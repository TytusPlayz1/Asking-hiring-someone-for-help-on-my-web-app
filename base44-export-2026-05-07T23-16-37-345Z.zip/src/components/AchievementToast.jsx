import React, { useState, useEffect, createContext, useContext, useCallback } from 'react';

const AchievementContext = createContext(null);

export const useAchievement = () => useContext(AchievementContext);

export function AchievementProvider({ children }) {
  const [toasts, setToasts] = useState([]);

  const unlock = useCallback((title, desc, icon = '🏆') => {
    const id = Date.now();
    setToasts(p => [...p, { id, title, desc, icon }]);
    setTimeout(() => setToasts(p => p.filter(t => t.id !== id)), 4500);
  }, []);

  return (
    <AchievementContext.Provider value={{ unlock }}>
      {children}
      {/* Toast container */}
      <div className="fixed top-20 right-4 z-[100] space-y-2 pointer-events-none">
        {toasts.map(t => (
          <div key={t.id} className="achievement-toast animate-in slide-in-from-right-4 fade-in duration-300">
            <div className="flex items-center gap-3 bg-[#212121] border-2 border-[#555] rounded-lg px-4 py-3 shadow-[4px_4px_0px_#000] min-w-[260px]">
              <span className="text-2xl leading-none">{t.icon}</span>
              <div>
                <div className="text-[10px] text-yellow-400 font-bold uppercase tracking-widest">Achievement Get!</div>
                <div className="text-sm font-bold text-white leading-tight">{t.title}</div>
                {t.desc && <div className="text-xs text-gray-400 mt-0.5">{t.desc}</div>}
              </div>
            </div>
          </div>
        ))}
      </div>
    </AchievementContext.Provider>
  );
}