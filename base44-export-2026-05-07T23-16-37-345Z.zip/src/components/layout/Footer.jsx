import React from 'react';
import { Link } from 'react-router-dom';
import { Server, Github, MessageCircle } from 'lucide-react';

const footerLinks = {
  Product: [
    { label: 'Play Eaglercraft', path: '/play' },
    { label: 'Features', path: '/features' },
    { label: 'Dashboard', path: '/dashboard' },
  ],
  Support: [
    { label: 'Knowledge Base', path: '/knowledge-base' },
    { label: 'Status Page', path: '#' },
    { label: 'Contact Us', path: '#' },
  ],
  Legal: [
    { label: 'Terms of Service', path: '#' },
    { label: 'Privacy Policy', path: '#' },
    { label: 'Free Forever Policy', path: '#' },
  ],
};

export default function Footer() {
  return (
    <footer className="border-t border-border/50 bg-card/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 lg:gap-12">
          <div className="col-span-2 md:col-span-1">
            <Link to="/" className="flex items-center gap-2.5 mb-4">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <Server className="w-4 h-4 text-white" />
              </div>
              <span className="text-lg font-bold">
                Diorite<span className="text-primary">Hosting+</span>
              </span>
            </Link>
            <p className="text-sm text-muted-foreground leading-relaxed mb-4">
              100% free Minecraft hosting — Java, Bedrock & Eaglercraft. 24/7 uptime, unlimited players, no limits.
            </p>
            <div className="flex gap-3">
              <a href="#" className="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-secondary/80 transition-colors">
                <Github className="w-4 h-4" />
              </a>
              <a href="#" className="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-secondary/80 transition-colors">
                <MessageCircle className="w-4 h-4" />
              </a>
            </div>
          </div>

          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h4 className="text-sm font-semibold mb-4">{category}</h4>
              <ul className="space-y-2.5">
                {links.map((link) => (
                  <li key={link.label}>
                    <Link
                      to={link.path}
                      className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 pt-8 border-t border-border/50 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-muted-foreground">
            © 2026 Diorite Hosting+. All rights reserved.
          </p>
          <p className="text-xs text-muted-foreground">
            Not affiliated with Mojang Studios or Microsoft.
          </p>
          <p className="text-xs text-muted-foreground/60 flex items-center gap-2">
            <span>Made by <span className="text-primary/80 font-medium">Tytus Stevenson</span></span>
            <span className="px-1.5 py-0.5 rounded bg-secondary/60 border border-border/30 font-mono text-muted-foreground/50">v2.000</span>
          </p>
        </div>
      </div>
    </footer>
  );
}