import React from 'react';
import { Outlet } from 'react-router-dom';
import Navbar from './Navbar';
import Footer from './Footer';
import MusicPlayer from '../MusicPlayer';
import ParticleBackground from '../ParticleBackground';

export default function AppLayout() {
  return (
    <div className="min-h-screen flex flex-col relative">
      <ParticleBackground />
      <div className="relative z-10 flex flex-col min-h-screen">
        <Navbar />
        <main className="flex-1 pt-16">
          <Outlet />
        </main>
        <Footer />
      </div>
      <MusicPlayer />
    </div>
  );
}