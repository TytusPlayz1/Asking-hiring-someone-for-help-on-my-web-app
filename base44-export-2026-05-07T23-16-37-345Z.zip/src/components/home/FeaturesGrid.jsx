import React from 'react';
import { motion } from 'framer-motion';
import {
  Server, Shield, Zap, Globe, Cpu, HardDrive,
  Terminal, Users, Clock, Lock, Layers, Gauge
} from 'lucide-react';

const features = [
  {
    icon: Server,
    title: 'Pterodactyl Panel',
    description: 'Industry-standard game panel with full file management, console, and scheduling.',
    color: 'text-blue-400',
    bg: 'bg-blue-400/10',
  },
  {
    icon: Globe,
    title: 'Eaglercraft Support',
    description: 'Built-in EaglercraftXBungee proxy so players can join directly from their browser.',
    color: 'text-purple-400',
    bg: 'bg-purple-400/10',
  },
  {
    icon: Shield,
    title: 'DDoS Protection',
    description: 'Enterprise-grade mitigation absorbs attacks up to 1Tbps with zero downtime.',
    color: 'text-green-400',
    bg: 'bg-green-400/10',
  },
  {
    icon: Cpu,
    title: 'Ryzen 9 CPUs',
    description: 'AMD Ryzen 9 7950X processors ensure buttery-smooth gameplay at high TPS.',
    color: 'text-red-400',
    bg: 'bg-red-400/10',
  },
  {
    icon: HardDrive,
    title: 'NVMe Storage',
    description: 'Ultra-fast NVMe SSDs for instant chunk loading and rapid world saves.',
    color: 'text-yellow-400',
    bg: 'bg-yellow-400/10',
  },
  {
    icon: Layers,
    title: 'Full Mod Support',
    description: 'Forge, Fabric, Spigot, Paper — install any loader or modpack effortlessly.',
    color: 'text-cyan-400',
    bg: 'bg-cyan-400/10',
  },
  {
    icon: Terminal,
    title: 'Full Console Access',
    description: 'Execute commands, view live logs, and manage everything from the web panel.',
    color: 'text-orange-400',
    bg: 'bg-orange-400/10',
  },
  {
    icon: Users,
    title: 'Subuser Management',
    description: 'Grant granular permissions to moderators and admins on your server.',
    color: 'text-pink-400',
    bg: 'bg-pink-400/10',
  },
  {
    icon: Clock,
    title: 'Instant Deployment',
    description: 'Your server spins up in under 30 seconds. No waiting, no manual setup.',
    color: 'text-emerald-400',
    bg: 'bg-emerald-400/10',
  },
  {
    icon: Lock,
    title: 'Automated Backups',
    description: 'Schedule automatic world backups with one-click restore at any time.',
    color: 'text-indigo-400',
    bg: 'bg-indigo-400/10',
  },
  {
    icon: Gauge,
    title: '99.9% Uptime SLA',
    description: 'Our infrastructure is built for reliability with redundant power and networking.',
    color: 'text-teal-400',
    bg: 'bg-teal-400/10',
  },
  {
    icon: Zap,
    title: 'Free MySQL Database',
    description: 'Every plan includes a free MySQL database for plugins that require one.',
    color: 'text-amber-400',
    bg: 'bg-amber-400/10',
  },
];

export default function FeaturesGrid() {
  return (
    <section className="py-24 lg:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            Everything You Need to
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent"> Dominate</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Enterprise-grade features at indie prices. No compromises.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {features.map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.05 }}
              className="group p-5 rounded-xl bg-card/50 border border-border/30 hover:border-primary/30 hover:bg-card transition-all duration-300"
            >
              <div className={`w-10 h-10 rounded-lg ${feature.bg} flex items-center justify-center mb-4`}>
                <feature.icon className={`w-5 h-5 ${feature.color}`} />
              </div>
              <h3 className="font-semibold text-sm mb-1.5">{feature.title}</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}