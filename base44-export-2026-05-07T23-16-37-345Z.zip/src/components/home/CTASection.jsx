import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowRight, Sparkles } from 'lucide-react';

export default function CTASection() {
  return (
    <section className="py-24 lg:py-32 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-accent/10 border border-accent/20 text-accent text-sm font-medium mb-6">
          <Sparkles className="w-3.5 h-3.5" />
          Ready to get started?
        </div>

        <h2 className="text-3xl sm:text-5xl font-black mb-6 leading-tight">
          Launch Your Minecraft
          <br />
          Server Today
        </h2>

        <p className="text-lg text-muted-foreground mb-10 max-w-xl mx-auto">
          Join thousands of server owners who trust EnderHost for reliable,
          high-performance Minecraft hosting.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link to="/pricing">
            <Button size="lg" className="bg-gradient-to-r from-primary to-accent hover:opacity-90 text-white border-0 px-8 h-12 text-base font-semibold">
              Get Started Now
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
          <Link to="/knowledge-base">
            <Button variant="outline" size="lg" className="border-border/50 h-12 px-8 text-base">
              Read the Docs
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}