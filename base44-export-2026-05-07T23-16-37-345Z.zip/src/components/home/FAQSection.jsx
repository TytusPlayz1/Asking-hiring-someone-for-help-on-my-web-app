import React from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

const faqs = [
  {
    q: 'What is Eaglercraft and how does it work?',
    a: 'Eaglercraft allows players to join Minecraft servers directly from a web browser — no downloads needed. We run an EaglercraftXBungee proxy that translates WebSocket connections into standard Minecraft protocol, so browser players can play alongside Java clients.',
  },
  {
    q: 'Can I install mods and plugins?',
    a: 'Absolutely. We support Forge, Fabric, Spigot, Paper, Purpur, and BungeeCord. Upload your mods through the Pterodactyl file manager or use our one-click modpack installer.',
  },
  {
    q: 'What panel do you use?',
    a: 'We use Pterodactyl — the industry-standard, open-source game server management panel. It provides a full web interface with console access, file management, scheduled tasks, and subuser permissions.',
  },
  {
    q: 'Do you support both Java and Bedrock?',
    a: 'Yes. All plans support Java Edition. Bedrock crossplay can be enabled via the GeyserMC plugin, which we pre-install on request. Eaglercraft proxy support is available on Pro plans and above.',
  },
  {
    q: 'How does billing work?',
    a: 'We use an automated billing system connected to our Pterodactyl panel. When you purchase a plan, your server is provisioned instantly. You can upgrade, downgrade, or cancel at any time.',
  },
  {
    q: 'What kind of DDoS protection do you offer?',
    a: 'All servers are protected by enterprise-grade DDoS mitigation that can absorb attacks up to 1Tbps. Protection is always-on and included free with every plan.',
  },
];

export default function FAQSection() {
  return (
    <section className="py-24 lg:py-32 bg-card/30">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            Frequently Asked
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent"> Questions</span>
          </h2>
          <p className="text-muted-foreground">
            Got questions? We've got answers.
          </p>
        </div>

        <Accordion type="single" collapsible className="space-y-3">
          {faqs.map((faq, i) => (
            <AccordionItem
              key={i}
              value={`faq-${i}`}
              className="border border-border/30 rounded-xl px-6 bg-card/50 data-[state=open]:bg-card data-[state=open]:border-primary/20"
            >
              <AccordionTrigger className="text-sm font-medium hover:no-underline py-5">
                {faq.q}
              </AccordionTrigger>
              <AccordionContent className="text-sm text-muted-foreground leading-relaxed pb-5">
                {faq.a}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
}