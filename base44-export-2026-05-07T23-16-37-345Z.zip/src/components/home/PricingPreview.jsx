import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Check, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

const plans = [
  {
    name: 'Starter',
    price: '$4',
    period: '/mo',
    description: 'Perfect for small vanilla servers',
    ram: '2 GB',
    features: ['2 GB RAM', '10 GB NVMe', '2 vCPU Cores', 'Java & Bedrock', '1 Backup Slot'],
    popular: false,
  },
  {
    name: 'Pro',
    price: '$8',
    period: '/mo',
    description: 'Ideal for modded & community servers',
    ram: '4 GB',
    features: ['4 GB RAM', '25 GB NVMe', '3 vCPU Cores', 'Full Mod Support', '3 Backup Slots', 'Free MySQL'],
    popular: true,
  },
  {
    name: 'Enterprise',
    price: '$16',
    period: '/mo',
    description: 'Maximum performance for large networks',
    ram: '8 GB',
    features: ['8 GB RAM', '50 GB NVMe', '4 vCPU Cores', 'Eaglercraft Proxy', '5 Backup Slots', 'Priority Support'],
    popular: false,
  },
];

export default function PricingPreview() {
  return (
    <section className="py-24 lg:py-32 relative">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/5 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            Simple,
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent"> Transparent </span>
            Pricing
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            No hidden fees. No surprises. Scale up or down at any time.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {plans.map((plan, i) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.1 }}
              className={`relative rounded-2xl p-6 transition-all duration-300 ${
                plan.popular
                  ? 'bg-gradient-to-b from-primary/10 to-card border-2 border-primary/30 shadow-lg shadow-primary/5'
                  : 'bg-card/50 border border-border/30 hover:border-border/60'
              }`}
            >
              {plan.popular && (
                <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-primary to-accent text-white border-0 px-4">
                  Most Popular
                </Badge>
              )}

              <div className="mb-6">
                <h3 className="text-lg font-bold mb-1">{plan.name}</h3>
                <p className="text-xs text-muted-foreground mb-4">{plan.description}</p>
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl font-black">{plan.price}</span>
                  <span className="text-sm text-muted-foreground">{plan.period}</span>
                </div>
              </div>

              <ul className="space-y-3 mb-8">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-center gap-2.5 text-sm">
                    <div className="w-4 h-4 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Check className="w-2.5 h-2.5 text-primary" />
                    </div>
                    {feature}
                  </li>
                ))}
              </ul>

              <Link to="/pricing">
                <Button
                  className={`w-full ${
                    plan.popular
                      ? 'bg-gradient-to-r from-primary to-accent hover:opacity-90 text-white border-0'
                      : 'bg-secondary hover:bg-secondary/80'
                  }`}
                >
                  Get Started
                </Button>
              </Link>
            </motion.div>
          ))}
        </div>

        <div className="text-center mt-10">
          <Link to="/pricing" className="inline-flex items-center gap-1 text-sm text-primary hover:underline font-medium">
            See all plans and compare features
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>
    </section>
  );
}