import React, { useState, useRef, useEffect } from 'react';
import { Music, Play, Pause, SkipForward, SkipBack, Volume2, VolumeX, ChevronUp, ChevronDown, Disc3 } from 'lucide-react';

// All tracks use a single well-seeded archive.org identifier with correct filenames
const A = 'https://archive.org/download/Minecraft_Volume_Alpha';
const B = 'https://archive.org/download/Minecraft_Volume_Beta_C418';

const TRACKS = [
  // C418 - Volume Alpha (all filenames verified against the archive)
  { title: 'Key', artist: 'C418', cat: 'C418 Classic', src: `${A}/C418%20-%20Minecraft%20-%20Volume%20Alpha%20-%2001%20Key.mp3` },
  { title: 'Door', artist: 'C418', cat: 'C418 Classic', src: `${A}/C418%20-%20Minecraft%20-%20Volume%20Alpha%20-%2002%20Door.mp3` },
  { title: 'Subwoofer Lullaby', artist: 'C418', cat: 'C418 Classic', src: `${A}/C418%20-%20Minecraft%20-%20Volume%20Alpha%20-%2003%20Subwoofer%20Lullaby.mp3` },
  { title: 'Death', artist: 'C418', cat: 'C418 Classic', src: `${A}/C418%20-%20Minecraft%20-%20Volume%20Alpha%20-%2004%20Death.mp3` },
  { title: 'Living Mice', artist: 'C418', cat: 'C418 Classic', src: `${A}/C418%20-%20Minecraft%20-%20Volume%20Alpha%20-%2005%20Living%20Mice.mp3` },
  { title: 'Moog City', artist: 'C418', cat: 'C418 Classic', src: `${A}/C418%20-%20Minecraft%20-%20Volume%20Alpha%20-%2006%20Moog%20City.mp3` },
  { title: 'Haggstrom', artist: 'C418', cat: 'C418 Classic', src: `${A}/C418%20-%20Minecraft%20-%20Volume%20Alpha%20-%2007%20Haggstrom.mp3` },
  { title: 'Minecraft', artist: 'C418', cat: 'C418 Classic', src: `${A}/C418%20-%20Minecraft%20-%20Volume%20Alpha%20-%2008%20Minecraft.mp3` },
  { title: 'Oxygène', artist: 'C418', cat: 'C418 Classic', src: `${A}/C418%20-%20Minecraft%20-%20Volume%20Alpha%20-%2009%20Oxygene.mp3` },
  { title: 'Mice on Venus', artist: 'C418', cat: 'C418 Classic', src: `${A}/C418%20-%20Minecraft%20-%20Volume%20Alpha%20-%2010%20Mice%20on%20Venus.mp3` },
  { title: 'Dry Hands', artist: 'C418', cat: 'C418 Classic', src: `${A}/C418%20-%20Minecraft%20-%20Volume%20Alpha%20-%2011%20Dry%20Hands.mp3` },
  { title: 'Wet Hands', artist: 'C418', cat: 'C418 Classic', src: `${A}/C418%20-%20Minecraft%20-%20Volume%20Alpha%20-%2012%20Wet%20Hands.mp3` },
  { title: 'Danny', artist: 'C418', cat: 'C418 Classic', src: `${A}/C418%20-%20Minecraft%20-%20Volume%20Alpha%20-%2013%20Danny.mp3` },
  { title: 'Sweden', artist: 'C418', cat: 'C418 Classic', src: `${A}/C418%20-%20Minecraft%20-%20Volume%20Alpha%20-%2014%20Sweden.mp3` },
  { title: 'Droopy likes ricochet', artist: 'C418', cat: 'C418 Classic', src: `${A}/C418%20-%20Minecraft%20-%20Volume%20Alpha%20-%2015%20Droopy%20likes%20ricochet.mp3` },
  { title: 'Droopy likes your face', artist: 'C418', cat: 'C418 Classic', src: `${A}/C418%20-%20Minecraft%20-%20Volume%20Alpha%20-%2016%20Droopy%20likes%20your%20face.mp3` },
  // C418 - Volume Beta
  { title: 'Ki', artist: 'C418', cat: 'C418 Beta', src: `${B}/C418%20-%20Minecraft%20-%20Volume%20Beta%20-%2001%20Ki.mp3` },
  { title: 'Alpha', artist: 'C418', cat: 'C418 Beta', src: `${B}/C418%20-%20Minecraft%20-%20Volume%20Beta%20-%2002%20Alpha.mp3` },
  { title: 'Dead Voxel', artist: 'C418', cat: 'C418 Beta', src: `${B}/C418%20-%20Minecraft%20-%20Volume%20Beta%20-%2003%20Dead%20Voxel.mp3` },
  { title: 'Blind Spots', artist: 'C418', cat: 'C418 Beta', src: `${B}/C418%20-%20Minecraft%20-%20Volume%20Beta%20-%2004%20Blind%20Spots.mp3` },
  { title: 'Aria Math', artist: 'C418', cat: 'C418 Beta', src: `${B}/C418%20-%20Minecraft%20-%20Volume%20Beta%20-%2005%20Aria%20Math.mp3` },
  { title: 'Moog City 2', artist: 'C418', cat: 'C418 Beta', src: `${B}/C418%20-%20Minecraft%20-%20Volume%20Beta%20-%2006%20Moog%20City%202.mp3` },
  { title: 'Beginning 2', artist: 'C418', cat: 'C418 Beta', src: `${B}/C418%20-%20Minecraft%20-%20Volume%20Beta%20-%2007%20Beginning%202.mp3` },
  { title: 'Biome Fest', artist: 'C418', cat: 'C418 Beta', src: `${B}/C418%20-%20Minecraft%20-%20Volume%20Beta%20-%2008%20Biome%20Fest.mp3` },
  { title: 'Chirp', artist: 'C418', cat: 'C418 Beta', src: `${B}/C418%20-%20Minecraft%20-%20Volume%20Beta%20-%2009%20Chirp.mp3` },
  { title: 'Clark', artist: 'C418', cat: 'C418 Beta', src: `${B}/C418%20-%20Minecraft%20-%20Volume%20Beta%20-%2010%20Clark.mp3` },
  { title: 'Chris', artist: 'C418', cat: 'C418 Beta', src: `${B}/C418%20-%20Minecraft%20-%20Volume%20Beta%20-%2011%20Chris.mp3` },
  { title: 'Thirteen', artist: 'C418', cat: 'C418 Beta', src: `${B}/C418%20-%20Minecraft%20-%20Volume%20Beta%20-%2012%20Thirteen.mp3` },
  { title: 'Excuse', artist: 'C418', cat: 'C418 Beta', src: `${B}/C418%20-%20Minecraft%20-%20Volume%20Beta%20-%2013%20Excuse.mp3` },
  { title: 'Haunt Muskie', artist: 'C418', cat: 'C418 Beta', src: `${B}/C418%20-%20Minecraft%20-%20Volume%20Beta%20-%2014%20Haunt%20Muskie.mp3` },
  { title: 'Minecraft', artist: 'C418', cat: 'C418 Beta', src: `${B}/C418%20-%20Minecraft%20-%20Volume%20Beta%20-%2015%20Minecraft.mp3` },
  { title: 'Flake', artist: 'C418', cat: 'C418 Beta', src: `${B}/C418%20-%20Minecraft%20-%20Volume%20Beta%20-%2016%20Flake.mp3` },
  { title: 'Mutation', artist: 'C418', cat: 'C418 Beta', src: `${B}/C418%20-%20Minecraft%20-%20Volume%20Beta%20-%2017%20Mutation.mp3` },
  { title: 'Droopy Remembers', artist: 'C418', cat: 'C418 Beta', src: `${B}/C418%20-%20Minecraft%20-%20Volume%20Beta%20-%2018%20Droopy%20Remembers.mp3` },
  { title: 'Taswell', artist: 'C418', cat: 'C418 Beta', src: `${B}/C418%20-%20Minecraft%20-%20Volume%20Beta%20-%2019%20Taswell.mp3` },
  { title: 'Dreiton', artist: 'C418', cat: 'C418 Beta', src: `${B}/C418%20-%20Minecraft%20-%20Volume%20Beta%20-%2020%20Dreiton.mp3` },
  { title: 'Floating Trees', artist: 'C418', cat: 'C418 Beta', src: `${B}/C418%20-%20Minecraft%20-%20Volume%20Beta%20-%2021%20Floating%20Trees.mp3` },
];

const CATS = ['All', 'C418 Classic', 'C418 Beta'];

export default function MusicPlayer() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrack, setCurrentTrack] = useState(0);
  const [volume, setVolume] = useState(0.3);
  const [muted, setMuted] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [activeCat, setActiveCat] = useState('All');
  const audioRef = useRef(null);

  const filteredTracks = activeCat === 'All' ? TRACKS : TRACKS.filter(t => t.cat === activeCat);

  useEffect(() => {
    if (audioRef.current) audioRef.current.volume = muted ? 0 : volume;
  }, [volume, muted]);

  useEffect(() => {
    if (audioRef.current && isPlaying) {
      audioRef.current.load();
      audioRef.current.play().catch(() => setIsPlaying(false));
    }
  }, [currentTrack]);

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) { audioRef.current.pause(); } else { audioRef.current.play().catch(() => {}); }
    setIsPlaying(!isPlaying);
  };

  const nextTrack = () => setCurrentTrack(p => (p + 1) % TRACKS.length);
  const prevTrack = () => setCurrentTrack(p => (p - 1 + TRACKS.length) % TRACKS.length);

  const playTrack = (globalIdx) => {
    setCurrentTrack(globalIdx);
    setIsPlaying(true);
    setTimeout(() => audioRef.current?.play().catch(() => setIsPlaying(false)), 50);
  };

  const formatTime = (s) => {
    if (!s || isNaN(s)) return '0:00';
    return `${Math.floor(s / 60)}:${Math.floor(s % 60).toString().padStart(2, '0')}`;
  };

  const progressPercent = duration ? (progress / duration) * 100 : 0;
  const track = TRACKS[currentTrack];

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <audio
        ref={audioRef}
        src={track.src}
        onTimeUpdate={() => audioRef.current && setProgress(audioRef.current.currentTime)}
        onLoadedMetadata={() => audioRef.current && setDuration(audioRef.current.duration)}
        onEnded={nextTrack}

      />

      <div className={`bg-card/95 backdrop-blur-xl border border-border/50 rounded-2xl shadow-2xl overflow-hidden transition-all duration-300 ${expanded ? 'w-80' : 'w-auto'}`}>

        {expanded && (
          <div className="p-4 border-b border-border/30">
            {/* Header */}
            <div className="flex items-center gap-3 mb-3">
              <div className={`w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center flex-shrink-0 ${isPlaying ? 'animate-pulse' : ''}`}>
                <Disc3 className={`w-5 h-5 text-white ${isPlaying ? 'animate-spin' : ''}`} style={{ animationDuration: '3s' }} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-bold truncate">{track.title}</div>
                <div className="text-xs text-muted-foreground">{track.artist} • {track.cat}</div>
              </div>
            </div>

            {/* Progress */}
            <div className="h-1.5 bg-secondary rounded-full cursor-pointer mb-1"
              onClick={e => { const r = e.currentTarget.getBoundingClientRect(); if (audioRef.current) { audioRef.current.currentTime = ((e.clientX - r.left) / r.width) * duration; } }}>
              <div className="h-full bg-gradient-to-r from-primary to-accent rounded-full" style={{ width: `${progressPercent}%` }} />
            </div>
            <div className="flex justify-between text-xs text-muted-foreground mb-3">
              <span>{formatTime(progress)}</span><span>{formatTime(duration)}</span>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-center gap-4 mb-3">
              <button onClick={prevTrack} className="text-muted-foreground hover:text-foreground transition-colors"><SkipBack className="w-4 h-4" /></button>
              <button onClick={togglePlay} className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center hover:opacity-90">
                {isPlaying ? <Pause className="w-4 h-4 text-white" /> : <Play className="w-4 h-4 text-white ml-0.5" />}
              </button>
              <button onClick={nextTrack} className="text-muted-foreground hover:text-foreground transition-colors"><SkipForward className="w-4 h-4" /></button>
            </div>

            {/* Volume */}
            <div className="flex items-center gap-2 mb-3">
              <button onClick={() => setMuted(!muted)} className="text-muted-foreground hover:text-foreground">
                {muted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
              </button>
              <input type="range" min="0" max="1" step="0.01" value={muted ? 0 : volume}
                onChange={e => { setVolume(parseFloat(e.target.value)); setMuted(false); }}
                className="flex-1 h-1 accent-blue-500 cursor-pointer" />
            </div>

            {/* Category filter */}
            <div className="flex gap-1 mb-2 flex-wrap">
              {CATS.map(c => (
                <button key={c} onClick={() => setActiveCat(c)}
                  className={`px-2 py-0.5 rounded-md text-xs transition-all ${activeCat === c ? 'bg-primary text-white' : 'bg-secondary/60 text-muted-foreground hover:text-foreground'}`}>
                  {c}
                </button>
              ))}
            </div>

            {/* Track list */}
            <div className="space-y-0.5 max-h-40 overflow-y-auto">
              {filteredTracks.map((t) => {
                const globalIdx = TRACKS.indexOf(t);
                return (
                  <button key={t.title} onClick={() => playTrack(globalIdx)}
                    className={`w-full text-left px-2 py-1.5 rounded-lg text-xs flex items-center gap-2 transition-colors ${
                      globalIdx === currentTrack ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:bg-secondary/50 hover:text-foreground'
                    }`}>
                    {globalIdx === currentTrack && isPlaying
                      ? <span className="w-2 h-2 rounded-full bg-primary animate-pulse flex-shrink-0" />
                      : <span className="w-2 h-2 rounded-full bg-border flex-shrink-0" />}
                    <span className="flex-1 truncate">{t.title}</span>
                    <span className="text-muted-foreground/50 text-xs">{t.cat.split(' ')[1] || ''}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Collapsed bar */}
        <div className="flex items-center gap-2 px-3 py-2.5">
          <button onClick={togglePlay} className="w-8 h-8 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center hover:opacity-90 flex-shrink-0">
            {isPlaying ? <Pause className="w-3.5 h-3.5 text-white" /> : <Play className="w-3.5 h-3.5 text-white ml-0.5" />}
          </button>
          <span className="text-xs text-muted-foreground max-w-[120px] truncate">
            {isPlaying ? `♪ ${track.title}` : 'Diorite Jukebox'}
          </span>
          <button onClick={() => setExpanded(!expanded)} className="text-muted-foreground hover:text-foreground transition-colors">
            {expanded ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </div>
  );
}