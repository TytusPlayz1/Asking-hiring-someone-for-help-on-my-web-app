import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Users, Crown, Plus, Shield, Check } from 'lucide-react';

const perms = [
  'Full control over every permission',
  'Granular per-user permissions',
  'Full audit log of every action',
  'Revoke or edit access at any time',
];

export default function ServerTeamTab() {
  const [email, setEmail] = useState('');
  const [invited, setInvited] = useState(false);

  const handleInvite = () => {
    if (!email.trim()) return;
    setInvited(true);
    setEmail('');
    setTimeout(() => setInvited(false), 3000);
  };

  return (
    <div className="space-y-5 max-w-2xl">
      <div>
        <h2 className="text-xl font-bold">Team</h2>
        <p className="text-sm text-muted-foreground">1 member</p>
      </div>

      {/* Current member */}
      <div className="p-5 rounded-xl bg-card/50 border border-border/30">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center font-bold text-white text-sm">T</div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-sm">You</span>
              <span className="flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-yellow-500/10 border border-yellow-500/20 text-yellow-400">
                <Crown className="w-3 h-3" />Server Owner
              </span>
            </div>
            <div className="text-xs text-muted-foreground mt-0.5">Full control over every permission</div>
          </div>
        </div>
      </div>

      {/* Invite CTA */}
      <div className="p-5 rounded-xl bg-gradient-to-br from-primary/10 to-accent/10 border border-primary/20">
        <h3 className="font-bold mb-1">Bring your team along.</h3>
        <p className="text-sm text-muted-foreground mb-4">Invite friends, moderators, or co-owners to help run your server. Granular permissions let you decide exactly what each person can do.</p>
        <div className="space-y-2 mb-5">
          {perms.map(p => (
            <div key={p} className="flex items-center gap-2 text-xs">
              <Check className="w-3.5 h-3.5 text-primary flex-shrink-0" />
              <span>{p}</span>
            </div>
          ))}
        </div>
        <div className="flex gap-2">
          <Input
            placeholder="friend@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleInvite()}
            className="bg-background/60 border-border/40 h-9 text-sm"
          />
          <Button size="sm" className="h-9 bg-primary hover:bg-primary/90 text-white border-0 gap-1.5" onClick={handleInvite}>
            <Plus className="w-3.5 h-3.5" />
            {invited ? 'Invited!' : 'Invite'}
          </Button>
        </div>
      </div>

      {/* Permissions overview */}
      <div className="p-5 rounded-xl bg-card/50 border border-border/30">
        <div className="flex items-center gap-2 mb-3">
          <Shield className="w-4 h-4 text-primary" />
          <h3 className="font-semibold text-sm">Role Permissions</h3>
        </div>
        <div className="space-y-2 text-xs text-muted-foreground">
          <div className="flex items-center justify-between py-2 border-b border-border/20">
            <span className="flex items-center gap-2"><Crown className="w-3.5 h-3.5 text-yellow-400" />Owner</span>
            <span className="text-green-400">Full Access</span>
          </div>
          <div className="flex items-center justify-between py-2 border-b border-border/20">
            <span className="flex items-center gap-2"><Shield className="w-3.5 h-3.5 text-blue-400" />Admin</span>
            <span>Console, Files, Players</span>
          </div>
          <div className="flex items-center justify-between py-2">
            <span className="flex items-center gap-2"><Users className="w-3.5 h-3.5 text-muted-foreground" />Moderator</span>
            <span>Console, Players</span>
          </div>
        </div>
      </div>
    </div>
  );
}