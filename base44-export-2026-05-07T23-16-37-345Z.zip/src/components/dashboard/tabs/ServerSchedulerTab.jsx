import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Clock, Plus, Trash2, RotateCw, Archive, Check } from 'lucide-react';

const defaultTasks = [
  { id: 1, name: 'Daily Restart', action: 'restart', schedule: '04:00', days: ['everyday'], enabled: true },
  { id: 2, name: 'Daily Backup', action: 'backup', schedule: '03:00', days: ['everyday'], enabled: true },
];

const ACTIONS = [
  { id: 'restart', label: 'Restart Server', icon: RotateCw, color: 'text-yellow-400' },
  { id: 'backup', label: 'Create Backup', icon: Archive, color: 'text-blue-400' },
  { id: 'say', label: 'Broadcast Message', icon: Clock, color: 'text-green-400' },
];

const DAY_OPTIONS = ['everyday', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

export default function ServerSchedulerTab() {
  const [tasks, setTasks] = useState(defaultTasks);
  const [showAdd, setShowAdd] = useState(false);
  const [newName, setNewName] = useState('');
  const [newAction, setNewAction] = useState('restart');
  const [newTime, setNewTime] = useState('06:00');
  const [newDays, setNewDays] = useState(['everyday']);
  const [saved, setSaved] = useState(null);

  const toggleTask = (id) => {
    setTasks(p => p.map(t => t.id === id ? { ...t, enabled: !t.enabled } : t));
  };

  const deleteTask = (id) => setTasks(p => p.filter(t => t.id !== id));

  const addTask = () => {
    if (!newName.trim()) return;
    setTasks(p => [...p, { id: Date.now(), name: newName, action: newAction, schedule: newTime, days: newDays, enabled: true }]);
    setNewName(''); setNewAction('restart'); setNewTime('06:00'); setNewDays(['everyday']);
    setShowAdd(false);
    setSaved(Date.now());
    setTimeout(() => setSaved(null), 2000);
  };

  const toggleDay = (day) => {
    if (day === 'everyday') { setNewDays(['everyday']); return; }
    setNewDays(p => {
      const filtered = p.filter(d => d !== 'everyday');
      return filtered.includes(day) ? filtered.filter(d => d !== day) : [...filtered, day];
    });
  };

  return (
    <div className="space-y-5 max-w-2xl">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold">Task Scheduler</h2>
          <p className="text-sm text-muted-foreground">Automate restarts, backups, and messages</p>
        </div>
        <Button size="sm" className="bg-primary/10 text-primary border border-primary/20 hover:bg-primary/20 gap-1.5 text-xs" variant="ghost" onClick={() => setShowAdd(!showAdd)}>
          <Plus className="w-3.5 h-3.5" />
          Add Task
        </Button>
      </div>

      {/* Info */}
      <div className="p-3 rounded-lg bg-blue-500/10 border border-blue-500/20 text-xs text-blue-300">
        <strong>Tip:</strong> Scheduled restarts clear RAM and prevent memory buildup — recommended every 24 hours for free servers.
      </div>

      {/* Add task form */}
      {showAdd && (
        <div className="p-4 rounded-xl bg-card/50 border border-primary/20 space-y-4">
          <h3 className="font-semibold text-sm">New Scheduled Task</h3>
          <div>
            <label className="text-xs text-muted-foreground block mb-1">Task Name</label>
            <input
              value={newName}
              onChange={e => setNewName(e.target.value)}
              placeholder="e.g. Nightly Restart"
              className="w-full px-3 py-2 text-sm rounded-lg bg-secondary/30 border border-border/40 focus:outline-none focus:border-primary/50 text-foreground placeholder:text-muted-foreground"
            />
          </div>
          <div>
            <label className="text-xs text-muted-foreground block mb-1">Action</label>
            <div className="grid grid-cols-3 gap-2">
              {ACTIONS.map(a => (
                <button key={a.id} onClick={() => setNewAction(a.id)}
                  className={`p-2 rounded-lg border text-xs font-medium flex items-center gap-1.5 justify-center transition-all ${newAction === a.id ? 'bg-primary/10 border-primary/40 text-primary' : 'border-border/30 text-muted-foreground hover:border-border/60'}`}>
                  <a.icon className={`w-3.5 h-3.5 ${newAction === a.id ? '' : a.color}`} />
                  {a.label.split(' ')[0]}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="text-xs text-muted-foreground block mb-1">Time (24h)</label>
            <input type="time" value={newTime} onChange={e => setNewTime(e.target.value)}
              className="px-3 py-2 text-sm rounded-lg bg-secondary/30 border border-border/40 focus:outline-none focus:border-primary/50 text-foreground" />
          </div>
          <div>
            <label className="text-xs text-muted-foreground block mb-1.5">Days</label>
            <div className="flex flex-wrap gap-1.5">
              {DAY_OPTIONS.map(day => (
                <button key={day} onClick={() => toggleDay(day)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition-all ${newDays.includes(day) ? 'bg-primary/10 border-primary/40 text-primary' : 'border-border/30 text-muted-foreground hover:border-border/60'}`}>
                  {day}
                </button>
              ))}
            </div>
          </div>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" className="border-border/40 text-xs" onClick={() => setShowAdd(false)}>Cancel</Button>
            <Button size="sm" className="flex-1 bg-primary hover:bg-primary/90 text-white border-0 text-xs gap-1.5" onClick={addTask} disabled={!newName.trim()}>
              <Check className="w-3.5 h-3.5" />
              Save Task
            </Button>
          </div>
        </div>
      )}

      {saved && (
        <div className="p-3 rounded-lg bg-green-500/10 border border-green-500/20 text-xs text-green-400 flex items-center gap-2">
          <Check className="w-3.5 h-3.5" />Task scheduled successfully!
        </div>
      )}

      {/* Task list */}
      <div className="space-y-2">
        {tasks.map(task => {
          const action = ACTIONS.find(a => a.id === task.action);
          const ActionIcon = action?.icon || Clock;
          return (
            <div key={task.id} className={`flex items-center gap-4 p-4 rounded-xl border transition-all ${task.enabled ? 'bg-card/50 border-border/30' : 'bg-secondary/20 border-border/20 opacity-60'}`}>
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${task.enabled ? 'bg-primary/10' : 'bg-muted'}`}>
                <ActionIcon className={`w-4 h-4 ${task.enabled ? action?.color || 'text-primary' : 'text-muted-foreground'}`} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-sm">{task.name}</div>
                <div className="text-xs text-muted-foreground">{action?.label} · {task.schedule} · {task.days.join(', ')}</div>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <button onClick={() => toggleTask(task.id)}
                  className={`relative w-10 h-5 rounded-full transition-colors ${task.enabled ? 'bg-primary' : 'bg-muted'}`}>
                  <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all ${task.enabled ? 'left-5' : 'left-0.5'}`} />
                </button>
                <button onClick={() => deleteTask(task.id)} className="p-1 rounded hover:bg-red-500/10 text-muted-foreground hover:text-red-400 transition-colors">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
        {tasks.length === 0 && (
          <div className="text-center py-10 text-muted-foreground">
            <Clock className="w-8 h-8 mx-auto mb-2 opacity-20" />
            <p className="text-xs">No scheduled tasks yet.</p>
          </div>
        )}
      </div>
    </div>
  );
}