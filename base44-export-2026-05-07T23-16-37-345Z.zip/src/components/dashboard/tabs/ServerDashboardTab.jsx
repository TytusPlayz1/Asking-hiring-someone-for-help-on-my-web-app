import React from 'react';
import { Copy, Users, Cpu, HardDrive, MemoryStick } from 'lucide-react';
import ResourceBar from '../ResourceBar';

export default function ServerDashboardTab({ server }) {
  const copyIP = () => navigator.clipboard.writeText(server.address);

  return (
    <div className="space-y-5 max-w-2xl">
      <div>
        <h2 className="text-xl font-bold">{server.name}</h2>
        <p className="text-sm text-muted-foreground">Server Dashboard</p>
      </div>

      {/* IP */}
      <div className="flex items-center justify-between p-4 rounded-xl bg-card/50 border border-border/30">
        <div>
          <div className="text-xs text-muted-foreground mb-0.5">Server IP</div>
          <div className="font-mono text-sm font-semibold">{server.address}</div>
        </div>
        <button onClick={copyIP} className="p-2 rounded-lg bg-primary/10 hover:bg-primary/20 transition-colors">
          <Copy className="w-4 h-4 text-primary" />
        </button>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 gap-3">
        <div className="p-4 rounded-xl bg-card/50 border border-border/30">
          <div className="flex items-center gap-2 mb-2">
            <Users className="w-4 h-4 text-blue-400" />
            <span className="text-xs text-muted-foreground">Players</span>
          </div>
          <div className="text-2xl font-bold">{server.playersOnline}/{server.playersMax}</div>
        </div>
        <div className="p-4 rounded-xl bg-card/50 border border-border/30">
          <div className="flex items-center gap-2 mb-2">
            <Cpu className="w-4 h-4 text-purple-400" />
            <span className="text-xs text-muted-foreground">CPU Usage</span>
          </div>
          <div className="text-2xl font-bold">{server.cpuUsage}%</div>
        </div>
        <div className="p-4 rounded-xl bg-card/50 border border-border/30 space-y-2">
          <div className="flex items-center gap-2">
            <MemoryStick className="w-4 h-4 text-orange-400" />
            <span className="text-xs text-muted-foreground">Memory</span>
          </div>
          <div className="text-lg font-bold">{(server.ramUsed / 1024).toFixed(1)}GB</div>
          <ResourceBar value={server.ramUsed} max={server.ramTotal} colorClass="bg-orange-500" animate={server.status === 'online'} label={`of ${(server.ramTotal / 1024).toFixed(0)}GB`} />
        </div>
        <div className="p-4 rounded-xl bg-card/50 border border-border/30 space-y-2">
          <div className="flex items-center gap-2">
            <HardDrive className="w-4 h-4 text-green-400" />
            <span className="text-xs text-muted-foreground">Storage</span>
          </div>
          <div className="text-lg font-bold">{server.diskUsed}GB</div>
          <ResourceBar value={server.diskUsed} max={server.diskTotal} colorClass="bg-green-500" label={`of ${server.diskTotal}GB`} />
        </div>
      </div>

      {/* Players list */}
      <div className="p-4 rounded-xl bg-card/50 border border-border/30">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-blue-400" />
            <span className="font-semibold text-sm">Players</span>
          </div>
          <span className="text-xs text-muted-foreground">{server.playersOnline}/{server.playersMax}</span>
        </div>
        {server.playersOnline === 0 ? (
          <div className="text-center py-6 text-muted-foreground">
            <Users className="w-8 h-8 mx-auto mb-2 opacity-20" />
            <p className="text-xs">No players online</p>
          </div>
        ) : null}
      </div>
    </div>
  );
}