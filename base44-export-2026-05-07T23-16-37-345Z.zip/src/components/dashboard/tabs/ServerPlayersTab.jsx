import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Crown, Shield, User, Ban, UserX, Users, Search } from 'lucide-react';

const initialPlayers = [
  { id: 1, name: 'Steve', role: 'admin', online: true, joined: '2026-05-01', lastSeen: 'Now' },
  { id: 2, name: 'Alex', role: 'member', online: true, joined: '2026-05-03', lastSeen: 'Now' },
  { id: 3, name: 'Notch', role: 'member', online: false, joined: '2026-04-20', lastSeen: '2 days ago' },
  { id: 4, name: 'Herobrine', role: 'banned', online: false, joined: '2026-04-15', lastSeen: '10 days ago' },
];

const roleConfig = {
  admin: { label: 'Admin', icon: Crown, color: 'text-yellow-400', bg: 'bg-yellow-400/10', border: 'border-yellow-400/20' },
  member: { label: 'Member', icon: User, color: 'text-blue-400', bg: 'bg-blue-400/10', border: 'border-blue-400/20' },
  moderator: { label: 'Mod', icon: Shield, color: 'text-green-400', bg: 'bg-green-400/10', border: 'border-green-400/20' },
  banned: { label: 'Banned', icon: Ban, color: 'text-red-400', bg: 'bg-red-400/10', border: 'border-red-400/20' },
};

export default function ServerPlayersTab({ server }) {
  const [players, setPlayers] = useState(initialPlayers);
  const [search, setSearch] = useState('');
  const [addName, setAddName] = useState('');

  const setRole = (id, role) => {
    setPlayers(p => p.map(pl => pl.id === id ? { ...pl, role } : pl));
  };

  const unban = (id) => setRole(id, 'member');

  const addOp = () => {
    if (!addName.trim()) return;
    setPlayers(p => [...p, { id: Date.now(), name: addName.trim(), role: 'admin', online: false, joined: new Date().toISOString().slice(0, 10), lastSeen: 'Never' }]);
    setAddName('');
  };

  const filtered = players.filter(p => p.name.toLowerCase().includes(search.toLowerCase()));
  const online = players.filter(p => p.online).length;

  return (
    <div className="space-y-5 max-w-2xl">
      <div>
        <h2 className="text-xl font-bold">Players</h2>
        <p className="text-sm text-muted-foreground">{online}/{server.playersMax} online</p>
      </div>

      {/* Quick op */}
      <div className="p-4 rounded-xl bg-card/50 border border-border/30 space-y-3">
        <h3 className="font-semibold text-sm flex items-center gap-2"><Crown className="w-4 h-4 text-yellow-400" />Quick OP a Player</h3>
        <div className="flex gap-2">
          <Input
            placeholder="Player username..."
            value={addName}
            onChange={e => setAddName(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && addOp()}
            className="bg-secondary/30 border-border/40 h-9 text-sm"
          />
          <Button size="sm" className="h-9 bg-yellow-500/10 text-yellow-400 border border-yellow-500/20 hover:bg-yellow-500/20 gap-1.5" variant="ghost" onClick={addOp} disabled={!addName.trim()}>
            <Crown className="w-3.5 h-3.5" />
            OP
          </Button>
        </div>
        <p className="text-xs text-muted-foreground">Gives a player full admin/operator rights without typing /op in console.</p>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
        <Input
          placeholder="Search players..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="pl-9 h-9 text-xs bg-secondary/30 border-border/40"
        />
      </div>

      {/* Player list */}
      <div className="space-y-2">
        {filtered.map(player => {
          const rc = roleConfig[player.role] || roleConfig.member;
          const RoleIcon = rc.icon;
          return (
            <div key={player.id} className="flex items-center gap-3 p-4 rounded-xl bg-card/50 border border-border/30">
              {/* Avatar */}
              <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center font-bold text-sm flex-shrink-0">
                {player.name[0]}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-semibold text-sm">{player.name}</span>
                  <span className={`flex items-center gap-1 text-xs px-2 py-0.5 rounded-full border ${rc.bg} ${rc.border} ${rc.color}`}>
                    <RoleIcon className="w-3 h-3" />{rc.label}
                  </span>
                  {player.online && <span className="w-2 h-2 bg-green-400 rounded-full" />}
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">Last seen: {player.lastSeen} · Joined: {player.joined}</p>
              </div>
              {/* Actions */}
              <div className="flex gap-1 flex-shrink-0">
                {player.role !== 'admin' && player.role !== 'banned' && (
                  <button onClick={() => setRole(player.id, 'admin')} title="Make Admin/OP" className="p-1.5 rounded-lg hover:bg-yellow-500/10 text-muted-foreground hover:text-yellow-400 transition-colors">
                    <Crown className="w-3.5 h-3.5" />
                  </button>
                )}
                {player.role === 'admin' && (
                  <button onClick={() => setRole(player.id, 'member')} title="Remove OP" className="p-1.5 rounded-lg hover:bg-secondary text-yellow-400 hover:text-muted-foreground transition-colors">
                    <Crown className="w-3.5 h-3.5" />
                  </button>
                )}
                {player.role === 'banned' ? (
                  <button onClick={() => unban(player.id)} title="Unban" className="p-1.5 rounded-lg hover:bg-green-500/10 text-red-400 hover:text-green-400 transition-colors">
                    <UserX className="w-3.5 h-3.5" />
                  </button>
                ) : (
                  <button onClick={() => setRole(player.id, 'banned')} title="Ban Player" className="p-1.5 rounded-lg hover:bg-red-500/10 text-muted-foreground hover:text-red-400 transition-colors">
                    <Ban className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
        {filtered.length === 0 && (
          <div className="text-center py-10 text-muted-foreground">
            <Users className="w-8 h-8 mx-auto mb-2 opacity-20" />
            <p className="text-xs">No players found.</p>
          </div>
        )}
      </div>
    </div>
  );
}