import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Download, Upload, Archive, AlertTriangle, CheckCircle2, Trash2, RefreshCw } from 'lucide-react';

const initialBackups = [
  { id: 1, name: 'auto-backup-2026-05-05', size: '142 MB', date: '2026-05-05 03:00', type: 'Auto' },
  { id: 2, name: 'auto-backup-2026-05-04', size: '138 MB', date: '2026-05-04 03:00', type: 'Auto' },
  { id: 3, name: 'manual-backup-2026-05-03', size: '135 MB', date: '2026-05-03 16:42', type: 'Manual' },
];

export default function ServerBackupsTab() {
  const [backups, setBackups] = useState(initialBackups);
  const [creating, setCreating] = useState(false);
  const [created, setCreated] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [downloading, setDownloading] = useState(null);

  const handleCreate = () => {
    setCreating(true);
    setTimeout(() => {
      const now = new Date();
      const dateStr = now.toISOString().slice(0, 10);
      const timeStr = `${now.getHours().toString().padStart(2,'0')}:${now.getMinutes().toString().padStart(2,'0')}`;
      setBackups(prev => [{
        id: Date.now(),
        name: `manual-backup-${dateStr}`,
        size: '140 MB',
        date: `${dateStr} ${timeStr}`,
        type: 'Manual',
      }, ...prev]);
      setCreating(false);
      setCreated(true);
      setTimeout(() => setCreated(false), 3000);
    }, 3000);
  };

  const handleDownload = (id) => {
    setDownloading(id);
    setTimeout(() => setDownloading(null), 2000);
  };

  const handleDelete = (id) => {
    setBackups(prev => prev.filter(b => b.id !== id));
  };

  return (
    <div className="space-y-5 max-w-2xl">
      <div>
        <h2 className="text-xl font-bold">Server Backups</h2>
        <p className="text-sm text-muted-foreground">Download and restore your server data</p>
      </div>

      {/* Create Backup */}
      <div className="p-5 rounded-xl bg-card/50 border border-border/30 space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center">
            <Archive className="w-5 h-5 text-blue-400" />
          </div>
          <div>
            <h3 className="font-semibold">Create Backup</h3>
            <p className="text-xs text-muted-foreground">Manually trigger a full world backup now</p>
          </div>
        </div>
        <Button
          className={`w-full gap-2 border-0 text-white ${created ? 'bg-green-600 hover:bg-green-700' : 'bg-gradient-to-r from-primary to-accent hover:opacity-90'}`}
          onClick={handleCreate}
          disabled={creating}
        >
          {creating ? (
            <><RefreshCw className="w-4 h-4 animate-spin" />Creating backup...</>
          ) : created ? (
            <><CheckCircle2 className="w-4 h-4" />Backup Created!</>
          ) : (
            <><Archive className="w-4 h-4" />Create Backup Now</>
          )}
        </Button>
        <div className="space-y-1.5 text-xs text-muted-foreground">
          <div className="flex items-start gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-green-400 mt-0.5 flex-shrink-0" />Creates a complete archive of all server files</div>
          <div className="flex items-start gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-green-400 mt-0.5 flex-shrink-0" />Includes worlds, plugins, and configurations</div>
        </div>
      </div>

      {/* Backup List */}
      <div className="p-5 rounded-xl bg-card/50 border border-border/30 space-y-3">
        <h3 className="font-semibold text-sm">Saved Backups</h3>
        {backups.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Archive className="w-8 h-8 mx-auto mb-2 opacity-20" />
            <p className="text-xs">No backups yet.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {backups.map(b => (
              <div key={b.id} className="flex items-center gap-3 p-3 rounded-lg bg-secondary/30 border border-border/20">
                <Archive className="w-4 h-4 text-blue-400 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium truncate">{b.name}</div>
                  <div className="text-xs text-muted-foreground">{b.date} · {b.size}</div>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full flex-shrink-0 ${b.type === 'Auto' ? 'bg-secondary text-muted-foreground' : 'bg-primary/10 text-primary border border-primary/20'}`}>{b.type}</span>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-7 w-7 p-0 text-muted-foreground hover:text-primary flex-shrink-0"
                  onClick={() => handleDownload(b.id)}
                >
                  {downloading === b.id
                    ? <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    : <Download className="w-3.5 h-3.5" />
                  }
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-7 w-7 p-0 text-muted-foreground hover:text-red-400 flex-shrink-0"
                  onClick={() => handleDelete(b.id)}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Import Backup */}
      <div className="p-5 rounded-xl bg-card/50 border border-border/30 space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-orange-500/10 flex items-center justify-center">
            <Upload className="w-5 h-5 text-orange-400" />
          </div>
          <div>
            <h3 className="font-semibold">Import Backup</h3>
            <p className="text-xs text-muted-foreground">Restore from a previous backup ZIP</p>
          </div>
        </div>
        <div className="flex items-center gap-2 p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20 text-xs text-yellow-400">
          <AlertTriangle className="w-4 h-4 flex-shrink-0" />
          <span><strong>Server Must Be Stopped</strong> — Stop your server before importing to prevent data corruption.</span>
        </div>
        <div
          onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => { e.preventDefault(); setDragging(false); }}
          className={`border-2 border-dashed rounded-xl p-8 text-center transition-colors cursor-pointer ${dragging ? 'border-primary bg-primary/5' : 'border-border/40 hover:border-border/70'}`}
        >
          <Archive className="w-8 h-8 mx-auto mb-2 text-muted-foreground/40" />
          <p className="text-sm font-medium">Drag & drop your backup ZIP file</p>
          <p className="text-xs text-muted-foreground mt-1">or click to browse (max 8GB)</p>
          <p className="text-xs text-muted-foreground/60 mt-1">Supported formats: .zip</p>
        </div>
      </div>
    </div>
  );
}