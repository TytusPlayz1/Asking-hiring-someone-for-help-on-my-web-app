import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Download, Check, Star, Puzzle } from 'lucide-react';

const allPlugins = [
  { id: 1, name: 'EssentialsX', version: '2.21.0', category: 'Utility', desc: 'The essential plugin suite for Spigot servers.', downloads: '12.4M', rating: 4.9, type: ['Paper', 'Spigot'] },
  { id: 2, name: 'LuckPerms', version: '5.4.134', category: 'Permissions', desc: 'A permissions plugin for Minecraft servers.', downloads: '9.1M', rating: 5.0, type: ['Paper', 'Fabric', 'Forge'] },
  { id: 3, name: 'Vault', version: '1.7.3', category: 'Economy', desc: 'Economy, permissions, and chat API plugin.', downloads: '7.8M', rating: 4.7, type: ['Paper', 'Spigot'] },
  { id: 4, name: 'WorldEdit', version: '7.3.6', category: 'Building', desc: 'In-game map editor and fixer. Select and edit terrain fast.', downloads: '11.2M', rating: 4.8, type: ['Paper', 'Fabric', 'Forge'] },
  { id: 5, name: 'GeyserMC', version: '2.4.2', category: 'Crossplay', desc: 'Allow Bedrock players to join Java servers.', downloads: '4.3M', rating: 4.9, type: ['Paper', 'EaglercraftXBungee'] },
  { id: 6, name: 'Dynmap', version: '3.7', category: 'Maps', desc: 'Real-time dynamic world map for your browser.', downloads: '3.9M', rating: 4.6, type: ['Paper', 'Forge', 'Fabric'] },
  { id: 7, name: 'CoreProtect', version: '22.4', category: 'Protection', desc: 'Fast, efficient block logging, rollback & restore plugin.', downloads: '5.5M', rating: 4.9, type: ['Paper'] },
  { id: 8, name: 'Multiverse-Core', version: '4.3.12', category: 'Worlds', desc: 'Create and manage multiple worlds on one server.', downloads: '6.1M', rating: 4.7, type: ['Paper', 'Spigot'] },
  { id: 9, name: 'EaglercraftXBungee Plugin', version: '1.3.0', category: 'Eaglercraft', desc: 'Core plugin for Eaglercraft WebSocket proxying.', downloads: '890K', rating: 4.8, type: ['EaglercraftXBungee'] },
  { id: 10, name: 'SkinsRestorer', version: '15.3.0', category: 'Cosmetics', desc: 'Restore skins for offline/Eaglercraft servers.', downloads: '4.2M', rating: 4.8, type: ['Paper', 'EaglercraftXBungee'] },
  { id: 11, name: 'ViaVersion', version: '5.0.3', category: 'Compatibility', desc: 'Allow newer client versions to connect to your server.', downloads: '8.0M', rating: 4.8, type: ['Paper', 'EaglercraftXBungee'] },
  { id: 12, name: 'Chunky', version: '1.4.28', category: 'Performance', desc: 'Pre-generate chunks quickly and efficiently.', downloads: '2.1M', rating: 4.9, type: ['Paper', 'Fabric'] },
];

const modpacks = [
  { id: 101, name: 'All the Mods 9', version: '0.4.68', loader: 'Forge', mc: '1.20.1', mods: 402, desc: 'Kitchen-sink modpack with hundreds of balanced mods.' },
  { id: 102, name: 'RLCraft', version: '2.9.3', loader: 'Forge', mc: '1.12.2', mods: 169, desc: 'Brutally difficult survival overhaul.' },
  { id: 103, name: 'Enigmatica 6', version: '1.8.0', loader: 'Forge', mc: '1.18.2', mods: 251, desc: 'Expert-mode tech and magic quest-driven modpack.' },
  { id: 104, name: 'Prominence II', version: '2.8.0', loader: 'Forge', mc: '1.20.1', mods: 310, desc: 'Adventure & RPG quest-heavy overhaul.' },
  { id: 105, name: 'Fabulously Optimized', version: '6.1.4', loader: 'Fabric', mc: '1.21.1', mods: 38, desc: 'Performance-first client-side optimization pack.' },
  { id: 106, name: 'Create: Above & Beyond', version: '1.0.9', loader: 'Forge', mc: '1.16.5', mods: 188, desc: 'Automation and engineering with the Create mod.' },
];

export default function ServerPluginsTab({ serverType }) {
  const [tab, setTab] = useState('plugins');
  const [search, setSearch] = useState('');
  const [installed, setInstalled] = useState({});
  const [installing, setInstalling] = useState(null);

  const install = (id) => {
    setInstalling(id);
    setTimeout(() => { setInstalled(p => ({ ...p, [id]: true })); setInstalling(null); }, 2000);
  };

  const filteredPlugins = allPlugins.filter(p => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase()) || p.desc.toLowerCase().includes(search.toLowerCase());
    return matchSearch;
  });

  const filteredMods = modpacks.filter(m =>
    m.name.toLowerCase().includes(search.toLowerCase()) || m.desc.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-4 max-w-3xl">
      <div>
        <h2 className="text-xl font-bold">Plugins & Modpacks</h2>
        <p className="text-sm text-muted-foreground">1-click install for your server</p>
      </div>

      {/* Sub-tabs */}
      <div className="flex gap-1 border-b border-border/30">
        {['plugins', 'modpacks'].map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2 text-sm font-medium capitalize border-b-2 -mb-px transition-colors ${tab === t ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'}`}
          >
            {t === 'plugins' ? 'Plugins' : 'Modpacks'}
          </button>
        ))}
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
        <Input
          placeholder={`Search ${tab}...`}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9 h-9 text-xs bg-secondary/30 border-border/40"
        />
      </div>

      {tab === 'plugins' && (
        <div className="grid gap-3">
          {filteredPlugins.map(plugin => (
            <div key={plugin.id} className="flex items-center gap-4 p-4 rounded-xl bg-card/50 border border-border/30 hover:border-border/50 transition-all">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                <Puzzle className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-semibold text-sm">{plugin.name}</span>
                  <span className="text-xs text-muted-foreground">v{plugin.version}</span>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-secondary/60 text-muted-foreground">{plugin.category}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-0.5 truncate">{plugin.desc}</p>
                <div className="flex items-center gap-3 mt-1">
                  <span className="text-xs text-muted-foreground/60">↓ {plugin.downloads}</span>
                  <span className="flex items-center gap-0.5 text-xs text-yellow-400"><Star className="w-3 h-3 fill-yellow-400" />{plugin.rating}</span>
                </div>
              </div>
              <Button
                size="sm"
                variant="ghost"
                className={`h-8 text-xs flex-shrink-0 ${installed[plugin.id] ? 'bg-green-600/20 text-green-400 border border-green-600/20' : 'bg-primary/10 text-primary border border-primary/20 hover:bg-primary/20'}`}
                disabled={installing === plugin.id}
                onClick={() => !installed[plugin.id] && install(plugin.id)}
              >
                {installing === plugin.id ? (
                  <div className="w-3.5 h-3.5 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
                ) : installed[plugin.id] ? (
                  <><Check className="w-3 h-3 mr-1" />Installed</>
                ) : (
                  <><Download className="w-3 h-3 mr-1" />Install</>
                )}
              </Button>
            </div>
          ))}
        </div>
      )}

      {tab === 'modpacks' && (
        <div className="grid gap-3">
          {filteredMods.map(pack => (
            <div key={pack.id} className="flex items-center gap-4 p-4 rounded-xl bg-card/50 border border-border/30 hover:border-border/50 transition-all">
              <div className="w-10 h-10 rounded-xl bg-orange-500/10 flex items-center justify-center flex-shrink-0">
                <span className="text-lg">📦</span>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-semibold text-sm">{pack.name}</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full border ${pack.loader === 'Forge' ? 'bg-orange-500/10 border-orange-500/20 text-orange-400' : 'bg-blue-500/10 border-blue-500/20 text-blue-400'}`}>{pack.loader}</span>
                  <span className="text-xs text-muted-foreground">{pack.mc}</span>
                  <span className="text-xs text-muted-foreground">{pack.mods} mods</span>
                </div>
                <p className="text-xs text-muted-foreground mt-0.5 truncate">{pack.desc}</p>
              </div>
              <Button
                size="sm"
                variant="ghost"
                className={`h-8 text-xs flex-shrink-0 ${installed[pack.id] ? 'bg-green-600/20 text-green-400 border border-green-600/20' : 'bg-primary/10 text-primary border border-primary/20 hover:bg-primary/20'}`}
                disabled={installing === pack.id}
                onClick={() => !installed[pack.id] && install(pack.id)}
              >
                {installing === pack.id ? (
                  <div className="w-3.5 h-3.5 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
                ) : installed[pack.id] ? (
                  <><Check className="w-3 h-3 mr-1" />Installed</>
                ) : (
                  <><Download className="w-3 h-3 mr-1" />Install</>
                )}
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}