import React, { useState, useEffect, useRef } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

function generateHistory(points, baseValue, variance) {
  return Array.from({ length: points }, (_, i) => ({
    i,
    cpu: Math.max(0, Math.min(100, baseValue + (Math.random() - 0.5) * variance * 2)),
    ram: Math.max(0, Math.min(100, (baseValue * 0.8) + (Math.random() - 0.5) * variance * 1.5)),
  }));
}

const RANGES = [
  { key: '1h', label: 'Last Hour', points: 60, interval: 'min', tickEvery: 10 },
  { key: '24h', label: '24 Hours', points: 48, interval: '30m', tickEvery: 6 },
  { key: '7d', label: '7 Days', points: 84, interval: '2h', tickEvery: 12 },
];

function makeLabels(range) {
  const now = Date.now();
  if (range.key === '1h') {
    return Array.from({ length: range.points }, (_, i) => {
      const t = new Date(now - (range.points - i) * 60000);
      return `${t.getHours().toString().padStart(2,'0')}:${t.getMinutes().toString().padStart(2,'0')}`;
    });
  }
  if (range.key === '24h') {
    return Array.from({ length: range.points }, (_, i) => {
      const t = new Date(now - (range.points - i) * 30 * 60000);
      return `${t.getHours().toString().padStart(2,'0')}:00`;
    });
  }
  // 7d
  return Array.from({ length: range.points }, (_, i) => {
    const t = new Date(now - (range.points - i) * 2 * 3600000);
    return `${(t.getMonth()+1)}/${t.getDate()} ${t.getHours().toString().padStart(2,'0')}h`;
  });
}

export default function ServerMonitoringTab({ server }) {
  const [activeRange, setActiveRange] = useState('1h');
  const [datasets, setDatasets] = useState(() => ({
    '1h': generateHistory(60, server.cpuUsage || 30, 20),
    '24h': generateHistory(48, server.cpuUsage || 30, 25),
    '7d': generateHistory(84, server.cpuUsage || 30, 30),
  }));

  const range = RANGES.find(r => r.key === activeRange);
  const rawData = datasets[activeRange];
  const labels = makeLabels(range);

  const chartData = rawData.map((d, i) => ({
    time: i % range.tickEvery === 0 ? labels[i] : '',
    timeLabel: labels[i],
    CPU: parseFloat(d.cpu.toFixed(1)),
    RAM: parseFloat(d.ram.toFixed(1)),
  }));

  // Live update for 1h
  useEffect(() => {
    if (activeRange !== '1h' || server.status !== 'online') return;
    const id = setInterval(() => {
      setDatasets(prev => {
        const old = prev['1h'];
        const last = old[old.length - 1];
        const next = {
          i: last.i + 1,
          cpu: Math.max(0, Math.min(100, last.cpu + (Math.random() - 0.5) * 8)),
          ram: Math.max(0, Math.min(100, last.ram + (Math.random() - 0.5) * 5)),
        };
        return { ...prev, '1h': [...old.slice(1), next] };
      });
    }, 3000);
    return () => clearInterval(id);
  }, [activeRange, server.status]);

  const current = chartData[chartData.length - 1];
  const ramPct = ((server.ramUsed / server.ramTotal) * 100).toFixed(1);

  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload?.length) return null;
    return (
      <div className="bg-card border border-border/50 rounded-lg px-3 py-2 text-xs shadow-xl">
        <p className="text-muted-foreground mb-1">{payload[0]?.payload?.timeLabel}</p>
        {payload.map(p => (
          <p key={p.name} style={{ color: p.color }}>{p.name}: {p.value}%</p>
        ))}
      </div>
    );
  };

  return (
    <div className="space-y-5 max-w-3xl">
      <div>
        <h2 className="text-xl font-bold">Monitoring</h2>
        <p className="text-sm text-muted-foreground">Real-time resource usage trends</p>
      </div>

      {/* Current stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'CPU Now', value: `${server.cpuUsage}%`, color: 'text-purple-400', bg: 'bg-purple-500/10' },
          { label: 'RAM Now', value: `${ramPct}%`, color: 'text-blue-400', bg: 'bg-blue-500/10' },
          { label: 'RAM Used', value: `${(server.ramUsed/1024).toFixed(1)}GB`, color: 'text-blue-300', bg: 'bg-blue-500/10' },
          { label: 'Status', value: server.status === 'online' ? 'Online' : 'Offline', color: server.status === 'online' ? 'text-green-400' : 'text-red-400', bg: server.status === 'online' ? 'bg-green-500/10' : 'bg-red-500/10' },
        ].map(s => (
          <div key={s.label} className={`p-3 rounded-xl border border-border/30 ${s.bg}`}>
            <div className="text-xs text-muted-foreground">{s.label}</div>
            <div className={`text-xl font-bold ${s.color}`}>{s.value}</div>
          </div>
        ))}
      </div>

      {/* Range selector */}
      <div className="flex gap-1 p-1 bg-secondary/40 rounded-lg w-fit">
        {RANGES.map(r => (
          <button
            key={r.key}
            onClick={() => setActiveRange(r.key)}
            className={`px-4 py-1.5 rounded-md text-xs font-medium transition-all ${activeRange === r.key ? 'bg-card text-foreground shadow' : 'text-muted-foreground hover:text-foreground'}`}
          >
            {r.label}
          </button>
        ))}
      </div>

      {/* CPU Chart */}
      <div className="p-4 rounded-xl bg-card/50 border border-border/30">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold">CPU & RAM Usage</h3>
          <div className="flex items-center gap-3 text-xs">
            <span className="flex items-center gap-1"><span className="w-3 h-0.5 bg-purple-400 inline-block" />CPU</span>
            <span className="flex items-center gap-1"><span className="w-3 h-0.5 bg-blue-400 inline-block" />RAM</span>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={chartData} margin={{ top: 5, right: 5, bottom: 5, left: -20 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(222 30% 18%)" />
            <XAxis dataKey="time" tick={{ fontSize: 10, fill: 'hsl(215 20% 55%)' }} interval={0} />
            <YAxis domain={[0, 100]} tick={{ fontSize: 10, fill: 'hsl(215 20% 55%)' }} tickFormatter={v => `${v}%`} />
            <Tooltip content={<CustomTooltip />} />
            <Line type="monotone" dataKey="CPU" stroke="hsl(262 83% 68%)" strokeWidth={2} dot={false} activeDot={{ r: 3 }} />
            <Line type="monotone" dataKey="RAM" stroke="hsl(217 91% 60%)" strokeWidth={2} dot={false} activeDot={{ r: 3 }} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {server.status !== 'online' && (
        <div className="p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20 text-xs text-yellow-400 text-center">
          Server is offline — live monitoring paused. Historical data shown.
        </div>
      )}
    </div>
  );
}