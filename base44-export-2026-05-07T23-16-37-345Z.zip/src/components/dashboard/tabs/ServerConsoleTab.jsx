import React, { useState, useRef, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Send, Play, Square, RotateCw, Filter } from 'lucide-react';

const sampleLogs = [
  { time: '21:43:07', level: 'INFO', msg: 'Player Steve issued server command: /effect Steve minecraft:saturation 1000000 10' },
  { time: '21:43:07', level: 'INFO', msg: '[Evokryn: Given Saturation (ID 23) * 10 to Steve for 1000000 seconds]' },
  { time: '21:46:09', level: 'INFO', msg: 'Player Steve issued server command: /clean Steve cobblestone' },
  { time: '21:46:21', level: 'INFO', msg: 'Player Steve issued server command: /clean Steve spidereye' },
  { time: '21:48:19', level: 'WARN', msg: "Can't keep up! Is the server overloaded? Running 2500ms behind." },
  { time: '21:48:19', level: 'INFO', msg: 'Player Steve issued server command: /gamerule mobGriefing false' },
  { time: '21:48:19', level: 'INFO', msg: '[Game rule has been updated]' },
  { time: '21:49:48', level: 'INFO', msg: 'Steve lost connection: Disconnected' },
  { time: '21:49:48', level: 'WARN', msg: '[Broadcast] Bye Steve! :(' },
  { time: '21:49:48', level: 'INFO', msg: 'TChat > [-] Steve has left the server' },
  { time: '21:50:12', level: 'ERROR', msg: 'Failed to load plugin XYZ: ClassNotFoundException' },
  { time: '21:51:00', level: 'INFO', msg: 'Alex joined the game' },
];

const levelColors = { INFO: 'text-foreground/70', WARN: 'text-orange-400', ERROR: 'text-red-400' };
const levelBracket = { INFO: 'text-blue-400', WARN: 'text-orange-400', ERROR: 'text-red-400' };

const FILTERS = [
  { key: 'all', label: 'All' },
  { key: 'ERROR', label: 'Errors' },
  { key: 'WARN', label: 'Warnings' },
  { key: 'join', label: 'Join/Leave' },
];

export default function ServerConsoleTab({ server, onStatusChange }) {
  const [command, setCommand] = useState('');
  const [logs, setLogs] = useState(sampleLogs);
  const [restarting, setRestarting] = useState(false);
  const [activeFilter, setActiveFilter] = useState('all');
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [logs, activeFilter]);

  const filteredLogs = logs.filter(log => {
    if (activeFilter === 'all') return true;
    if (activeFilter === 'ERROR') return log.level === 'ERROR';
    if (activeFilter === 'WARN') return log.level === 'WARN';
    if (activeFilter === 'join') return /joined|left|lost connection|has left/i.test(log.msg);
    return true;
  });

  const send = () => {
    if (!command.trim()) return;
    setLogs(p => [...p, { time: new Date().toLocaleTimeString('en', { hour12: false }), level: 'INFO', msg: `> ${command}` }]);
    setCommand('');
  };

  const handleToggle = () => {
    const next = server.status === 'online' ? 'offline' : 'online';
    onStatusChange(server.id, next);
    setLogs(p => [...p, { time: new Date().toLocaleTimeString('en', { hour12: false }), level: 'INFO', msg: next === 'offline' ? 'Server stopped.' : 'Server started.' }]);
  };

  const handleRestart = () => {
    if (restarting || server.status === 'offline') return;
    setRestarting(true);
    onStatusChange(server.id, 'starting');
    setLogs(p => [...p, { time: new Date().toLocaleTimeString('en', { hour12: false }), level: 'INFO', msg: 'Server restarting...' }]);
    setTimeout(() => {
      onStatusChange(server.id, 'online');
      setRestarting(false);
      setLogs(p => [...p, { time: new Date().toLocaleTimeString('en', { hour12: false }), level: 'INFO', msg: 'Server is online.' }]);
    }, 2000);
  };

  const errorCount = logs.filter(l => l.level === 'ERROR').length;
  const warnCount = logs.filter(l => l.level === 'WARN').length;

  return (
    <div className="flex flex-col h-[calc(100vh-160px)] max-w-3xl">
      <div className="p-4 rounded-xl bg-card/50 border border-border/30 flex flex-col flex-1 overflow-hidden gap-3">
        {/* Header */}
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded bg-green-500/10 border border-green-500/20 flex items-center justify-center font-mono text-green-400 text-xs">&gt;_</div>
            <span className="font-semibold text-sm">Server Console</span>
            <Badge className="bg-green-500/10 text-green-400 border-green-500/20 text-xs">● Connected</Badge>
          </div>
          <div className="flex gap-2">
            <Button size="sm" variant="ghost" className={`h-7 text-xs ${server.status === 'online' ? 'text-red-400 hover:bg-red-500/10' : 'text-green-400 hover:bg-green-500/10'}`} onClick={handleToggle}>
              {server.status === 'online' ? <Square className="w-3 h-3" /> : <Play className="w-3 h-3" />}
            </Button>
            <Button size="sm" variant="ghost" className="h-7 text-xs text-yellow-400 hover:bg-yellow-500/10" onClick={handleRestart} disabled={restarting || server.status === 'offline'}>
              <RotateCw className={`w-3 h-3 ${restarting ? 'animate-spin' : ''}`} />
            </Button>
          </div>
        </div>

        {/* Filter bar */}
        <div className="flex items-center gap-2 flex-wrap">
          <Filter className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
          {FILTERS.map(f => (
            <button
              key={f.key}
              onClick={() => setActiveFilter(f.key)}
              className={`px-2.5 py-1 rounded-md text-xs font-medium transition-all flex items-center gap-1 ${activeFilter === f.key ? 'bg-primary/15 text-primary border border-primary/20' : 'text-muted-foreground hover:text-foreground border border-transparent hover:border-border/30'}`}
            >
              {f.label}
              {f.key === 'ERROR' && errorCount > 0 && <span className="bg-red-500 text-white text-xs px-1 rounded-full">{errorCount}</span>}
              {f.key === 'WARN' && warnCount > 0 && <span className="bg-orange-500 text-white text-xs px-1 rounded-full">{warnCount}</span>}
            </button>
          ))}
        </div>

        {/* Log output */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto font-mono text-xs space-y-0.5 bg-background/60 rounded-lg p-3 min-h-0">
          {filteredLogs.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground/50 text-xs">No {activeFilter === 'all' ? '' : activeFilter} logs to show.</div>
          ) : filteredLogs.map((log, i) => (
            <div key={i} className="flex gap-2 leading-5">
              <span className="text-muted-foreground/40 flex-shrink-0">[{log.time}</span>
              <span className={`flex-shrink-0 ${levelBracket[log.level]}`}>{log.level}]:</span>
              <span className={`break-all ${levelColors[log.level]}`}>{log.msg}</span>
            </div>
          ))}
        </div>

        {/* Input */}
        <div className="flex gap-2">
          <Input
            placeholder="Enter command..."
            value={command}
            onChange={e => setCommand(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && send()}
            className="font-mono text-xs bg-background/60 border-border/30 h-9"
          />
          <Button size="sm" onClick={send} variant="ghost" className="h-9 px-3 text-muted-foreground hover:text-primary">
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}