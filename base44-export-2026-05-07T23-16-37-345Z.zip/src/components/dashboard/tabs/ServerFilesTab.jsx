import React, { useState, useRef } from 'react';
import { FolderOpen, File, ChevronRight, Upload, Folder, FileText, Archive, Settings, Trash2, Pencil, X, Save, ChevronLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ROOT_FILES = [
  { name: 'cache', type: 'folder' },
  { name: 'debug', type: 'folder' },
  { name: 'logs', type: 'folder' },
  { name: 'plugins', type: 'folder' },
  { name: 'world', type: 'folder' },
  { name: 'world_nether', type: 'folder' },
  { name: 'banned-ips.json', type: 'file', size: '2.0 KB', ext: 'json', content: '[\n\n]' },
  { name: 'banned-players.json', type: 'file', size: '12.24 KB', ext: 'json', content: '[\n\n]' },
  { name: 'bukkit.yml', type: 'file', size: '11.26 KB', ext: 'yml', content: 'settings:\n  allow-end: true\n  warn-on-overload: true\n  permissions-file: permissions.yml\n  update-folder: update\n  ping-packet-limit: 100\n  use-exact-login-location: false\n  plugin-profiling: false\n  connection-throttle: 4000\n  query-plugins: true\n  deprecated-verbose: default\n  shutdown-message: Server closed' },
  { name: 'commands.yml', type: 'file', size: '119 KB', ext: 'yml', content: 'command-block-overrides: []\nignore-vanilla-permissions: false\naliases:\n  icanhasbukkit:\n    - version $1-' },
  { name: 'ops.json', type: 'file', size: '1.14 KB', ext: 'json', content: '[\n  {\n    "uuid": "00000000-0000-0000-0000-000000000001",\n    "name": "YourName",\n    "level": 4,\n    "bypassesPlayerLimit": false\n  }\n]' },
  { name: 'server.properties', type: 'file', size: '500 B', ext: 'properties', content: 'server-port=25565\nmax-players=20\ndifficulty=easy\ngamemode=survival\nmotd=A Diorite Hosting+ Server\nonline-mode=true\nwhite-list=false\npvp=true\nspawn-protection=16\nview-distance=10\nmax-world-size=29999984\nallow-flight=false\nspawn-animals=true\nspawn-monsters=true\nspawn-npcs=true' },
  { name: 'spigot.yml', type: 'file', size: '4.04 KB', ext: 'yml', content: 'config-version: 12\nmessages:\n  whitelist: You are not whitelisted on this server!\n  unknown-command: Unknown command. Type "/help" for help.\nstats:\n  disable-saving: false\n  forced-stats: {}\ncommands:\n  replace-commands:\n    - setblock\n    - summon' },
  { name: 'whitelist.json', type: 'file', size: '2.0 KB', ext: 'json', content: '[\n\n]' },
];

const extIcon = (ext) => {
  if (ext === 'yml' || ext === 'yaml' || ext === 'properties') return <Settings className="w-4 h-4 text-yellow-400" />;
  if (ext === 'json') return <FileText className="w-4 h-4 text-blue-400" />;
  if (ext === 'jar') return <Archive className="w-4 h-4 text-orange-400" />;
  return <File className="w-4 h-4 text-muted-foreground" />;
};

export default function ServerFilesTab() {
  const [files, setFiles] = useState(ROOT_FILES);
  const [search, setSearch] = useState('');
  const [editingFile, setEditingFile] = useState(null);
  const [editContent, setEditContent] = useState('');
  const [savedMsg, setSavedMsg] = useState(false);
  const fileInputRef = useRef(null);

  const filtered = files.filter(f => f.name.toLowerCase().includes(search.toLowerCase()));

  const openEditor = (f) => {
    if (f.type === 'folder') return;
    setEditingFile(f);
    setEditContent(f.content || '');
  };

  const saveEdit = () => {
    setFiles(prev => prev.map(f => f.name === editingFile.name ? { ...f, content: editContent } : f));
    setSavedMsg(true);
    setTimeout(() => setSavedMsg(false), 2000);
  };

  const deleteFile = (name) => {
    setFiles(prev => prev.filter(f => f.name !== name));
    if (editingFile?.name === name) setEditingFile(null);
  };

  const handleUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const newFile = {
      name: file.name,
      type: 'file',
      size: `${(file.size / 1024).toFixed(1)} KB`,
      ext: file.name.split('.').pop(),
      content: '',
    };
    setFiles(prev => [...prev, newFile]);
  };

  if (editingFile) {
    return (
      <div className="flex flex-col h-[calc(100vh-200px)] max-w-3xl space-y-3">
        <div className="flex items-center gap-3">
          <button onClick={() => setEditingFile(null)} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <ChevronLeft className="w-4 h-4" />
            Back
          </button>
          <span className="text-sm font-semibold truncate flex-1">{editingFile.name}</span>
          <Button size="sm" className={`h-8 gap-1.5 text-xs ${savedMsg ? 'bg-green-600 hover:bg-green-700 text-white border-0' : 'bg-primary hover:bg-primary/90 text-white border-0'}`} onClick={saveEdit}>
            <Save className="w-3.5 h-3.5" />
            {savedMsg ? 'Saved!' : 'Save'}
          </Button>
        </div>
        <textarea
          className="flex-1 w-full font-mono text-xs bg-background border border-border/30 rounded-xl p-4 resize-none focus:outline-none focus:border-primary/50 text-foreground"
          value={editContent}
          onChange={(e) => setEditContent(e.target.value)}
          spellCheck={false}
        />
      </div>
    );
  }

  return (
    <div className="space-y-4 max-w-3xl">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold">File Manager</h2>
          <p className="text-sm text-muted-foreground">Browse and edit your server files</p>
        </div>
        <div className="flex gap-2">
          <input ref={fileInputRef} type="file" className="hidden" onChange={handleUpload} />
          <Button size="sm" className="bg-primary/10 text-primary border border-primary/20 hover:bg-primary/20 gap-1.5 text-xs" variant="ghost" onClick={() => fileInputRef.current?.click()}>
            <Upload className="w-3.5 h-3.5" />
            Upload File
          </Button>
        </div>
      </div>

      {/* Path bar */}
      <div className="flex items-center gap-1.5 text-xs text-muted-foreground px-3 py-2 rounded-lg bg-secondary/30 border border-border/30">
        <FolderOpen className="w-3.5 h-3.5" />
        <span>home</span>
        <ChevronRight className="w-3 h-3" />
        <span className="text-foreground font-medium">server</span>
      </div>

      <input
        placeholder="Search files..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="w-full px-3 py-2 text-xs rounded-lg bg-secondary/30 border border-border/30 outline-none focus:border-primary/40 transition-colors"
      />

      <div className="rounded-xl bg-card/50 border border-border/30 overflow-hidden">
        <div className="grid grid-cols-[1fr,auto,auto] px-4 py-2 border-b border-border/20 text-xs text-muted-foreground font-semibold">
          <span>Name</span>
          <span className="mr-8">Size</span>
          <span>Actions</span>
        </div>
        <div className="divide-y divide-border/20">
          {filtered.map((f, i) => (
            <div key={i} className="grid grid-cols-[1fr,auto,auto] items-center px-4 py-2.5 hover:bg-secondary/30 transition-colors group">
              <button className="flex items-center gap-3 min-w-0 text-left" onClick={() => openEditor(f)}>
                {f.type === 'folder'
                  ? <Folder className="w-4 h-4 text-primary/70 flex-shrink-0" />
                  : extIcon(f.ext)
                }
                <span className="text-sm truncate group-hover:text-primary transition-colors">{f.name}</span>
              </button>
              <span className="text-xs text-muted-foreground mr-4">{f.size || '—'}</span>
              <div className="flex gap-1">
                {f.type !== 'folder' && (
                  <button onClick={() => openEditor(f)} className="p-1 rounded hover:bg-primary/10 text-muted-foreground hover:text-primary transition-colors">
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                )}
                <button onClick={() => deleteFile(f.name)} className="p-1 rounded hover:bg-red-500/10 text-muted-foreground hover:text-red-400 transition-colors">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}