import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Save, AlertTriangle, Copy, Check, HardDrive } from 'lucide-react';

export default function ServerSettingsTab({ server }) {
  const [name, setName] = useState(server.name);
  const [motd, setMotd] = useState('A Diorite Hosting+ server');
  const [maxPlayers, setMaxPlayers] = useState(server.playersMax);
  const [autoShutdown, setAutoShutdown] = useState(false);
  const [autoSave, setAutoSave] = useState(true);
  const [saved, setSaved] = useState(false);
  const [copiedSftp, setCopiedSftp] = useState('');

  const slug = server.address?.replace('play.', '').replace('.diorite.hosting', '') || 'server';
  const sftp = {
    host: `sftp.diorite.hosting`,
    port: '2022',
    user: slug,
    pass: `dh_${Math.random().toString(36).slice(2, 10).toUpperCase()}`,
  };

  const copySftp = (val, key) => {
    navigator.clipboard.writeText(val);
    setCopiedSftp(key);
    setTimeout(() => setCopiedSftp(''), 2000);
  };

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-5 max-w-2xl">
      <div>
        <h2 className="text-xl font-bold">Server Settings</h2>
        <p className="text-sm text-muted-foreground">Configure your server settings</p>
      </div>

      {/* Appearance */}
      <div className="p-5 rounded-xl bg-card/50 border border-border/30 space-y-4">
        <h3 className="font-semibold text-sm text-primary/80 uppercase tracking-wide text-xs">Appearance</h3>
        <div className="space-y-3">
          <div>
            <label className="text-sm font-medium block mb-1.5">Server Name</label>
            <Input value={name} onChange={(e) => setName(e.target.value)} className="bg-secondary/30 border-border/40" />
          </div>
          <div>
            <label className="text-sm font-medium block mb-1.5">Description / MOTD</label>
            <Input value={motd} onChange={(e) => setMotd(e.target.value)} className="bg-secondary/30 border-border/40" />
            <p className="text-xs text-muted-foreground mt-1">Shown in the server list.</p>
          </div>
          <div>
            <label className="text-sm font-medium block mb-1.5">Max Players</label>
            <Input type="number" value={maxPlayers} onChange={(e) => setMaxPlayers(e.target.value)} className="bg-secondary/30 border-border/40 w-32" />
          </div>
        </div>
      </div>

      {/* Server Optimization */}
      <div className="p-5 rounded-xl bg-card/50 border border-border/30 space-y-4">
        <h3 className="font-semibold text-xs text-primary/80 uppercase tracking-wide">Server Optimization</h3>
        {[
          { label: 'Auto-Shutdown', desc: 'Automatically stop the server when no players are online.', value: autoShutdown, set: setAutoShutdown },
          { label: 'Auto-Save', desc: 'Automatically save the world every 5 minutes.', value: autoSave, set: setAutoSave },
        ].map(item => (
          <div key={item.label} className="flex items-start justify-between gap-4">
            <div>
              <div className="text-sm font-medium">{item.label}</div>
              <div className="text-xs text-muted-foreground mt-0.5">{item.desc}</div>
            </div>
            <button
              onClick={() => item.set(!item.value)}
              className={`relative w-11 h-6 rounded-full transition-colors flex-shrink-0 mt-0.5 ${item.value ? 'bg-primary' : 'bg-muted'}`}
            >
              <span className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${item.value ? 'left-6' : 'left-1'}`} />
            </button>
          </div>
        ))}
      </div>

      <Button
        className={`w-full gap-2 ${saved ? 'bg-green-600 hover:bg-green-700' : 'bg-primary hover:bg-primary/90'} text-white border-0`}
        onClick={handleSave}
      >
        <Save className="w-4 h-4" />
        {saved ? 'Settings Saved!' : 'Save Settings'}
      </Button>

      {/* SFTP Access */}
      <div className="p-5 rounded-xl bg-card/50 border border-border/30 space-y-3">
        <div className="flex items-center gap-2 mb-1">
          <HardDrive className="w-4 h-4 text-primary" />
          <h3 className="font-semibold text-xs text-primary/80 uppercase tracking-wide">SFTP Access (FileZilla)</h3>
        </div>
        <p className="text-xs text-muted-foreground">Use FileZilla or WinSCP to drag-and-drop world files directly.</p>
        {[
          { label: 'Host', val: sftp.host, key: 'host' },
          { label: 'Port', val: sftp.port, key: 'port' },
          { label: 'Username', val: sftp.user, key: 'user' },
          { label: 'Password', val: sftp.pass, key: 'pass' },
        ].map(row => (
          <div key={row.key} className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground w-20 flex-shrink-0">{row.label}</span>
            <code className="flex-1 text-xs font-mono bg-background border border-border/30 rounded px-2 py-1 text-foreground/80">{row.val}</code>
            <button onClick={() => copySftp(row.val, row.key)} className="p-1.5 rounded hover:bg-primary/10 text-muted-foreground hover:text-primary transition-colors flex-shrink-0">
              {copiedSftp === row.key ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
        ))}
        <p className="text-xs text-yellow-400/80">⚠️ Password resets on every page reload. Connect immediately after copying.</p>
      </div>

      {/* Danger Zone */}
      <div className="p-5 rounded-xl bg-red-500/5 border border-red-500/20 space-y-3">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-red-400" />
          <h3 className="font-semibold text-sm text-red-400">Danger Zone</h3>
        </div>
        <p className="text-xs text-muted-foreground">Deleting your server is irreversible. All data, worlds, and configurations will be permanently lost.</p>
        <Button size="sm" variant="outline" className="border-red-500/40 text-red-400 hover:bg-red-500/10 text-xs">
          Delete Server
        </Button>
      </div>
    </div>
  );
}