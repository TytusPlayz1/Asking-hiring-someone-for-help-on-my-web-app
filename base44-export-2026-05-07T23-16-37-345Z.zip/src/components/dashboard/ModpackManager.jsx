import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Layers, Check, Download, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';

const modpacks = [
  { id: 1, name: 'All the Mods 9', loader: 'Forge', version: '1.20.1', mods: 402, desc: 'The kitchen-sink modpack with hundreds of balanced mods.' },
  { id: 2, name: 'RLCraft', loader: 'Forge', version: '1.12.2', mods: 169, desc: 'Brutally difficult survival overhaul. Not for the faint-hearted.' },
  { id: 3, name: 'Enigmatica 6', loader: 'Forge', version: '1.18.2', mods: 251, desc: 'Expert-mode tech and magic quest-driven modpack.' },
  { id: 4, name: 'Prominence II', loader: 'Forge', version: '1.20.1', mods: 310, desc: 'Adventure & RPG quest-heavy overhaul.' },
  { id: 5, name: 'Fabulously Optimized', loader: 'Fabric', version: '1.21.1', mods: 38, desc: 'Performance-first client-side optimization pack.' },
  { id: 6, name: 'Create: Above & Beyond', loader: 'Forge', version: '1.16.5', mods: 188, desc: 'Automation and engineering with the Create mod.' },
  { id: 7, name: 'Sky Factory 4', loader: 'Forge', version: '1.12.2', mods: 204, desc: 'Skyblock with tech, magic, and automation.' },
  { id: 8, name: 'Better MC', loader: 'Fabric', version: '1.20.1', mods: 145, desc: 'Vanilla+ experience with quality-of-life improvements.' },
];

export default function ModpackManager() {
  const [installed, setInstalled] = useState({});
  const [installing, setInstalling] = useState(null);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('All');

  const handleInstall = (id) => {
    setInstalling(id);
    setTimeout(() => {
      setInstalled(prev => ({ ...prev, [id]: true }));
      setInstalling(null);
    }, 2200);
  };

  const filtered = modpacks.filter(m => {
    const matchSearch = m.name.toLowerCase().includes(search.toLowerCase()) || m.desc.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === 'All' || m.loader === filter;
    return matchSearch && matchFilter;
  });

  return (
    <div className="space-y-4">
      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input
            placeholder="Search modpacks..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 h-8 text-xs bg-secondary/30 border-border/40"
          />
        </div>
        {['All', 'Forge', 'Fabric'].map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${filter === f ? 'bg-primary/10 border-primary/30 text-primary' : 'border-border/30 text-muted-foreground hover:text-foreground'}`}
          >
            {f}
          </button>
        ))}
      </div>

      <div className="grid gap-3">
        {filtered.map((pack) => (
          <div key={pack.id} className="flex items-center gap-4 p-4 rounded-xl bg-secondary/20 border border-border/30 hover:border-border/50 transition-all">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Layers className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-semibold text-sm">{pack.name}</span>
                <span className={`text-xs px-2 py-0.5 rounded-full border ${pack.loader === 'Forge' ? 'bg-orange-500/10 border-orange-500/20 text-orange-400' : 'bg-blue-500/10 border-blue-500/20 text-blue-400'}`}>
                  {pack.loader}
                </span>
                <span className="text-xs text-muted-foreground">{pack.version}</span>
                <span className="text-xs text-muted-foreground">{pack.mods} mods</span>
              </div>
              <p className="text-xs text-muted-foreground mt-0.5 truncate">{pack.desc}</p>
            </div>
            <Button
              size="sm"
              className={`h-8 text-xs flex-shrink-0 ${installed[pack.id] ? 'bg-green-600/20 text-green-400 border border-green-600/20 hover:bg-green-600/30' : 'bg-primary/10 text-primary border border-primary/20 hover:bg-primary/20'}`}
              variant="ghost"
              disabled={installing === pack.id}
              onClick={() => !installed[pack.id] && handleInstall(pack.id)}
            >
              {installing === pack.id ? (
                <><div className="w-3 h-3 border-2 border-primary/30 border-t-primary rounded-full animate-spin mr-1.5" />Installing...</>
              ) : installed[pack.id] ? (
                <><Check className="w-3 h-3 mr-1" />Installed</>
              ) : (
                <><Download className="w-3 h-3 mr-1" />1-Click Install</>
              )}
            </Button>
          </div>
        ))}
        {filtered.length === 0 && (
          <div className="text-center py-10 text-muted-foreground text-sm">No modpacks found.</div>
        )}
      </div>
    </div>
  );
}