import React, { useEffect, useState } from 'react';

export default function ResourceBar({ value, max, label, colorClass = 'bg-primary', animate = false }) {
  const [display, setDisplay] = useState(value);

  useEffect(() => {
    if (!animate) { setDisplay(value); return; }
    // Simulate slight live fluctuation ±5%
    const interval = setInterval(() => {
      const jitter = (Math.random() - 0.5) * 10;
      setDisplay(Math.max(0, Math.min(max, Math.round(value + jitter))));
    }, 2000);
    return () => clearInterval(interval);
  }, [value, max, animate]);

  const pct = max > 0 ? Math.min(100, Math.round((display / max) * 100)) : 0;
  const barColor = pct > 85 ? 'bg-red-500' : pct > 65 ? 'bg-yellow-500' : colorClass;

  return (
    <div>
      <div className="flex justify-between items-center mb-1">
        <span className="text-xs text-muted-foreground">{label}</span>
        <span className="text-xs font-mono font-semibold">{pct}%</span>
      </div>
      <div className="h-1.5 rounded-full bg-secondary/60 overflow-hidden">
        <div
          className={`h-full rounded-full transition-all duration-700 ${barColor}`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}