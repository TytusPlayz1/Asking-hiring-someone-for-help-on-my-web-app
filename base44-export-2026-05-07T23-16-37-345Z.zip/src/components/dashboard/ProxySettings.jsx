import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Save, Globe, RefreshCw, Shield, Wifi } from 'lucide-react';

const defaultConfig = `server_connect_timeout: 5000
remote_ping_timeout: 5000

listeners:
  - host: 0.0.0.0:25577
    query_port: 25577
    motd: '&1Diorite Eaglercraft Proxy'
    max_players: 100
    tab_list: GLOBAL_PING
    query_enabled: false
    proxy_protocol: false
    ping_passthrough: false
    priorities:
      - lobby

servers:
  lobby:
    motd: '&1Just another BungeeCord server'
    address: localhost:25565
    restricted: false

groups:
  admin:
    - bungeecord.command.alert
    - bungeecord.command.end
    - bungeecord.command.ip
    - bungeecord.command.reload

permissions:
  default:
    - bungeecord.command.server
    - bungeecord.command.list

connection_throttle: 4000
connection_throttle_limit: 3
online_mode: false
forge_support: false
player_limit: -1
ip_forward: true
network_compression_threshold: 256
log_commands: false
stats: ''`;

export default function ProxySettings({ server }) {
  const [config, setConfig] = useState(defaultConfig);
  const [saved, setSaved] = useState(false);
  const [proxyMode, setProxyMode] = useState('BungeeCord');
  const [wssEnabled, setWssEnabled] = useState(true);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-4">
      {/* Quick Toggles */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-4 rounded-xl bg-secondary/20 border border-border/30">
          <div className="flex items-center gap-2 mb-3">
            <Globe className="w-4 h-4 text-purple-400" />
            <span className="text-sm font-semibold">Proxy Software</span>
          </div>
          <div className="flex gap-2">
            {['BungeeCord', 'Waterfall'].map(m => (
              <button
                key={m}
                onClick={() => setProxyMode(m)}
                className={`flex-1 py-1.5 text-xs rounded-lg border transition-all ${proxyMode === m ? 'bg-purple-500/10 border-purple-500/30 text-purple-400' : 'border-border/30 text-muted-foreground hover:text-foreground'}`}
              >
                {m}
              </button>
            ))}
          </div>
        </div>

        <div className="p-4 rounded-xl bg-secondary/20 border border-border/30">
          <div className="flex items-center gap-2 mb-3">
            <Wifi className="w-4 h-4 text-blue-400" />
            <span className="text-sm font-semibold">WSS (Secure WS)</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">{wssEnabled ? 'Enabled' : 'Disabled'}</span>
            <button
              onClick={() => setWssEnabled(!wssEnabled)}
              className={`relative w-10 h-5 rounded-full transition-colors ${wssEnabled ? 'bg-blue-500' : 'bg-muted'}`}
            >
              <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all ${wssEnabled ? 'left-5' : 'left-0.5'}`} />
            </button>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-secondary/20 border border-border/30">
          <div className="flex items-center gap-2 mb-3">
            <Shield className="w-4 h-4 text-green-400" />
            <span className="text-sm font-semibold">Online Mode</span>
          </div>
          <div className="text-xs text-muted-foreground">
            Eaglercraft requires <span className="text-green-400 font-semibold">offline mode</span> (online_mode: false in config).
          </div>
        </div>
      </div>

      {/* Config Editor */}
      <div className="rounded-xl bg-background border border-border/30 overflow-hidden">
        <div className="flex items-center justify-between px-4 py-2 border-b border-border/30">
          <span className="text-xs font-mono text-muted-foreground">config.yml — {proxyMode}</span>
          <div className="flex gap-2">
            <Button size="sm" variant="ghost" className="h-7 text-xs gap-1.5 text-muted-foreground hover:text-foreground" onClick={() => setConfig(defaultConfig)}>
              <RefreshCw className="w-3 h-3" />Reset
            </Button>
            <Button size="sm" className={`h-7 text-xs gap-1.5 ${saved ? 'bg-green-600 hover:bg-green-700' : 'bg-primary hover:bg-primary/90'} text-white border-0`} onClick={handleSave}>
              <Save className="w-3 h-3" />
              {saved ? 'Saved!' : 'Save'}
            </Button>
          </div>
        </div>
        <textarea
          value={config}
          onChange={(e) => setConfig(e.target.value)}
          className="w-full h-80 p-4 font-mono text-xs bg-transparent text-foreground/80 resize-none outline-none leading-relaxed"
          spellCheck={false}
        />
      </div>
    </div>
  );
}