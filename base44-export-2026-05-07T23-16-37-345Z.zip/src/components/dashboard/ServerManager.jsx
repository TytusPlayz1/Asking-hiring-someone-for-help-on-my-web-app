import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  ArrowLeft, LayoutDashboard, Terminal, Settings, FolderOpen,
  Puzzle, Archive, Users, Play, Square, RotateCw, X, Copy, Activity, Clock, Crown
} from 'lucide-react';
import ServerDashboardTab from './tabs/ServerDashboardTab';
import ServerConsoleTab from './tabs/ServerConsoleTab';
import ServerFilesTab from './tabs/ServerFilesTab';
import ServerPluginsTab from './tabs/ServerPluginsTab';
import ServerBackupsTab from './tabs/ServerBackupsTab';
import ServerTeamTab from './tabs/ServerTeamTab';
import ServerSettingsTab from './tabs/ServerSettingsTab';
import ServerMonitoringTab from './tabs/ServerMonitoringTab';
import ServerPlayersTab from './tabs/ServerPlayersTab';
import ServerSchedulerTab from './tabs/ServerSchedulerTab';

const statusStyles = {
  online: 'bg-green-500/10 text-green-400 border-green-500/20',
  offline: 'bg-muted text-muted-foreground border-border/30',
  starting: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
};

const navSections = [
  {
    label: 'OVERVIEW',
    items: [
      { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
      { id: 'console', label: 'Console', icon: Terminal },
      { id: 'monitoring', label: 'Monitoring', icon: Activity },
      { id: 'settings', label: 'Settings', icon: Settings },
    ],
  },
  {
    label: 'MANAGEMENT',
    items: [
      { id: 'files', label: 'File Manager', icon: FolderOpen },
      { id: 'plugins', label: 'Plugins', icon: Puzzle },
      { id: 'players', label: 'Players', icon: Crown },
      { id: 'scheduler', label: 'Scheduler', icon: Clock },
      { id: 'backups', label: 'Backups', icon: Archive },
      { id: 'team', label: 'Team', icon: Users },
    ],
  },
];

export default function ServerManager({ server, onBack, onStatusChange }) {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [restarting, setRestarting] = useState(false);
  const [copied, setCopied] = useState(false);

  const isOnline = server.status === 'online';

  const handleToggle = () => {
    const next = isOnline ? 'offline' : 'online';
    onStatusChange(server.id, next);
  };

  const handleRestart = () => {
    if (!isOnline || restarting) return;
    setRestarting(true);
    onStatusChange(server.id, 'starting');
    setTimeout(() => { onStatusChange(server.id, 'online'); setRestarting(false); }, 2000);
  };

  const copyAddress = () => {
    navigator.clipboard.writeText(server.address);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const tabContent = {
    dashboard: <ServerDashboardTab server={server} onStatusChange={onStatusChange} />,
    console: <ServerConsoleTab server={server} onStatusChange={onStatusChange} />,
    monitoring: <ServerMonitoringTab server={server} />,
    files: <ServerFilesTab />,
    plugins: <ServerPluginsTab serverType={server.type} />,
    players: <ServerPlayersTab server={server} />,
    scheduler: <ServerSchedulerTab />,
    backups: <ServerBackupsTab />,
    team: <ServerTeamTab />,
    settings: <ServerSettingsTab server={server} />,
  };

  const Sidebar = () => (
    <div className="flex flex-col h-full bg-card border-r border-border/30 w-64 flex-shrink-0">
      {/* Server identity */}
      <div className="p-5 border-b border-border/30">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary/30 to-accent/30 flex items-center justify-center text-lg flex-shrink-0">
            ⛏️
          </div>
          <div className="min-w-0">
            <div className="font-bold text-sm truncate">{server.name}</div>
            <div className="text-xs text-muted-foreground truncate">{server.address}</div>
          </div>
          <button onClick={copyAddress} className="flex-shrink-0 p-1 rounded hover:bg-secondary transition-colors">
            <Copy className="w-3.5 h-3.5 text-muted-foreground" />
          </button>
        </div>
        <Badge className={`${statusStyles[server.status]} text-xs w-full justify-center py-1`}>
          {isOnline ? '● Running' : server.status === 'starting' ? '● Starting...' : '● Offline'}
        </Badge>
        <div className="flex gap-2 mt-3">
          <Button
            size="sm"
            className={`flex-1 h-8 text-xs border-0 ${isOnline ? 'bg-red-600 hover:bg-red-700 text-white' : 'bg-green-600 hover:bg-green-700 text-white'}`}
            onClick={handleToggle}
          >
            {isOnline ? <><Square className="w-3 h-3 mr-1" />Stop</> : <><Play className="w-3 h-3 mr-1" />Start</>}
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="flex-1 h-8 text-xs border-border/40 gap-1"
            onClick={handleRestart}
            disabled={!isOnline || restarting}
          >
            <RotateCw className={`w-3 h-3 ${restarting ? 'animate-spin' : ''}`} />
            Restart
          </Button>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto p-3 space-y-4">
        {navSections.map(section => (
          <div key={section.label}>
            <div className="text-xs text-muted-foreground/60 font-semibold px-2 mb-1.5 tracking-wider">{section.label}</div>
            <div className="space-y-0.5">
              {section.items.map(item => (
                <button
                  key={item.id}
                  onClick={() => { setActiveTab(item.id); setSidebarOpen(false); }}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-colors text-left ${
                    activeTab === item.id
                      ? 'bg-primary/15 text-primary font-medium'
                      : 'text-muted-foreground hover:text-foreground hover:bg-secondary/50'
                  }`}
                >
                  <item.icon className="w-4 h-4 flex-shrink-0" />
                  {item.label}
                  {item.badge && (
                    <span className="ml-auto text-xs px-1.5 py-0.5 rounded-full bg-primary/20 text-primary">{item.badge}</span>
                  )}
                </button>
              ))}
            </div>
          </div>
        ))}
      </nav>

      {/* Back */}
      <div className="p-3 border-t border-border/30">
        <button onClick={onBack} className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-secondary/50 transition-colors">
          <ArrowLeft className="w-4 h-4" />
          Back to Servers
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex h-[calc(100vh-64px)]">
      {/* Desktop sidebar */}
      <div className="hidden md:flex">
        <Sidebar />
      </div>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="md:hidden fixed inset-0 z-40 flex">
          <div className="absolute inset-0 bg-black/50" onClick={() => setSidebarOpen(false)} />
          <div className="relative z-50 h-full">
            <Sidebar />
          </div>
          <button onClick={() => setSidebarOpen(false)} className="absolute top-4 right-4 z-50 p-1 rounded-lg bg-card">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile top bar */}
        <div className="md:hidden flex items-center gap-3 px-4 py-3 border-b border-border/30 bg-card/50">
          <button onClick={() => setSidebarOpen(true)} className="p-1.5 rounded-lg hover:bg-secondary">
            <LayoutDashboard className="w-4 h-4" />
          </button>
          <span className="font-semibold text-sm flex-1 truncate">{server.name}</span>
          <Badge className={`${statusStyles[server.status]} text-xs`}>{server.status}</Badge>
        </div>

        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          {tabContent[activeTab]}
        </div>
      </div>
    </div>
  );
}