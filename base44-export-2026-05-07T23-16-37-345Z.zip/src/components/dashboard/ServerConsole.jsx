import React, { useState, useRef, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Send, ArrowLeft, Play, Square, RotateCw, Terminal, Package, Settings } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import ResourceBar from './ResourceBar';
import ModpackManager from './ModpackManager';
import ProxySettings from './ProxySettings';

const sampleLogs = [
  { time: '12:00:01', level: 'INFO', msg: '[Server] Starting minecraft server version 1.21.1' },
  { time: '12:00:03', level: 'INFO', msg: '[Server] Loading properties...' },
  { time: '12:00:03', level: 'INFO', msg: '[Server] Default game type: SURVIVAL' },
  { time: '12:00:05', level: 'INFO', msg: '[Server] Preparing level "world"' },
  { time: '12:00:08', level: 'INFO', msg: '[Server] Preparing spawn area: 84%' },
  { time: '12:00:09', level: 'INFO', msg: '[Server] Done (8.234s)! For help, type "help"' },
  { time: '12:01:22', level: 'INFO', msg: '[Server] Player Steve joined the game' },
  { time: '12:03:45', level: 'WARN', msg: "[Server] Can't keep up! Is the server overloaded?" },
  { time: '12:04:01', level: 'INFO', msg: '[Server] Player Alex joined the game' },
];

const statusStyles = {
  online: 'bg-green-500/10 text-green-400 border-green-500/20',
  offline: 'bg-muted text-muted-foreground border-border/30',
  starting: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
};

const levelColors = { INFO: 'text-blue-400', WARN: 'text-yellow-400', ERROR: 'text-red-400' };

const isEaglercraft = (server) => server.type === 'EaglercraftXBungee';

export default function ServerConsole({ server, onBack, onStatusChange }) {
  const [command, setCommand] = useState('');
  const [logs, setLogs] = useState(sampleLogs);
  const [restarting, setRestarting] = useState(false);
  const [activeTab, setActiveTab] = useState('console');
  const scrollRef = useRef(null);

  const tabs = [
    { id: 'console', label: 'Console', icon: Terminal },
    { id: 'modpacks', label: 'Modpacks', icon: Package },
    ...(isEaglercraft(server) ? [{ id: 'proxy', label: 'Proxy Settings', icon: Settings }] : []),
  ];

  useEffect(() => {
    if (scrollRef.current && activeTab === 'console') {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs, activeTab]);

  const sendCommand = () => {
    if (!command.trim()) return;
    setLogs(prev => [...prev, { time: new Date().toLocaleTimeString('en', { hour12: false }), level: 'INFO', msg: `> ${command}` }]);
    setCommand('');
  };

  const handleToggle = () => {
    const next = server.status === 'online' ? 'offline' : 'online';
    onStatusChange(server.id, next);
    setLogs(prev => [...prev, { time: new Date().toLocaleTimeString('en', { hour12: false }), level: 'INFO', msg: next === 'offline' ? '[Server] Server stopped.' : '[Server] Server started.' }]);
  };

  const handleRestart = () => {
    if (server.status === 'offline' || restarting) return;
    setRestarting(true);
    onStatusChange(server.id, 'starting');
    setLogs(prev => [...prev, { time: new Date().toLocaleTimeString('en', { hour12: false }), level: 'INFO', msg: '[Server] Restarting...' }]);
    setTimeout(() => {
      onStatusChange(server.id, 'online');
      setRestarting(false);
      setLogs(prev => [...prev, { time: new Date().toLocaleTimeString('en', { hour12: false }), level: 'INFO', msg: '[Server] Server online.' }]);
    }, 2000);
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center gap-3 mb-4 flex-wrap">
        <Button variant="ghost" size="icon" onClick={onBack} className="h-8 w-8 flex-shrink-0">
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="flex-1 min-w-0">
          <h2 className="text-lg font-bold truncate">{server.name}</h2>
          <p className="text-xs text-muted-foreground">{server.type} · {server.version} · {server.address}</p>
        </div>
        <Badge className={`${statusStyles[server.status]} text-xs flex-shrink-0`}>{server.status}</Badge>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" className={`h-8 text-xs border-border/30 ${server.status === 'online' ? 'hover:text-red-400' : 'hover:text-green-400'}`} onClick={handleToggle}>
            {server.status === 'online' ? <><Square className="w-3 h-3 mr-1" />Stop</> : <><Play className="w-3 h-3 mr-1" />Start</>}
          </Button>
          <Button size="sm" variant="outline" className="h-8 text-xs border-border/30 hover:text-yellow-400" onClick={handleRestart} disabled={restarting || server.status === 'offline'}>
            <RotateCw className={`w-3 h-3 ${restarting ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </div>

      {/* Live resource bars */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
        <div className="col-span-2 sm:col-span-1 p-3 rounded-lg bg-secondary/50 border border-border/30 space-y-2">
          <ResourceBar label="RAM" value={server.ramUsed} max={server.ramTotal} colorClass="bg-blue-500" animate={server.status === 'online'} />
        </div>
        <div className="col-span-2 sm:col-span-1 p-3 rounded-lg bg-secondary/50 border border-border/30">
          <ResourceBar label="CPU" value={server.cpuUsage} max={100} colorClass="bg-purple-500" animate={server.status === 'online'} />
        </div>
        <div className="p-3 rounded-lg bg-secondary/50 border border-border/30">
          <div className="text-xs text-muted-foreground mb-0.5">Disk</div>
          <div className="text-sm font-semibold">{server.diskUsed}/{server.diskTotal} GB</div>
        </div>
        <div className="p-3 rounded-lg bg-secondary/50 border border-border/30">
          <div className="text-xs text-muted-foreground mb-0.5">Players</div>
          <div className="text-sm font-semibold">{server.playersOnline}/{server.playersMax}</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-3 border-b border-border/30">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-1.5 px-4 py-2 text-xs font-medium transition-colors border-b-2 -mb-px ${activeTab === tab.id ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'}`}
          >
            <tab.icon className="w-3.5 h-3.5" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab content */}
      {activeTab === 'console' && (
        <div className="flex-1 flex flex-col rounded-xl bg-background border border-border/30 overflow-hidden min-h-0">
          <div className="px-4 py-2 border-b border-border/30 text-xs font-medium text-muted-foreground font-mono">Console Output</div>
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 font-mono text-xs space-y-1">
            {logs.map((log, i) => (
              <div key={i} className="flex gap-2">
                <span className="text-muted-foreground/50 flex-shrink-0">{log.time}</span>
                <span className={`flex-shrink-0 ${levelColors[log.level] || 'text-foreground'}`}>[{log.level}]</span>
                <span className="text-foreground/80 break-all">{log.msg}</span>
              </div>
            ))}
          </div>
          <div className="flex gap-2 p-3 border-t border-border/30">
            <Input
              placeholder="Enter command..."
              value={command}
              onChange={(e) => setCommand(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && sendCommand()}
              className="font-mono text-xs bg-transparent border-border/30 h-8"
            />
            <Button size="sm" onClick={sendCommand} className="h-8 px-3 bg-primary hover:bg-primary/90">
              <Send className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
      )}

      {activeTab === 'modpacks' && (
        <div className="flex-1 overflow-y-auto">
          <ModpackManager />
        </div>
      )}

      {activeTab === 'proxy' && (
        <div className="flex-1 overflow-y-auto">
          <ProxySettings server={server} />
        </div>
      )}
    </div>
  );
}