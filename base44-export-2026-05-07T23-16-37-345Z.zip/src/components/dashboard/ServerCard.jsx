import React, { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Play, Square, RotateCw, Users, Terminal, Trash2, MapPin } from 'lucide-react';
import DeleteServerDialog from './DeleteServerDialog';
import ResourceBar from './ResourceBar';

const statusStyles = {
  online: 'bg-green-500/10 text-green-400 border-green-500/20',
  offline: 'bg-muted text-muted-foreground border-border/30',
  starting: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
};

export default function ServerCard({ server, onManage, onStatusChange, onDelete }) {
  const [restarting, setRestarting] = useState(false);
  const [showDelete, setShowDelete] = useState(false);

  const handleToggle = (e) => {
    e.stopPropagation();
    onStatusChange(server.id, server.status === 'online' ? 'offline' : 'online');
  };

  const handleRestart = (e) => {
    e.stopPropagation();
    if (server.status === 'offline') return;
    setRestarting(true);
    onStatusChange(server.id, 'starting');
    setTimeout(() => {
      onStatusChange(server.id, 'online');
      setRestarting(false);
    }, 2000);
  };

  const isOnline = server.status === 'online';

  return (
    <>
      <div className={`p-5 rounded-xl bg-card/50 border transition-all group flex flex-col gap-3 ${isOnline ? 'enchanted-card hover:border-purple-500/60' : 'border-border/30 hover:border-primary/20'}`}>
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="min-w-0">
            <h3 className="font-semibold truncate group-hover:text-primary transition-colors text-sm">{server.name}</h3>
            <p className="text-xs text-muted-foreground mt-0.5">{server.type} · {server.version}</p>
            {server.node && (
              <div className="flex items-center gap-1 mt-1">
                <MapPin className="w-3 h-3 text-muted-foreground/60" />
                <span className="text-xs text-muted-foreground/60">{server.node}</span>
              </div>
            )}
          </div>
          <Badge className={`${statusStyles[server.status]} text-xs flex-shrink-0 ml-2`}>
            {server.status}
          </Badge>
        </div>

        {/* Live resource bars */}
        <div className="space-y-2">
          <ResourceBar
            label="RAM"
            value={server.ramUsed}
            max={server.ramTotal}
            colorClass="bg-blue-500"
            animate={isOnline}
          />
          <ResourceBar
            label="CPU"
            value={server.cpuUsage}
            max={100}
            colorClass="bg-purple-500"
            animate={isOnline}
          />
        </div>

        {/* Players */}
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <Users className="w-3.5 h-3.5" />
          <span>{server.playersOnline}/{server.playersMax} players</span>
          <span className="ml-auto text-muted-foreground/50">{server.diskUsed}/{server.diskTotal} GB</span>
        </div>

        {/* Manage Button */}
        <Button
          size="sm"
          onClick={() => onManage(server)}
          className="w-full h-8 text-xs bg-primary/10 hover:bg-primary/20 text-primary border border-primary/20 hover:border-primary/40"
          variant="ghost"
        >
          <Terminal className="w-3.5 h-3.5 mr-1.5" />
          Manage / Console
        </Button>

        {/* Controls */}
        <div className="flex gap-2">
          <Button
            size="sm"
            variant="outline"
            className={`flex-1 h-8 text-xs border-border/30 ${isOnline ? 'hover:border-red-500/40 hover:text-red-400' : 'hover:border-green-500/40 hover:text-green-400'}`}
            onClick={handleToggle}
          >
            {isOnline ? <><Square className="w-3 h-3 mr-1" />Stop</> : <><Play className="w-3 h-3 mr-1" />Start</>}
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="h-8 text-xs border-border/30 hover:border-yellow-500/40 hover:text-yellow-400"
            onClick={handleRestart}
            disabled={restarting || !isOnline}
            title="Restart"
          >
            <RotateCw className={`w-3 h-3 ${restarting ? 'animate-spin' : ''}`} />
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="h-8 text-xs border-border/30 hover:border-red-500/40 hover:text-red-400"
            onClick={(e) => { e.stopPropagation(); setShowDelete(true); }}
            title="Delete server"
          >
            <Trash2 className="w-3 h-3" />
          </Button>
        </div>
      </div>

      {showDelete && (
        <DeleteServerDialog
          serverName={server.name}
          onConfirm={() => { setShowDelete(false); onDelete(server.id); }}
          onCancel={() => setShowDelete(false)}
        />
      )}
    </>
  );
}