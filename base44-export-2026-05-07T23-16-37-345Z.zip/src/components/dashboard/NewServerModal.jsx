import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { X, Server, Globe, Layers, MapPin, Shield, Check, Puzzle, Crown } from 'lucide-react';

// Java version auto-selection
const getJavaVersion = (version) => {
  const v = parseFloat(version);
  if (v <= 1.12) return 'Java 8';
  if (v <= 1.16) return 'Java 11';
  if (v <= 1.17) return 'Java 16';
  if (v <= 1.20) return 'Java 17';
  return 'Java 21';
};

const serverTypes = [
  { id: 'Paper', label: 'Java (Paper)', icon: Server, desc: 'Best for plugins & vanilla', color: 'text-blue-400', border: 'border-blue-500/40', bg: 'bg-blue-500/10' },
  { id: 'Forge', label: 'Java (Forge)', icon: Layers, desc: 'Mod packs & Forge mods', color: 'text-orange-400', border: 'border-orange-500/40', bg: 'bg-orange-500/10' },
  { id: 'Bedrock', label: 'Bedrock', icon: Globe, desc: 'Mobile, console & Windows', color: 'text-green-400', border: 'border-green-500/40', bg: 'bg-green-500/10' },
  { id: 'EaglercraftXBungee', label: 'Eaglercraft', icon: Globe, desc: 'Browser-based via WSS', color: 'text-purple-400', border: 'border-purple-500/40', bg: 'bg-purple-500/10' },
];

const versionsByType = {
  Paper: [
    { v: '1.21.4', label: '1.21.4', desc: 'Latest - modern content', available: true },
    { v: '1.21.1', label: '1.21.1', desc: 'Stable release', available: true },
    { v: '1.20.1', label: '1.20.1', desc: 'Most popular, great plugin support', available: true },
    { v: '1.19.4', label: '1.19.4', desc: 'Classic with good plugin support', available: true },
    { v: '1.16.5', label: '1.16.5', desc: 'Legacy - Nether Update', available: true },
    { v: '1.12.2', label: '1.12.2', desc: 'Legacy Java 8', available: true },
  ],
  Forge: [
    { v: '1.21.1', label: '1.21.1', desc: 'Modern Forge modding', available: true },
    { v: '1.20.1', label: '1.20.1', desc: 'Most mods available', available: true },
    { v: '1.18.2', label: '1.18.2', desc: 'Stable Forge', available: true },
    { v: '1.16.5', label: '1.16.5', desc: 'Classic modpacks', available: true },
    { v: '1.12.2', label: '1.12.2', desc: 'Legacy - Java 8', available: true },
  ],
  Bedrock: [
    { v: '1.21.50', label: '1.21.50', desc: 'Latest Bedrock', available: true },
    { v: '1.20.80', label: '1.20.80', desc: 'Stable release', available: true },
  ],
  EaglercraftXBungee: [
    { v: '1.8.8', label: '1.8.8', desc: 'Classic PvP - Java 8, WSS auto', available: true },
    { v: '1.12.2', label: '1.12.2', desc: 'Extended features - Java 8', available: true },
  ],
};

const pluginLibrary = [
  { id: 'account-security', name: 'Account Security', category: 'Security', desc: 'Required Eaglercraft plugin for account/skin login. Prevents account hijacking.', recommended: true, eaglerOnly: false, icon: '🔒' },
  { id: 'essentialsx', name: 'EssentialsX', category: 'Utility', desc: 'Essential server commands & utilities including economy, kits, warps, homes, and more.', recommended: false, eaglerOnly: false, icon: '⚡' },
  { id: 'skinsrestorer', name: 'SkinsRestorer', category: 'Cosmetics', desc: 'Allows players to change their in-game skin and set premium Minecraft skin accounts.', recommended: false, eaglerOnly: false, icon: '🎨' },
  { id: 'worldedit', name: 'WorldEdit', category: 'Building', desc: 'In-game map editor for building, terraforming, and map creation.', recommended: false, eaglerOnly: false, icon: '🔨' },
  { id: 'viaversion', name: 'ViaVersion', category: 'Compatibility', desc: 'Allow newer Minecraft versions to connect to your server.', recommended: true, eaglerOnly: false, icon: '🔗' },
  { id: 'skript', name: 'Skript', category: 'Scripting', desc: 'Create custom plugins and commands using a simple scripting language without Java knowledge.', recommended: false, eaglerOnly: false, icon: '📜' },
  { id: 'luckperms', name: 'LuckPerms', category: 'Permissions', desc: 'Advanced permissions management system for granular control.', recommended: false, eaglerOnly: false, icon: '🛡️' },
  { id: 'geyser', name: 'GeyserMC', category: 'Crossplay', desc: 'Allow Bedrock players to join your Java server.', recommended: false, eaglerOnly: false, icon: '🌉' },
];

const nodes = [
  { id: 'us-east', label: 'North America (East)', flag: '🇺🇸', ping: '12ms', city: 'New York', coords: { x: '22%', y: '38%' } },
  { id: 'us-west', label: 'North America (West)', flag: '🇺🇸', ping: '28ms', city: 'Los Angeles', coords: { x: '10%', y: '42%' } },
  { id: 'eu-west', label: 'Europe (West)', flag: '🇬🇧', ping: '45ms', city: 'London', coords: { x: '46%', y: '28%' } },
  { id: 'eu-central', label: 'Europe (Central)', flag: '🇩🇪', ping: '52ms', city: 'Frankfurt', coords: { x: '50%', y: '30%' } },
  { id: 'asia-sg', label: 'Asia (Southeast)', flag: '🇸🇬', ping: '110ms', city: 'Singapore', coords: { x: '74%', y: '60%' } },
  { id: 'asia-jp', label: 'Asia (East)', flag: '🇯🇵', ping: '135ms', city: 'Tokyo', coords: { x: '82%', y: '35%' } },
];

const TOTAL_STEPS = 5;

export default function NewServerModal({ onClose, onCreate }) {
  const [step, setStep] = useState(1);
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');
  const [selectedType, setSelectedType] = useState('Paper');
  const [selectedVersion, setSelectedVersion] = useState('1.21.4');
  const [selectedNode, setSelectedNode] = useState('us-east');
  const [selectedPlugins, setSelectedPlugins] = useState(['account-security', 'viaversion']);
  const [motd, setMotd] = useState('');

  const slug = name.trim().toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 20);
  const address = slug ? `play.${slug}.diorite.hosting` : 'play.[name].diorite.hosting';
  const javaVersion = getJavaVersion(selectedVersion);
  const isEagler = selectedType === 'EaglercraftXBungee';

  const handleTypeSelect = (typeId) => {
    setSelectedType(typeId);
    setSelectedVersion(versionsByType[typeId][0].v);
    // Auto-add account-security for Eaglercraft
    if (typeId === 'EaglercraftXBungee') {
      setSelectedPlugins(p => p.includes('account-security') ? p : [...p, 'account-security']);
    }
  };

  const togglePlugin = (id) => {
    setSelectedPlugins(p => p.includes(id) ? p.filter(x => x !== id) : [...p, id]);
  };

  const handleCreate = () => {
    if (!name.trim()) return;
    const node = nodes.find(n => n.id === selectedNode);
    onCreate({
      name: name.trim(),
      type: selectedType,
      version: selectedVersion,
      node: `${node.flag} ${node.city}`,
      javaVersion,
      wss: isEagler,
      plugins: selectedPlugins,
      status: 'offline',
      address,
      ramUsed: 0, ramTotal: 2048,
      cpuUsage: 0,
      diskUsed: 0, diskTotal: 10,
      playersOnline: 0, playersMax: 20,
    });
    onClose();
  };

  const stepLabels = ['Name', 'Version', 'Location', 'Plugins', 'MOTD'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <div
        className="relative z-10 w-full max-w-lg rounded-2xl bg-card border border-border/50 shadow-2xl flex flex-col max-h-[90vh]"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-border/30 flex-shrink-0">
          <div>
            <h2 className="text-lg font-bold">Create Free Server</h2>
            <div className="flex items-center gap-1.5 mt-2">
              {stepLabels.map((label, i) => (
                <div key={i} className="flex items-center gap-1">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-all ${i + 1 < step ? 'bg-green-500 text-white' : i + 1 === step ? 'bg-primary text-white' : 'bg-muted text-muted-foreground'}`}>
                    {i + 1 < step ? <Check className="w-3 h-3" /> : i + 1}
                  </div>
                  {i < stepLabels.length - 1 && <div className={`w-5 h-0.5 rounded ${i + 1 < step ? 'bg-green-500' : 'bg-muted'}`} />}
                </div>
              ))}
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-secondary transition-colors flex-shrink-0">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5">

          {/* Step 1: Name */}
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold mb-1">Name Your Server</h3>
                <p className="text-xs text-muted-foreground mb-3">Let's set up the basics</p>
              </div>
              <div>
                <label className="text-sm font-medium block mb-1.5">Server Name</label>
                <Input
                  placeholder="e.g. MySurvivalSMP"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="bg-secondary/30 border-border/40"
                  autoFocus
                />
                {name.trim() && (
                  <>
                    <p className="text-xs text-green-400 mt-1.5 flex items-center gap-1"><Check className="w-3 h-3" />This name is available!</p>
                    <p className="text-xs text-muted-foreground mt-0.5 font-mono">🌐 Your server IP: <span className="text-primary">{address}</span></p>
                  </>
                )}
              </div>
              <div>
                <label className="text-sm font-medium block mb-1.5">Description <span className="text-muted-foreground font-normal">(Optional)</span></label>
                <textarea
                  placeholder="Describe your server (only visible to you)..."
                  value={desc}
                  onChange={e => setDesc(e.target.value)}
                  maxLength={100}
                  rows={3}
                  className="w-full px-3 py-2 text-sm rounded-lg bg-secondary/30 border border-border/40 focus:outline-none focus:border-primary/50 resize-none text-foreground placeholder:text-muted-foreground"
                />
                <p className="text-xs text-muted-foreground text-right">{desc.length}/100</p>
              </div>
              <div>
                <label className="text-sm font-medium block mb-2">Server Type</label>
                <div className="grid grid-cols-2 gap-2">
                  {serverTypes.map(t => (
                    <button key={t.id} onClick={() => handleTypeSelect(t.id)}
                      className={`p-3 rounded-xl border text-left transition-all ${selectedType === t.id ? `${t.border} ${t.bg}` : 'border-border/30 hover:border-border/60 bg-secondary/20'}`}>
                      <t.icon className={`w-4 h-4 mb-1.5 ${selectedType === t.id ? t.color : 'text-muted-foreground'}`} />
                      <div className="text-xs font-semibold">{t.label}</div>
                      <div className="text-xs text-muted-foreground">{t.desc}</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Step 2: Version */}
          {step === 2 && (
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold mb-1">Choose Minecraft Version</h3>
                <p className="text-xs text-muted-foreground">Your server's backend version. Players on any client version can join if you install ViaVersion later.</p>
              </div>
              <div className="space-y-2">
                {versionsByType[selectedType].map(ver => (
                  <button key={ver.v} onClick={() => setSelectedVersion(ver.v)}
                    className={`w-full flex items-center gap-3 p-3 rounded-xl border text-left transition-all ${selectedVersion === ver.v ? 'border-primary/40 bg-primary/10' : ver.available ? 'border-border/30 hover:border-border/60 bg-secondary/20' : 'border-border/20 bg-secondary/10 opacity-50 cursor-not-allowed'}`}
                    disabled={!ver.available}
                  >
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold flex-shrink-0 ${selectedVersion === ver.v ? 'bg-primary text-white' : 'bg-secondary text-muted-foreground'}`}>
                      {ver.v.split('.').slice(0, 2).join('.')}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-sm">{selectedType} {ver.v}</div>
                      <div className="text-xs text-muted-foreground">{ver.desc}</div>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <div className="text-xs text-muted-foreground/60">{getJavaVersion(ver.v)}</div>
                      {isEagler && <div className="text-xs text-purple-400">WSS 🔒</div>}
                    </div>
                  </button>
                ))}
              </div>
              <div className="p-3 rounded-lg bg-secondary/30 border border-border/20 text-xs space-y-1">
                <div className="flex justify-between"><span className="text-muted-foreground">Auto Java Runtime</span><span className="text-green-400 font-semibold">{javaVersion} ✓</span></div>
                {isEagler && <div className="flex justify-between"><span className="text-muted-foreground">SSL/WSS</span><span className="text-green-400 font-semibold">Auto-configured ✓</span></div>}
                {isEagler && <div className="flex justify-between"><span className="text-muted-foreground">Memory Leak Fix</span><span className="text-green-400 font-semibold">Applied ✓</span></div>}
              </div>
            </div>
          )}

          {/* Step 3: Node Location */}
          {step === 3 && (
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold mb-1 flex items-center gap-2"><MapPin className="w-4 h-4 text-primary" />Select Server Location</h3>
                <p className="text-xs text-muted-foreground">Pick the node closest to your players for the best latency.</p>
              </div>

              {/* World map visual */}
              <div className="relative h-32 rounded-xl bg-secondary/30 border border-border/30 overflow-hidden">
                <div className="absolute inset-0 flex items-center justify-center text-4xl opacity-10">🗺️</div>
                <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 to-green-900/20" />
                {nodes.map(n => (
                  <button
                    key={n.id}
                    onClick={() => setSelectedNode(n.id)}
                    style={{ left: n.coords.x, top: n.coords.y }}
                    className="absolute transform -translate-x-1/2 -translate-y-1/2"
                    title={`${n.flag} ${n.city} ~${n.ping}`}
                  >
                    <div className={`w-3 h-3 rounded-full border-2 transition-all ${selectedNode === n.id ? 'bg-primary border-white scale-150' : 'bg-muted-foreground/60 border-border hover:bg-primary/60 hover:scale-125'}`} />
                    {selectedNode === n.id && (
                      <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-card border border-border/50 rounded px-1.5 py-0.5 text-xs whitespace-nowrap font-semibold shadow-lg">
                        {n.flag} {n.city}
                      </div>
                    )}
                  </button>
                ))}
              </div>

              <div className="grid gap-2">
                {nodes.map(n => (
                  <button key={n.id} onClick={() => setSelectedNode(n.id)}
                    className={`flex items-center gap-3 p-3 rounded-xl border text-left transition-all ${selectedNode === n.id ? 'border-primary/40 bg-primary/10' : 'border-border/30 hover:border-border/60 bg-secondary/20'}`}>
                    <span className="text-xl">{n.flag}</span>
                    <div className="flex-1">
                      <div className="text-sm font-semibold">{n.city}</div>
                      <div className="text-xs text-muted-foreground">{n.label}</div>
                    </div>
                    <div className={`text-xs font-mono ${selectedNode === n.id ? 'text-primary' : 'text-muted-foreground'}`}>~{n.ping}</div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 4: Plugins */}
          {step === 4 && (
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold mb-1 flex items-center gap-2"><Puzzle className="w-4 h-4 text-primary" />Choose Your Plugins</h3>
                <p className="text-xs text-muted-foreground">Pre-install plugins for your server. You can always add more later.</p>
                <p className="text-xs text-primary mt-1">{selectedPlugins.length} plugin{selectedPlugins.length !== 1 ? 's' : ''} selected</p>
              </div>
              <div className="space-y-2">
                {pluginLibrary.map(plugin => {
                  const selected = selectedPlugins.includes(plugin.id);
                  const required = isEagler && plugin.id === 'account-security';
                  return (
                    <button key={plugin.id} onClick={() => !required && togglePlugin(plugin.id)}
                      className={`w-full flex items-start gap-3 p-3 rounded-xl border text-left transition-all ${selected ? 'border-primary/40 bg-primary/5' : 'border-border/30 hover:border-border/60 bg-secondary/20'} ${required ? 'cursor-default' : ''}`}>
                      <span className="text-xl flex-shrink-0 mt-0.5">{plugin.icon}</span>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-semibold text-sm">{plugin.name}</span>
                          {plugin.recommended && <span className="text-xs px-1.5 py-0.5 rounded-full bg-yellow-500/10 border border-yellow-500/20 text-yellow-400">Recommended</span>}
                          {required && <span className="text-xs px-1.5 py-0.5 rounded-full bg-green-500/10 border border-green-500/20 text-green-400">Required</span>}
                          <span className="text-xs text-muted-foreground">{plugin.category}</span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{plugin.desc}</p>
                      </div>
                      <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center flex-shrink-0 mt-0.5 transition-all ${selected ? 'bg-primary border-primary' : 'border-border/50'}`}>
                        {selected && <Check className="w-3 h-3 text-white" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Step 5: MOTD / Summary */}
          {step === 5 && (
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold mb-1">Customize MOTD</h3>
                <p className="text-xs text-muted-foreground">Design how your server appears in the server list.</p>
              </div>

              {/* MOTD preview */}
              <div className="p-4 rounded-xl bg-gray-900 border border-border/40 font-mono text-sm">
                <div className="text-white text-xs mb-1 opacity-60">{address}</div>
                <div className="text-yellow-300 font-bold">{motd || 'An Eaglercraft Server'}</div>
                <div className="text-gray-400 text-xs">Powered by Diorite Hosting+</div>
              </div>

              <div>
                <label className="text-sm font-medium block mb-1.5">Server MOTD</label>
                <Input
                  placeholder="An Eaglercraft Server"
                  value={motd}
                  onChange={e => setMotd(e.target.value)}
                  className="bg-secondary/30 border-border/40"
                />
              </div>

              {/* Final summary */}
              <div className="p-3 rounded-xl bg-secondary/30 border border-border/20 text-xs space-y-2">
                <div className="font-semibold text-sm mb-2">Deployment Summary</div>
                <div className="flex justify-between"><span className="text-muted-foreground">Server IP</span><span className="font-mono text-primary">{address}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Type</span><span>{selectedType}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Version</span><span>{selectedVersion}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Java Runtime</span><span className="text-green-400">{javaVersion} (auto)</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Node</span><span>{nodes.find(n => n.id === selectedNode)?.flag} {nodes.find(n => n.id === selectedNode)?.city}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Plugins</span><span>{selectedPlugins.length} selected</span></div>
                {isEagler && <div className="flex justify-between"><span className="text-muted-foreground">SSL/WSS</span><span className="text-green-400">Auto-configured ✓</span></div>}
                <div className="flex justify-between"><span className="text-muted-foreground">Monthly Cost</span><span className="text-green-400 font-bold">$0.00</span></div>
              </div>
            </div>
          )}
        </div>

        {/* Footer nav */}
        <div className="flex gap-3 p-5 border-t border-border/30 flex-shrink-0">
          {step > 1 && <Button variant="outline" className="border-border/50" onClick={() => setStep(s => s - 1)}>← Back</Button>}
          {step < TOTAL_STEPS ? (
            <Button
              className="flex-1 bg-gradient-to-r from-primary to-accent hover:opacity-90 text-white border-0"
              disabled={step === 1 && !name.trim()}
              onClick={() => setStep(s => s + 1)}
            >
              Continue →
            </Button>
          ) : (
            <Button
              className="flex-1 bg-gradient-to-r from-green-500 to-emerald-600 hover:opacity-90 text-white border-0"
              disabled={!name.trim()}
              onClick={handleCreate}
            >
              🚀 Deploy Server
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}