import React from 'react';
import { motion } from 'framer-motion';
import {
  Server, Globe, Shield, Cpu, HardDrive, Layers,
  Terminal, Lock, Zap, ArrowRight, Monitor, Gamepad2
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';

const highlights = [
  {
    icon: Server,
    title: 'Pterodactyl Panel',
    description: 'The gold standard in game server management. Full web-based control with file manager, console, task scheduler, and granular subuser permissions. Every server runs in an isolated Docker container for maximum security.',
    color: 'from-blue-500 to-blue-600',
  },
  {
    icon: Globe,
    title: 'Eaglercraft Support',
    description: 'Run an EaglercraftXBungee proxy alongside your server so players can join from any web browser — no downloads needed. We handle the WebSocket configuration, SSL certificates, and proxy networking for you.',
    color: 'from-purple-500 to-purple-600',
  },
  {
    icon: Layers,
    title: 'Full Mod & Plugin Support',
    description: 'Forge, Fabric, Spigot, Paper, Purpur, BungeeCord, Velocity — we support every major server type. Upload mods directly through the panel, or use our one-click modpack installer for popular packs.',
    color: 'from-cyan-500 to-cyan-600',
  },
];

const specs = [
  { icon: Cpu, label: 'AMD Ryzen 9 7950X', sub: 'Up to 5.7 GHz boost clock' },
  { icon: HardDrive, label: 'NVMe Gen4 SSDs', sub: 'Up to 7,000 MB/s read speed' },
  { icon: Shield, label: '1Tbps DDoS Protection', sub: 'Always-on, zero-latency mitigation' },
  { icon: Lock, label: 'Automated Backups', sub: 'Scheduled with one-click restore' },
  { icon: Terminal, label: 'Full Root Console', sub: 'Execute any command in real-time' },
  { icon: Zap, label: 'Instant Provisioning', sub: 'Server ready in under 30 seconds' },
];

const serverTypes = [
  { icon: Gamepad2, name: 'Java Edition', desc: 'Vanilla, Spigot, Paper, Purpur' },
  { icon: Monitor, name: 'Bedrock Edition', desc: 'Via GeyserMC crossplay bridge' },
  { icon: Globe, name: 'Eaglercraft', desc: 'Browser-based via WebSocket proxy' },
  { icon: Layers, name: 'Modded (Forge)', desc: 'All Forge versions, Java 8–21' },
  { icon: Layers, name: 'Modded (Fabric)', desc: 'All Fabric versions with Loader' },
  { icon: Server, name: 'Proxy Networks', desc: 'BungeeCord, Velocity, Waterfall' },
];

export default function Features() {
  return (
    <div className="py-20 lg:py-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-20">
          <h1 className="text-4xl sm:text-5xl font-black mb-4">
            Built for
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent"> Performance</span>
          </h1>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Enterprise-grade infrastructure designed specifically for Minecraft servers.
          </p>
        </div>

        {/* Key Highlights */}
        <div className="space-y-6 mb-28">
          {highlights.map((item, i) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, x: i % 2 === 0 ? -30 : 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="flex flex-col md:flex-row items-start gap-6 p-8 rounded-2xl bg-card/50 border border-border/30"
            >
              <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${item.color} flex items-center justify-center flex-shrink-0`}>
                <item.icon className="w-7 h-7 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{item.description}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Hardware Specs */}
        <div className="mb-28">
          <h2 className="text-3xl font-bold text-center mb-12">
            Hardware
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent"> Specifications</span>
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {specs.map((spec, i) => (
              <motion.div
                key={spec.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: i * 0.06 }}
                className="p-5 rounded-xl bg-card/50 border border-border/30 flex items-start gap-4"
              >
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <spec.icon className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h4 className="font-semibold text-sm">{spec.label}</h4>
                  <p className="text-xs text-muted-foreground mt-0.5">{spec.sub}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Supported Server Types */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-center mb-12">
            Supported
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent"> Server Types</span>
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {serverTypes.map((type, i) => (
              <motion.div
                key={type.name}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: i * 0.05 }}
                className="p-5 rounded-xl bg-card/50 border border-border/30 hover:border-primary/20 transition-colors"
              >
                <type.icon className="w-6 h-6 text-primary mb-3" />
                <h4 className="font-semibold text-sm mb-1">{type.name}</h4>
                <p className="text-xs text-muted-foreground">{type.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center">
          <Link to="/dashboard">
            <Button size="lg" className="bg-gradient-to-r from-green-500 to-emerald-600 hover:opacity-90 text-white border-0 px-8 h-12 text-base font-semibold">
              Create Free Server
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}