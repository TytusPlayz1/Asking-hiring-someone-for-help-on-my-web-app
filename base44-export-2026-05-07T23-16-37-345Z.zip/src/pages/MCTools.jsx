import React, { useState, useEffect, useRef } from 'react';
import { Terminal, User, Hammer, ExternalLink, Copy, Check, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const tools = [
  { id: 'command', label: 'Command Lab', icon: Terminal },
  { id: 'skin', label: 'Skin & UUID Lookup', icon: User },
  { id: 'mcstacker', label: 'MCStacker', icon: Hammer },
];

// Simple NBT-style command builder
function CommandLab() {
  const [mode, setMode] = useState('give');
  const [player, setPlayer] = useState('@p');
  const [item, setItem] = useState('diamond_sword');
  const [amount, setAmount] = useState('1');
  const [enchant, setEnchant] = useState('sharpness 5');
  const [copied, setCopied] = useState(false);
  const [version, setVersion] = useState('modern');

  const modernCmd = `/give ${player} ${item}{Enchantments:[{id:"${enchant.split(' ')[0]}",lvl:${enchant.split(' ')[1] || 1}}]} ${amount}`;
  const legacyCmd = `/give ${player} ${item} ${amount} 0 {ench:[{id:16,lvl:${enchant.split(' ')[1] || 1}}]}`;
  const cmd = version === 'modern' ? modernCmd : legacyCmd;

  const copy = () => {
    navigator.clipboard.writeText(cmd);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-4 max-w-2xl">
      <div>
        <h2 className="text-xl font-bold mb-1">Command Lab</h2>
        <p className="text-sm text-muted-foreground">Generate /give commands with enchantments for your server console.</p>
      </div>

      {/* Version toggle */}
      <div className="flex gap-1 bg-secondary/50 rounded-lg p-1 w-fit">
        {['modern', 'legacy'].map(v => (
          <button key={v} onClick={() => setVersion(v)}
            className={`px-4 py-1.5 rounded-md text-xs font-semibold transition-all capitalize ${version === v ? 'bg-primary text-white' : 'text-muted-foreground hover:text-foreground'}`}>
            {v === 'modern' ? 'Modern (1.13+)' : 'Legacy (1.8.8)'}
          </button>
        ))}
      </div>

      <div className="grid sm:grid-cols-2 gap-3">
        <div>
          <label className="text-xs font-medium text-muted-foreground mb-1 block">Player / Target</label>
          <Input value={player} onChange={e => setPlayer(e.target.value)} placeholder="@p or PlayerName" className="bg-secondary/30 border-border/40 text-sm" />
        </div>
        <div>
          <label className="text-xs font-medium text-muted-foreground mb-1 block">Item ID</label>
          <Input value={item} onChange={e => setItem(e.target.value)} placeholder="diamond_sword" className="bg-secondary/30 border-border/40 text-sm" />
        </div>
        <div>
          <label className="text-xs font-medium text-muted-foreground mb-1 block">Amount</label>
          <Input value={amount} onChange={e => setAmount(e.target.value)} placeholder="1" className="bg-secondary/30 border-border/40 text-sm" />
        </div>
        <div>
          <label className="text-xs font-medium text-muted-foreground mb-1 block">Enchantment (name level)</label>
          <Input value={enchant} onChange={e => setEnchant(e.target.value)} placeholder="sharpness 5" className="bg-secondary/30 border-border/40 text-sm" />
        </div>
      </div>

      {/* Output */}
      <div className="rounded-xl bg-background border border-border/30 p-4">
        <div className="text-xs text-muted-foreground mb-2 font-medium">Generated Command</div>
        <code className="text-xs text-green-400 break-all font-mono">{cmd}</code>
      </div>

      <Button onClick={copy} className="gap-2 bg-primary hover:bg-primary/90 text-white border-0">
        {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
        {copied ? 'Copied!' : 'Copy Command'}
      </Button>

      <div className="mt-4 p-3 rounded-lg bg-blue-500/10 border border-blue-500/20 text-xs text-blue-300">
        💡 Paste this directly into your server's Console tab. For more advanced commands, use <span className="font-semibold">MCStacker</span> (see the MCStacker tab).
      </div>
    </div>
  );
}

function SkinLookup() {
  const [username, setUsername] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState('');

  const lookup = async () => {
    if (!username.trim()) return;
    setLoading(true);
    setResult(null);
    // Use Minotar for skin + crafatar for avatar (no API key needed)
    await new Promise(r => setTimeout(r, 600));
    const skinUrl = `https://minotar.net/skin/${username}`;
    const avatarUrl = `https://minotar.net/helm/${username}/100`;
    const npcCmd = `/npc create ${username} --player-skin ${username}`;
    const citizensCmd = `/citizens skin ${username} ${username}`;
    setResult({ username, skinUrl, avatarUrl, npcCmd, citizensCmd });
    setLoading(false);
  };

  const copy = (text, key) => {
    navigator.clipboard.writeText(text);
    setCopied(key);
    setTimeout(() => setCopied(''), 2000);
  };

  return (
    <div className="space-y-4 max-w-xl">
      <div>
        <h2 className="text-xl font-bold mb-1">Skin & UUID Lookup</h2>
        <p className="text-sm text-muted-foreground">Look up any Java player's skin and generate NPC commands.</p>
      </div>

      <div className="flex gap-2">
        <Input value={username} onChange={e => setUsername(e.target.value)} onKeyDown={e => e.key === 'Enter' && lookup()}
          placeholder="Enter Java username..." className="bg-secondary/30 border-border/40" />
        <Button onClick={lookup} disabled={loading || !username.trim()} className="bg-primary hover:bg-primary/90 text-white border-0 gap-2">
          <Search className="w-4 h-4" />
          {loading ? 'Looking...' : 'Lookup'}
        </Button>
      </div>

      {result && (
        <div className="rounded-xl bg-card/50 border border-border/30 p-5 space-y-4">
          <div className="flex items-center gap-4">
            <img src={result.avatarUrl} alt={result.username} className="w-16 h-16 rounded-lg border border-border/30" style={{ imageRendering: 'pixelated' }} />
            <div>
              <div className="font-bold text-lg">{result.username}</div>
              <a href={result.skinUrl} target="_blank" rel="noopener noreferrer"
                className="text-xs text-primary flex items-center gap-1 hover:underline">
                <ExternalLink className="w-3 h-3" /> Download skin .png
              </a>
            </div>
          </div>

          {[
            { label: 'Citizens NPC Command', value: result.npcCmd, key: 'npc' },
            { label: 'Skin URL (for Eaglercraft)', value: result.skinUrl, key: 'skin' },
          ].map(row => (
            <div key={row.key}>
              <div className="text-xs text-muted-foreground mb-1 font-medium">{row.label}</div>
              <div className="flex gap-2 items-center">
                <code className="flex-1 text-xs font-mono bg-background border border-border/30 rounded-lg px-3 py-2 text-green-400 break-all">{row.value}</code>
                <button onClick={() => copy(row.value, row.key)}
                  className="p-2 rounded-lg hover:bg-primary/10 text-muted-foreground hover:text-primary transition-colors flex-shrink-0">
                  {copied === row.key ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function MCStackerEmbed() {
  const [version, setVersion] = useState('modern');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const containerRef = React.useRef(null);

  const toggleFullscreen = () => {
    if (!isFullscreen) {
      containerRef.current?.requestFullscreen?.();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen?.();
      setIsFullscreen(false);
    }
  };

  React.useEffect(() => {
    const handler = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', handler);
    return () => document.removeEventListener('fullscreenchange', handler);
  }, []);

  const src = version === 'modern' ? 'https://mcstacker.net' : 'https://mcstacker.net/1.12.php';

  return (
    <div className="flex flex-col" style={{ height: 'calc(100vh - 200px)' }}>
      <div className="flex items-center justify-between mb-3">
        <div>
          <h2 className="text-xl font-bold mb-0.5">MCStacker</h2>
          <p className="text-sm text-muted-foreground">Full command generator — summon, give, NBT, and more.</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex gap-1 bg-secondary/50 rounded-lg p-1">
            {[{ k: 'modern', l: 'Modern (1.13+)' }, { k: 'legacy', l: 'Legacy (1.8.8)' }].map(v => (
              <button key={v.k} onClick={() => setVersion(v.k)}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${version === v.k ? 'bg-primary text-white' : 'text-muted-foreground hover:text-foreground'}`}>
                {v.l}
              </button>
            ))}
          </div>
          <button
            onClick={toggleFullscreen}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-secondary/50 border border-border/30 text-xs font-semibold text-muted-foreground hover:text-foreground transition-colors"
            title="Fullscreen"
          >
            {isFullscreen ? '⛶ Exit' : '⛶ Fullscreen'}
          </button>
          <a href={src} target="_blank" rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-secondary/50 border border-border/30 text-xs font-semibold text-muted-foreground hover:text-foreground transition-colors">
            <ExternalLink className="w-3.5 h-3.5" /> Open Tab
          </a>
        </div>
      </div>
      <div ref={containerRef} className="flex-1 rounded-xl overflow-hidden border border-border/30 bg-card/50 min-h-0">
        <iframe
          key={version}
          src={src}
          className="w-full h-full border-0"
          title="MCStacker"
          allow="fullscreen"
          sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-modals"
        />
      </div>
    </div>
  );
}

export default function MCTools() {
  const [activeTool, setActiveTool] = useState('command');

  return (
    <div className="py-20 lg:py-28">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-black mb-1">MC <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Tools</span></h1>
          <p className="text-sm text-muted-foreground">Creator's Laboratory — generate commands, look up skins, and build without leaving the panel.</p>
        </div>

        <div className="flex flex-col md:flex-row gap-6">
          {/* Sidebar */}
          <div className="md:w-48 flex md:flex-col gap-1">
            {tools.map(tool => (
              <button key={tool.id} onClick={() => setActiveTool(tool.id)}
                className={`flex items-center gap-2.5 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors text-left ${
                  activeTool === tool.id
                    ? 'bg-primary/10 text-primary border border-primary/20'
                    : 'text-muted-foreground hover:text-foreground hover:bg-secondary/50'
                }`}>
                <tool.icon className="w-4 h-4 flex-shrink-0" />
                {tool.label}
              </button>
            ))}
          </div>

          {/* Content */}
          <div className="flex-1">
            {activeTool === 'command' && <CommandLab />}
            {activeTool === 'skin' && <SkinLookup />}
            {activeTool === 'mcstacker' && <MCStackerEmbed />}
          </div>
        </div>
      </div>
    </div>
  );
}