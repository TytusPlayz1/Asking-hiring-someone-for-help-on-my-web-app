import React, { useState } from 'react';
import { Globe, Gamepad2, Info, ExternalLink, Download, Shield, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

// WSS-safe launcher URL (hosted on a domain that supports wss://)
const LAUNCHER_URL = 'https://eaglercraft.com/mc/1.8.8/';
const AMPLER_URL = 'https://irv77.github.io/AmplerLauncher/';

export default function EaglercraftLauncher() {
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState(false);
  const [showDownloadBanner, setShowDownloadBanner] = useState(true);
  const [useAmpler, setUseAmpler] = useState(false);

  const activeSrc = useAmpler ? AMPLER_URL : LAUNCHER_URL;

  return (
    <div className="flex flex-col" style={{ height: 'calc(100vh - 64px)' }}>

      {/* Optional download banner */}
      {showDownloadBanner && (
        <div className="flex items-center gap-3 px-4 py-2.5 bg-purple-500/10 border-b border-purple-500/20 flex-shrink-0">
          <Download className="w-4 h-4 text-purple-400 flex-shrink-0" />
          <div className="flex-1 text-xs text-purple-300">
            <span className="font-semibold">Want offline play?</span> Download the Ampler Launcher files to run Eaglercraft locally — works even when this site is blocked.
          </div>
          <a
            href={AMPLER_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-shrink-0 px-3 py-1 rounded-lg bg-purple-500/20 border border-purple-500/30 text-purple-300 text-xs font-semibold hover:bg-purple-500/30 transition-colors"
          >
            Download Files
          </a>
          <button onClick={() => setShowDownloadBanner(false)} className="flex-shrink-0 text-muted-foreground hover:text-foreground">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Top bar */}
      <div className="flex items-center gap-3 px-4 py-2 bg-card/80 backdrop-blur-sm border-b border-border/30 flex-shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center">
            <Gamepad2 className="w-3.5 h-3.5 text-white" />
          </div>
          <span className="text-sm font-semibold">Eaglercraft Launcher</span>
          <div className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-green-500/10 border border-green-500/20">
            <Shield className="w-3 h-3 text-green-400" />
            <span className="text-xs text-green-400 font-medium">WSS Secured</span>
          </div>
        </div>

        {/* Toggle between Eaglercraft.com and Ampler */}
        <div className="flex items-center gap-1 ml-auto bg-secondary/50 rounded-lg p-1">
          <button
            onClick={() => { setUseAmpler(false); setLoaded(false); setError(false); }}
            className={`px-2.5 py-1 rounded-md text-xs font-medium transition-all ${!useAmpler ? 'bg-primary text-white' : 'text-muted-foreground hover:text-foreground'}`}
          >
            Eaglercraft 1.8.8
          </button>
          <button
            onClick={() => { setUseAmpler(true); setLoaded(false); setError(false); }}
            className={`px-2.5 py-1 rounded-md text-xs font-medium transition-all ${useAmpler ? 'bg-primary text-white' : 'text-muted-foreground hover:text-foreground'}`}
          >
            Ampler Launcher
          </button>
        </div>

        <div className="flex items-center gap-1.5">
          <div className={`w-1.5 h-1.5 rounded-full ${loaded ? 'bg-green-400' : 'bg-yellow-400 animate-pulse'}`} />
          <span className="text-xs text-muted-foreground">{loaded ? 'Ready' : 'Loading...'}</span>
          <a href={activeSrc} target="_blank" rel="noopener noreferrer" className="ml-1 text-muted-foreground hover:text-primary transition-colors" title="Open in new tab">
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>

      {/* WSS notice bar */}
      <div className="flex items-center gap-2 px-4 py-1.5 bg-blue-500/5 border-b border-blue-500/10 flex-shrink-0">
        <Shield className="w-3 h-3 text-blue-400 flex-shrink-0" />
        <span className="text-xs text-blue-300/70">
          Secure WebSocket (wss://) is automatically used — school firewalls see only encrypted HTTPS traffic to diorite.hosting.
        </span>
      </div>

      {/* iFrame */}
      <div className="flex-1 relative">
        {!loaded && !error && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-background z-10 gap-4">
            <div className="w-12 h-12 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
            <div className="text-sm text-muted-foreground">Loading Eaglercraft...</div>
            <div className="text-xs text-muted-foreground/60 flex items-center gap-1">
              <Shield className="w-3 h-3 text-green-400" /> Establishing secure wss:// connection...
            </div>
          </div>
        )}

        {error && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-background z-10 gap-4">
            <Globe className="w-12 h-12 text-muted-foreground/30" />
            <div className="text-center">
              <div className="text-sm font-semibold mb-1">Unable to embed launcher</div>
              <div className="text-xs text-muted-foreground mb-4">The page may block embedding. Open it directly in a new tab.</div>
              <div className="flex gap-3 justify-center">
                <a href={LAUNCHER_URL} target="_blank" rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-primary/10 text-primary text-sm hover:bg-primary/20 transition-colors">
                  <ExternalLink className="w-3.5 h-3.5" /> Eaglercraft.com
                </a>
                <a href={AMPLER_URL} target="_blank" rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-purple-500/10 text-purple-400 text-sm hover:bg-purple-500/20 transition-colors">
                  <ExternalLink className="w-3.5 h-3.5" /> Ampler Launcher
                </a>
              </div>
            </div>
          </div>
        )}

        <iframe
          key={activeSrc}
          src={activeSrc}
          className="w-full h-full border-0"
          title="Eaglercraft Launcher"
          onLoad={() => setLoaded(true)}
          onError={() => setError(true)}
          allow="fullscreen; autoplay; clipboard-write"
          sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-pointer-lock allow-downloads"
        />
      </div>

      {/* Bottom info */}
      <div className="flex items-center gap-2 px-4 py-1.5 bg-card/60 border-t border-border/20 flex-shrink-0">
        <Info className="w-3 h-3 text-muted-foreground/50" />
        <span className="text-xs text-muted-foreground/60">
          Eaglercraft is not affiliated with Mojang Studios. Ampler Launcher by IRV77 & Vulconcium.
        </span>
      </div>
    </div>
  );
}