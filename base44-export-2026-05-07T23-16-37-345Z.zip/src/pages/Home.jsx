import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';
import {
  ArrowRight, Zap, Shield, Globe, Server, Cpu, HardDrive,
  Layers, Terminal, Users, Clock, Lock, Gauge, Check, Gamepad2, Infinity
} from 'lucide-react';
import {
  Accordion, AccordionContent, AccordionItem, AccordionTrigger,
} from '@/components/ui/accordion';

const stats = [
  { value: '100%', label: 'Free Forever' },
  { value: '24/7', label: 'Always Online' },
  { value: '∞', label: 'No Limits' },
  { value: '<20ms', label: 'Low Latency' },
];

const features = [
  { icon: Server, title: 'Pterodactyl Panel', desc: 'Full web-based server management — console, files, schedules, subusers.', color: 'text-blue-400', bg: 'bg-blue-400/10' },
  { icon: Globe, title: 'Eaglercraft Ready', desc: 'Play directly in your browser via the built-in Ampler Launcher.', color: 'text-purple-400', bg: 'bg-purple-400/10' },
  { icon: Shield, title: 'DDoS Protected', desc: 'Always-on enterprise DDoS mitigation included at no cost.', color: 'text-green-400', bg: 'bg-green-400/10' },
  { icon: Infinity, title: 'Unlimited Players', desc: 'No slot restrictions. Invite as many friends as you want.', color: 'text-yellow-400', bg: 'bg-yellow-400/10' },
  { icon: Layers, title: 'Mods & Plugins', desc: 'Forge, Fabric, Spigot, Paper, Purpur — all supported, all free.', color: 'text-cyan-400', bg: 'bg-cyan-400/10' },
  { icon: Cpu, title: 'High Performance', desc: 'AMD Ryzen processors with NVMe storage for buttery TPS.', color: 'text-red-400', bg: 'bg-red-400/10' },
  { icon: HardDrive, title: 'NVMe Storage', desc: 'Lightning-fast storage for instant chunk loading and world saves.', color: 'text-orange-400', bg: 'bg-orange-400/10' },
  { icon: Terminal, title: 'Live Console', desc: 'Real-time console access to manage and monitor your server.', color: 'text-pink-400', bg: 'bg-pink-400/10' },
  { icon: Lock, title: 'Automatic Backups', desc: 'Scheduled world backups with one-click restore support.', color: 'text-indigo-400', bg: 'bg-indigo-400/10' },
  { icon: Users, title: 'Subuser System', desc: 'Give granular permissions to friends, staff, and admins.', color: 'text-teal-400', bg: 'bg-teal-400/10' },
  { icon: Clock, title: 'Instant Deploy', desc: 'Your server is live in under 30 seconds — no setup needed.', color: 'text-emerald-400', bg: 'bg-emerald-400/10' },
  { icon: Gauge, title: '99.9% Uptime', desc: 'Redundant infrastructure keeps your server online around the clock.', color: 'text-amber-400', bg: 'bg-amber-400/10' },
];

const freePerks = [
  'Unlimited RAM (fair-use)', 'Unlimited player slots', 'All server types (Java, Bedrock, Eaglercraft)',
  'Full mod & plugin support', 'DDoS protection', 'Automated backups', 'Free MySQL database',
  'Custom domain support', 'Subuser management', '24/7 uptime — no forced shutdowns',
  'Eaglercraft browser play', 'Real-time console access',
];

const faqs = [
  { q: 'Is it really 100% free?', a: 'Yes, completely free. No credit card, no bank account needed, no hidden fees. We keep it free forever — you just create an account and launch your server.' },
  { q: 'Will my server go offline randomly?', a: 'No. Unlike Aternos which sleeps your server when no one is online, we keep your server running 24/7 with no forced shutdowns or sleep modes.' },
  { q: 'What is Eaglercraft and the Ampler Launcher?', a: 'Eaglercraft lets players join Minecraft servers from any web browser without downloading the game. The Ampler Launcher (by IRV77) is a web-based client hub with multiple versions — accessible from our Play tab.' },
  { q: 'Can I install mods and plugins?', a: 'Absolutely. Forge, Fabric, Spigot, Paper, Purpur, BungeeCord — all free. Upload through the Pterodactyl file manager or use one-click installers.' },
  { q: 'Is there a player limit?', a: 'None. Invite as many players as you want. Fair-use resource limits apply to keep infrastructure stable for everyone, but there is no hard player cap.' },
  { q: 'How do I join using Eaglercraft?', a: 'Click the "Play" tab at the top to open the Ampler Launcher. Select a version, click Play, and connect to any server address — no Java download required.' },
];

export default function Home() {
  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-pulse-glow" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl animate-pulse-glow" style={{ animationDelay: '1.5s' }} />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-24 lg:pt-32 lg:pb-36">
          <div className="text-center max-w-4xl mx-auto">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-green-500/10 border border-green-500/20 text-green-400 text-sm font-medium mb-8">
                <Zap className="w-3.5 h-3.5" />
                100% Free · No Payment Required · No Limits
              </div>
            </motion.div>

            <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1 }}
              className="text-4xl sm:text-5xl lg:text-7xl font-black tracking-tight leading-[1.1] mb-6">
              Minecraft Hosting
              <br />
              <span className="bg-gradient-to-r from-green-400 via-primary to-accent bg-clip-text text-transparent">
                Free. Forever.
              </span>
            </motion.h1>

            <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.2 }}
              className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
              Launch Java, Bedrock, and Eaglercraft servers instantly — 24/7, unlimited players, full mod support.
              No credit card. No bank account. No catch.
            </motion.p>

            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.3 }}
              className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10">
              <Link to="/dashboard">
                <Button size="lg" className="bg-gradient-to-r from-green-500 to-emerald-600 hover:opacity-90 text-white border-0 px-8 h-12 text-base font-semibold">
                  Create Free Server
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
              <Link to="/play">
                <Button variant="outline" size="lg" className="border-border/50 h-12 px-8 text-base">
                  <Gamepad2 className="w-4 h-4 mr-2" />
                  Play Eaglercraft
                </Button>
              </Link>
            </motion.div>

            {/* Stats */}
            <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.4 }}
              className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto">
              {stats.map((s) => (
                <div key={s.label} className="text-center p-4 rounded-xl bg-card/50 border border-border/30">
                  <div className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-green-400 to-primary bg-clip-text text-transparent">{s.value}</div>
                  <div className="text-xs text-muted-foreground mt-1 font-medium">{s.label}</div>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Free perks highlight */}
      <section className="py-16 bg-card/20 border-y border-border/20">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h2 className="text-2xl sm:text-3xl font-bold mb-2">Everything Included,
              <span className="bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent"> Always Free</span>
            </h2>
            <p className="text-muted-foreground text-sm">No tiers, no upgrades, no paywalls.</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {freePerks.map((perk) => (
              <div key={perk} className="flex items-center gap-2 p-3 rounded-lg bg-card/50 border border-border/30">
                <Check className="w-3.5 h-3.5 text-green-400 flex-shrink-0" />
                <span className="text-xs font-medium">{perk}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Built to
              <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent"> Dominate</span>
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">Enterprise-grade features, zero cost.</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {features.map((f, i) => (
              <motion.div key={f.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }} transition={{ duration: 0.3, delay: i * 0.04 }}
                className="p-5 rounded-xl bg-card/50 border border-border/30 hover:border-primary/30 transition-all">
                <div className={`w-10 h-10 rounded-lg ${f.bg} flex items-center justify-center mb-3`}>
                  <f.icon className={`w-5 h-5 ${f.color}`} />
                </div>
                <h3 className="font-semibold text-sm mb-1">{f.title}</h3>
                <p className="text-xs text-muted-foreground leading-relaxed">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-24 bg-card/20 border-t border-border/20">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-3">
              Common
              <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent"> Questions</span>
            </h2>
          </div>
          <Accordion type="single" collapsible className="space-y-3">
            {faqs.map((faq, i) => (
              <AccordionItem key={i} value={`f${i}`}
                className="border border-border/30 rounded-xl px-6 bg-card/50 data-[state=open]:bg-card data-[state=open]:border-primary/20">
                <AccordionTrigger className="text-sm font-medium hover:no-underline py-5">{faq.q}</AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground leading-relaxed pb-5">{faq.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-green-500/5 rounded-full blur-3xl" />
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        </div>
        <div className="relative max-w-2xl mx-auto px-4 sm:px-6 text-center">
          <h2 className="text-3xl sm:text-5xl font-black mb-4 leading-tight">
            Start For Free.<br />
            <span className="bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent">Stay Free.</span>
          </h2>
          <p className="text-muted-foreground mb-8">Your server. Your rules. No bills.</p>
          <Link to="/dashboard">
            <Button size="lg" className="bg-gradient-to-r from-green-500 to-emerald-600 hover:opacity-90 text-white border-0 px-10 h-12 text-base font-bold">
              Launch My Server Now
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </section>
    </>
  );
}