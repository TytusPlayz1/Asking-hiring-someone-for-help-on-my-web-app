import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Search, BookOpen, Server, Globe, Layers, Shield, Terminal, Wrench } from 'lucide-react';
import { motion } from 'framer-motion';

const categories = [
  { id: 'all', label: 'All', icon: BookOpen },
  { id: 'getting-started', label: 'Getting Started', icon: Server },
  { id: 'eaglercraft', label: 'Eaglercraft', icon: Globe },
  { id: 'mods', label: 'Mods & Plugins', icon: Layers },
  { id: 'security', label: 'Security', icon: Shield },
  { id: 'advanced', label: 'Advanced', icon: Terminal },
];

const articles = [
  {
    id: 1,
    category: 'getting-started',
    title: 'Setting Up Your First Minecraft Server',
    summary: 'Learn how to create and configure your Minecraft server through the Pterodactyl panel, from initial setup to accepting your first player connections.',
    tags: ['beginner', 'panel', 'setup'],
  },
  {
    id: 2,
    category: 'getting-started',
    title: 'Understanding the Pterodactyl Panel',
    summary: 'A complete walkthrough of the Pterodactyl panel interface — file manager, console, schedules, databases, and subuser management.',
    tags: ['panel', 'guide'],
  },
  {
    id: 3,
    category: 'eaglercraft',
    title: 'Setting Up EaglercraftXBungee Proxy',
    summary: 'Step-by-step guide to configuring the Eaglercraft proxy so browser players can join your server. Covers WebSocket setup, SSL, and online-mode configuration.',
    tags: ['eaglercraft', 'proxy', 'websocket'],
  },
  {
    id: 4,
    category: 'eaglercraft',
    title: 'Troubleshooting Eaglercraft Connections',
    summary: 'Common issues when players try to connect via Eaglercraft and how to resolve them — from WSS certificates to firewall rules.',
    tags: ['eaglercraft', 'troubleshooting'],
  },
  {
    id: 5,
    category: 'mods',
    title: 'Installing Forge Mods on Your Server',
    summary: 'How to select the correct Forge egg, upload mods to the /mods directory, and ensure Java compatibility (Java 8 for legacy, Java 21 for 1.20+).',
    tags: ['forge', 'mods', 'java'],
  },
  {
    id: 6,
    category: 'mods',
    title: 'Setting Up Fabric with Mods',
    summary: 'Configure a Fabric server with mod support. Covers Fabric Loader installation, mod compatibility, and performance optimization.',
    tags: ['fabric', 'mods'],
  },
  {
    id: 7,
    category: 'mods',
    title: 'GeyserMC: Java + Bedrock Crossplay',
    summary: 'Enable Bedrock players to join your Java server using GeyserMC and Floodgate. Includes authentication setup and known limitations.',
    tags: ['geyser', 'bedrock', 'crossplay'],
  },
  {
    id: 8,
    category: 'security',
    title: 'DDoS Protection & Firewall Configuration',
    summary: 'Understanding our built-in DDoS mitigation, configuring additional firewall rules, and best practices for securing your Minecraft server.',
    tags: ['ddos', 'firewall', 'security'],
  },
  {
    id: 9,
    category: 'security',
    title: 'SSL Certificates for Eaglercraft (WSS)',
    summary: 'Why browsers require WSS (secure WebSockets) and how to set up Let\'s Encrypt SSL certificates for your Eaglercraft proxy.',
    tags: ['ssl', 'eaglercraft', 'certificates'],
  },
  {
    id: 10,
    category: 'advanced',
    title: 'Setting Up a BungeeCord / Velocity Network',
    summary: 'Create a multi-server network with proxy servers. Configure lobbies, survival, and minigame servers behind a single address.',
    tags: ['bungeecord', 'velocity', 'network'],
  },
  {
    id: 11,
    category: 'advanced',
    title: 'Automated Billing Integration (Paymenter)',
    summary: 'Connect your hosting business to Paymenter for automated server provisioning. Covers API keys, product creation, and egg mapping.',
    tags: ['billing', 'paymenter', 'automation'],
  },
  {
    id: 12,
    category: 'advanced',
    title: 'Port Allocation & Networking',
    summary: 'Understanding port ranges, allocations in Pterodactyl, and how to configure networking for multi-server setups and proxy connections.',
    tags: ['networking', 'ports', 'configuration'],
  },
];

export default function KnowledgeBase() {
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');

  const filtered = articles.filter((article) => {
    const matchesCategory = activeCategory === 'all' || article.category === activeCategory;
    const matchesSearch = !search ||
      article.title.toLowerCase().includes(search.toLowerCase()) ||
      article.summary.toLowerCase().includes(search.toLowerCase()) ||
      article.tags.some(t => t.toLowerCase().includes(search.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="py-20 lg:py-28">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl sm:text-5xl font-black mb-4">
            Knowledge
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent"> Base</span>
          </h1>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Guides, tutorials, and documentation for managing your Minecraft server.
          </p>
        </div>

        {/* Search */}
        <div className="relative max-w-md mx-auto mb-10">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search articles..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-card/50 border-border/30"
          />
        </div>

        {/* Categories */}
        <div className="flex flex-wrap justify-center gap-2 mb-10">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeCategory === cat.id
                  ? 'bg-primary/10 text-primary border border-primary/20'
                  : 'bg-card/50 text-muted-foreground hover:text-foreground border border-border/30 hover:border-border/60'
              }`}
            >
              <cat.icon className="w-3.5 h-3.5" />
              {cat.label}
            </button>
          ))}
        </div>

        {/* Articles */}
        <div className="space-y-4">
          {filtered.map((article, i) => (
            <motion.article
              key={article.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: i * 0.04 }}
              className="p-6 rounded-xl bg-card/50 border border-border/30 hover:border-primary/20 transition-all cursor-pointer group"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold mb-2 group-hover:text-primary transition-colors">
                    {article.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed mb-3">
                    {article.summary}
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {article.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="text-xs bg-secondary/50 border-border/30">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
                <Wrench className="w-5 h-5 text-muted-foreground/30 flex-shrink-0 mt-1" />
              </div>
            </motion.article>
          ))}

          {filtered.length === 0 && (
            <div className="text-center py-16">
              <BookOpen className="w-10 h-10 text-muted-foreground/30 mx-auto mb-3" />
              <p className="text-muted-foreground">No articles found matching your search.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}