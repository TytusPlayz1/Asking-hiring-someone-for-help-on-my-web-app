const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Shield, Key, Bell, Moon, Sun, Copy, RefreshCw, Check, Trash2, AlertTriangle, User, Users, Camera } from 'lucide-react';

const tabs = [
  { id: 'profile', label: 'Profile', icon: User },
  { id: 'security', label: 'Security', icon: Shield },
  { id: 'api', label: 'API Access', icon: Key },
  { id: 'notifications', label: 'Notifications', icon: Bell },
  { id: 'users', label: 'Find Users', icon: Users },
];

export default function Settings() {
  const [activeTab, setActiveTab] = useState('profile');
  const [user, setUser] = useState(null);
  const [darkMode, setDarkMode] = useState(true);
  const [apiKey] = useState('dh_live_' + Math.random().toString(36).slice(2, 18).toUpperCase());
  const [copied, setCopied] = useState(false);
  const [twoFAEnabled, setTwoFAEnabled] = useState(false);
  const [emailNotifs, setEmailNotifs] = useState(true);
  const [discordNotifs, setDiscordNotifs] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState('');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  // Profile state
  const [bio, setBio] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [profileSaved, setProfileSaved] = useState(false);

  // User search
  const [searchQuery, setSearchQuery] = useState('');
  const [allUsers, setAllUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [usersLoading, setUsersLoading] = useState(false);

  useEffect(() => {
    db.auth.me().then(u => {
      setUser(u);
      setBio(u.bio || '');
      setAvatarUrl(u.avatar_url || '');
    }).catch(() => {});
  }, []);

  const copyApiKey = () => {
    navigator.clipboard.writeText(apiKey);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const toggleTheme = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle('dark');
  };

  const handleLogout = () => db.auth.logout('/');

  const saveProfile = async () => {
    await db.auth.updateMe({ bio, avatar_url: avatarUrl });
    setProfileSaved(true);
    setTimeout(() => setProfileSaved(false), 2000);
  };

  const loadUsers = async () => {
    setUsersLoading(true);
    const users = await db.entities.User.list();
    setAllUsers(users);
    setFilteredUsers(users);
    setUsersLoading(false);
  };

  useEffect(() => {
    if (activeTab === 'users' && allUsers.length === 0) loadUsers();
  }, [activeTab]);

  useEffect(() => {
    if (!searchQuery.trim()) { setFilteredUsers(allUsers); return; }
    const q = searchQuery.toLowerCase();
    setFilteredUsers(allUsers.filter(u =>
      u.full_name?.toLowerCase().includes(q) || u.email?.toLowerCase().includes(q)
    ));
  }, [searchQuery, allUsers]);

  return (
    <div className="py-20 lg:py-28">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-black">Settings</h1>
            <p className="text-sm text-muted-foreground mt-1">Manage your account and preferences</p>
          </div>
          <Button onClick={handleLogout} variant="outline" className="border-red-500/30 text-red-400 hover:bg-red-500/10 hover:border-red-500/50">
            Logout
          </Button>
        </div>

        {/* Account info */}
        {user && (
          <div className="p-5 rounded-xl bg-card/50 border border-border/30 mb-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center flex-shrink-0 overflow-hidden">
              {user.avatar_url
                ? <img src={user.avatar_url} alt="avatar" className="w-full h-full object-cover" onError={e => { e.target.style.display='none'; }} />
                : <User className="w-6 h-6 text-primary" />}
            </div>
            <div className="min-w-0">
              <div className="font-semibold text-sm truncate">{user.full_name || user.email}</div>
              <div className="text-xs text-muted-foreground truncate">{user.email}</div>
              {user.bio && <div className="text-xs text-muted-foreground/70 truncate mt-0.5 italic">"{user.bio}"</div>}
            </div>
          </div>
        )}

        {/* Theme Toggle */}
        <div className="p-5 rounded-xl bg-card/50 border border-border/30 mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {darkMode ? <Moon className="w-5 h-5 text-primary" /> : <Sun className="w-5 h-5 text-yellow-400" />}
            <div>
              <div className="font-semibold text-sm">{darkMode ? 'Dark Mode' : 'Light Mode'}</div>
              <div className="text-xs text-muted-foreground">Toggle the interface theme</div>
            </div>
          </div>
          <button onClick={toggleTheme} className={`relative w-12 h-6 rounded-full transition-colors ${darkMode ? 'bg-primary' : 'bg-muted'}`}>
            <span className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${darkMode ? 'left-7' : 'left-1'}`} />
          </button>
        </div>

        <div className="flex flex-col md:flex-row gap-6">
          {/* Sidebar tabs */}
          <div className="md:w-48 flex md:flex-col gap-1">
            {tabs.map((tab) => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2.5 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors text-left w-full ${
                  activeTab === tab.id ? 'bg-primary/10 text-primary border border-primary/20' : 'text-muted-foreground hover:text-foreground hover:bg-secondary/50'
                }`}>
                <tab.icon className="w-4 h-4 flex-shrink-0" />
                {tab.label}
              </button>
            ))}
          </div>

          {/* Content */}
          <div className="flex-1 space-y-4">

            {/* Profile Tab */}
            {activeTab === 'profile' && (
              <div className="p-5 rounded-xl bg-card/50 border border-border/30 space-y-4">
                <h3 className="font-semibold">Edit Profile</h3>
                <div>
                  <label className="text-xs font-medium text-muted-foreground block mb-1.5">Avatar URL</label>
                  <div className="flex gap-2 items-center">
                    <div className="w-10 h-10 rounded-lg bg-secondary/50 border border-border/30 overflow-hidden flex-shrink-0 flex items-center justify-center">
                      {avatarUrl
                        ? <img src={avatarUrl} alt="preview" className="w-full h-full object-cover" onError={e => { e.target.style.display='none'; }} />
                        : <Camera className="w-4 h-4 text-muted-foreground" />}
                    </div>
                    <Input
                      value={avatarUrl}
                      onChange={e => setAvatarUrl(e.target.value)}
                      placeholder="https://example.com/avatar.png"
                      className="bg-secondary/30 border-border/40 text-sm"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Paste any public image URL to use as your avatar.</p>
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground block mb-1.5">Bio</label>
                  <textarea
                    value={bio}
                    onChange={e => setBio(e.target.value)}
                    placeholder="Tell the community about yourself..."
                    maxLength={120}
                    rows={3}
                    className="w-full px-3 py-2 text-sm rounded-lg bg-secondary/30 border border-border/40 focus:outline-none focus:border-primary/50 resize-none text-foreground placeholder:text-muted-foreground"
                  />
                  <p className="text-xs text-muted-foreground text-right">{bio.length}/120</p>
                </div>
                <Button onClick={saveProfile} className="bg-primary hover:bg-primary/90 text-white border-0 gap-2">
                  {profileSaved ? <><Check className="w-4 h-4" /> Saved!</> : 'Save Profile'}
                </Button>
              </div>
            )}

            {/* Security Tab */}
            {activeTab === 'security' && (
              <>
                <div className="p-5 rounded-xl bg-card/50 border border-border/30">
                  <h3 className="font-semibold mb-4">Change Password</h3>
                  <div className="space-y-3">
                    <Input type="password" placeholder="Current password" className="bg-secondary/30 border-border/40" />
                    <Input type="password" placeholder="New password" className="bg-secondary/30 border-border/40" />
                    <Input type="password" placeholder="Confirm new password" className="bg-secondary/30 border-border/40" />
                    <Button className="w-full bg-primary hover:bg-primary/90">Update Password</Button>
                  </div>
                </div>
                <div className="p-5 rounded-xl bg-card/50 border border-border/30">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold">Two-Factor Authentication</h3>
                      <p className="text-xs text-muted-foreground mt-0.5">Add an extra layer of security to your account</p>
                    </div>
                    <button onClick={() => setTwoFAEnabled(!twoFAEnabled)}
                      className={`relative w-12 h-6 rounded-full transition-colors ${twoFAEnabled ? 'bg-green-500' : 'bg-muted'}`}>
                      <span className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${twoFAEnabled ? 'left-7' : 'left-1'}`} />
                    </button>
                  </div>
                  {twoFAEnabled && (
                    <div className="mt-4 p-3 rounded-lg bg-green-500/10 border border-green-500/20 text-xs text-green-400">
                      2FA is enabled. Your account is protected.
                    </div>
                  )}
                </div>
                <div className="p-5 rounded-xl bg-red-500/5 border border-red-500/20 space-y-3">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-red-400" />
                    <h3 className="font-semibold text-sm text-red-400">Delete Account</h3>
                  </div>
                  <p className="text-xs text-muted-foreground">This will permanently delete your account and all associated servers. This action cannot be undone.</p>
                  {!showDeleteConfirm ? (
                    <Button size="sm" variant="outline" className="border-red-500/40 text-red-400 hover:bg-red-500/10 text-xs gap-2" onClick={() => setShowDeleteConfirm(true)}>
                      <Trash2 className="w-3.5 h-3.5" /> Delete My Account
                    </Button>
                  ) : (
                    <div className="space-y-3">
                      <p className="text-xs text-red-400 font-medium">Type <strong>DELETE</strong> to confirm:</p>
                      <Input value={deleteConfirm} onChange={e => setDeleteConfirm(e.target.value)} placeholder="Type DELETE" className="bg-secondary/30 border-red-500/30 text-xs h-8" />
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" className="text-xs border-border/40" onClick={() => { setShowDeleteConfirm(false); setDeleteConfirm(''); }}>Cancel</Button>
                        <Button size="sm" className="text-xs bg-red-600 hover:bg-red-700 text-white border-0 gap-1.5" disabled={deleteConfirm !== 'DELETE'} onClick={() => db.auth.logout('/')}>
                          <Trash2 className="w-3.5 h-3.5" /> Permanently Delete
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </>
            )}

            {/* API Tab */}
            {activeTab === 'api' && (
              <div className="p-5 rounded-xl bg-card/50 border border-border/30">
                <h3 className="font-semibold mb-1">API Key</h3>
                <p className="text-xs text-muted-foreground mb-4">Use this key to interact with the Diorite Hosting+ API.</p>
                <div className="flex gap-2 mb-4">
                  <Input readOnly value={apiKey} className="font-mono text-xs bg-secondary/30 border-border/40" />
                  <Button variant="outline" size="icon" className="border-border/40 flex-shrink-0" onClick={copyApiKey}>
                    {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                  </Button>
                </div>
                <Button variant="outline" size="sm" className="border-border/40 text-muted-foreground gap-2">
                  <RefreshCw className="w-3.5 h-3.5" /> Regenerate Key
                </Button>
                <div className="mt-4 p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20 text-xs text-yellow-400">
                  Keep your API key secret. Do not share it publicly.
                </div>
              </div>
            )}

            {/* Notifications Tab */}
            {activeTab === 'notifications' && (
              <div className="p-5 rounded-xl bg-card/50 border border-border/30 space-y-4">
                <h3 className="font-semibold">Notification Preferences</h3>
                {[
                  { label: 'Email Notifications', desc: 'Server alerts sent to your email', value: emailNotifs, set: setEmailNotifs },
                  { label: 'Discord Webhook', desc: 'Push alerts to a Discord channel', value: discordNotifs, set: setDiscordNotifs },
                ].map((item) => (
                  <div key={item.label} className="flex items-center justify-between">
                    <div>
                      <div className="text-sm font-medium">{item.label}</div>
                      <div className="text-xs text-muted-foreground">{item.desc}</div>
                    </div>
                    <button onClick={() => item.set(!item.value)}
                      className={`relative w-12 h-6 rounded-full transition-colors ${item.value ? 'bg-primary' : 'bg-muted'}`}>
                      <span className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${item.value ? 'left-7' : 'left-1'}`} />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Find Users Tab */}
            {activeTab === 'users' && (
              <div className="p-5 rounded-xl bg-card/50 border border-border/30 space-y-4">
                <h3 className="font-semibold">Find Users</h3>
                <p className="text-xs text-muted-foreground">Search for real accounts on Diorite Hosting+.</p>
                <Input
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="Search by name or email..."
                  className="bg-secondary/30 border-border/40"
                />
                {usersLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="w-6 h-6 border-2 border-border border-t-primary rounded-full animate-spin" />
                  </div>
                ) : (
                  <div className="space-y-2 max-h-80 overflow-y-auto">
                    {filteredUsers.map(u => (
                      <div key={u.id} className="flex items-center gap-3 p-3 rounded-xl bg-secondary/20 border border-border/20">
                        <div className="w-9 h-9 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center flex-shrink-0 overflow-hidden">
                          {u.avatar_url
                            ? <img src={u.avatar_url} alt="" className="w-full h-full object-cover" onError={e => { e.target.style.display='none'; }} />
                            : <User className="w-4 h-4 text-primary" />}
                        </div>
                        <div className="min-w-0">
                          <div className="text-sm font-semibold truncate">{u.full_name || 'Unknown'}</div>
                          <div className="text-xs text-muted-foreground truncate">{u.email}</div>
                          {u.bio && <div className="text-xs text-muted-foreground/60 truncate italic">"{u.bio}"</div>}
                        </div>
                      </div>
                    ))}
                    {filteredUsers.length === 0 && (
                      <p className="text-center text-sm text-muted-foreground py-6">No users found.</p>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}