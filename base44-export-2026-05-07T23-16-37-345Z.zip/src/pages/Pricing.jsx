import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Check, X, HelpCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

const plans = [
  {
    name: 'Starter',
    monthly: 4,
    yearly: 3,
    description: 'Small vanilla servers with friends',
    ram: '2 GB',
    cpu: '2 vCPU',
    storage: '10 GB NVMe',
    players: '20',
    backups: 1,
    mysql: false,
    eaglercraft: false,
    dedicated_ip: false,
    priority_support: false,
    popular: false,
  },
  {
    name: 'Pro',
    monthly: 8,
    yearly: 6,
    description: 'Modded & community servers',
    ram: '4 GB',
    cpu: '3 vCPU',
    storage: '25 GB NVMe',
    players: '50',
    backups: 3,
    mysql: true,
    eaglercraft: true,
    dedicated_ip: false,
    priority_support: false,
    popular: true,
  },
  {
    name: 'Enterprise',
    monthly: 16,
    yearly: 12,
    description: 'Large networks & heavy modpacks',
    ram: '8 GB',
    cpu: '4 vCPU',
    storage: '50 GB NVMe',
    players: '100+',
    backups: 5,
    mysql: true,
    eaglercraft: true,
    dedicated_ip: true,
    priority_support: true,
    popular: false,
  },
  {
    name: 'Ultimate',
    monthly: 32,
    yearly: 24,
    description: 'Maximum power for massive communities',
    ram: '16 GB',
    cpu: '6 vCPU',
    storage: '100 GB NVMe',
    players: 'Unlimited',
    backups: 10,
    mysql: true,
    eaglercraft: true,
    dedicated_ip: true,
    priority_support: true,
    popular: false,
  },
];

const comparisonRows = [
  { label: 'RAM', key: 'ram' },
  { label: 'CPU Cores', key: 'cpu' },
  { label: 'NVMe Storage', key: 'storage' },
  { label: 'Player Slots', key: 'players' },
  { label: 'Backup Slots', key: 'backups', type: 'number' },
  { label: 'Free MySQL', key: 'mysql', type: 'boolean' },
  { label: 'Eaglercraft Proxy', key: 'eaglercraft', type: 'boolean', tooltip: 'WebSocket proxy for browser-based Minecraft clients' },
  { label: 'Dedicated IP', key: 'dedicated_ip', type: 'boolean' },
  { label: 'Priority Support', key: 'priority_support', type: 'boolean' },
];

export default function Pricing() {
  const [yearly, setYearly] = useState(false);

  return (
    <div className="py-20 lg:py-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl sm:text-5xl font-black mb-4">
            Choose Your
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent"> Plan</span>
          </h1>
          <p className="text-muted-foreground max-w-xl mx-auto mb-8">
            Every plan includes Pterodactyl panel access, DDoS protection, and instant deployment.
          </p>

          <div className="flex items-center justify-center gap-3">
            <span className={`text-sm font-medium ${!yearly ? 'text-foreground' : 'text-muted-foreground'}`}>Monthly</span>
            <Switch checked={yearly} onCheckedChange={setYearly} />
            <span className={`text-sm font-medium ${yearly ? 'text-foreground' : 'text-muted-foreground'}`}>
              Yearly
              <Badge className="ml-2 bg-green-500/10 text-green-400 border-green-500/20 text-xs">Save 25%</Badge>
            </span>
          </div>
        </div>

        {/* Plan Cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-24">
          {plans.map((plan, i) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: i * 0.08 }}
              className={`relative rounded-2xl p-6 flex flex-col ${
                plan.popular
                  ? 'bg-gradient-to-b from-primary/10 to-card border-2 border-primary/30 shadow-lg shadow-primary/5'
                  : 'bg-card/50 border border-border/30'
              }`}
            >
              {plan.popular && (
                <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-primary to-accent text-white border-0 px-4">
                  Most Popular
                </Badge>
              )}

              <h3 className="text-lg font-bold">{plan.name}</h3>
              <p className="text-xs text-muted-foreground mt-1 mb-4">{plan.description}</p>

              <div className="flex items-baseline gap-1 mb-6">
                <span className="text-4xl font-black">${yearly ? plan.yearly : plan.monthly}</span>
                <span className="text-sm text-muted-foreground">/mo</span>
              </div>

              <div className="text-xs text-muted-foreground mb-4 p-3 rounded-lg bg-secondary/50">
                {plan.ram} RAM · {plan.cpu} · {plan.storage}
              </div>

              <ul className="space-y-2.5 mb-6 flex-1">
                <li className="flex items-center gap-2 text-sm">
                  <Check className="w-3.5 h-3.5 text-green-400 flex-shrink-0" /> Java & Bedrock
                </li>
                <li className="flex items-center gap-2 text-sm">
                  <Check className="w-3.5 h-3.5 text-green-400 flex-shrink-0" /> {plan.backups} Backup{plan.backups !== 1 ? 's' : ''}
                </li>
                <li className="flex items-center gap-2 text-sm">
                  {plan.mysql ? <Check className="w-3.5 h-3.5 text-green-400 flex-shrink-0" /> : <X className="w-3.5 h-3.5 text-muted-foreground/40 flex-shrink-0" />}
                  <span className={!plan.mysql ? 'text-muted-foreground/60' : ''}>Free MySQL</span>
                </li>
                <li className="flex items-center gap-2 text-sm">
                  {plan.eaglercraft ? <Check className="w-3.5 h-3.5 text-green-400 flex-shrink-0" /> : <X className="w-3.5 h-3.5 text-muted-foreground/40 flex-shrink-0" />}
                  <span className={!plan.eaglercraft ? 'text-muted-foreground/60' : ''}>Eaglercraft Proxy</span>
                </li>
                <li className="flex items-center gap-2 text-sm">
                  {plan.dedicated_ip ? <Check className="w-3.5 h-3.5 text-green-400 flex-shrink-0" /> : <X className="w-3.5 h-3.5 text-muted-foreground/40 flex-shrink-0" />}
                  <span className={!plan.dedicated_ip ? 'text-muted-foreground/60' : ''}>Dedicated IP</span>
                </li>
              </ul>

              <Button
                className={`w-full ${
                  plan.popular
                    ? 'bg-gradient-to-r from-primary to-accent hover:opacity-90 text-white border-0'
                    : 'bg-secondary hover:bg-secondary/80'
                }`}
              >
                Select Plan
              </Button>
            </motion.div>
          ))}
        </div>

        {/* Comparison Table */}
        <div>
          <h2 className="text-2xl font-bold text-center mb-8">Full Plan Comparison</h2>
          <div className="overflow-x-auto">
            <TooltipProvider>
              <table className="w-full min-w-[640px]">
                <thead>
                  <tr className="border-b border-border/30">
                    <th className="text-left text-sm font-medium text-muted-foreground py-4 px-4">Feature</th>
                    {plans.map((plan) => (
                      <th key={plan.name} className="text-center text-sm font-semibold py-4 px-4">{plan.name}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {comparisonRows.map((row) => (
                    <tr key={row.key} className="border-b border-border/20">
                      <td className="text-sm py-3 px-4 flex items-center gap-1.5">
                        {row.label}
                        {row.tooltip && (
                          <Tooltip>
                            <TooltipTrigger>
                              <HelpCircle className="w-3.5 h-3.5 text-muted-foreground" />
                            </TooltipTrigger>
                            <TooltipContent>{row.tooltip}</TooltipContent>
                          </Tooltip>
                        )}
                      </td>
                      {plans.map((plan) => (
                        <td key={plan.name} className="text-center text-sm py-3 px-4">
                          {row.type === 'boolean' ? (
                            plan[row.key] ? (
                              <Check className="w-4 h-4 text-green-400 mx-auto" />
                            ) : (
                              <X className="w-4 h-4 text-muted-foreground/30 mx-auto" />
                            )
                          ) : (
                            <span className="font-medium">{plan[row.key]}</span>
                          )}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </TooltipProvider>
          </div>
        </div>
      </div>
    </div>
  );
}