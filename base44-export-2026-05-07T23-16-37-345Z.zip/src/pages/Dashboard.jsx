const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useMemo, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Plus, Server, Activity, HardDrive, Users } from 'lucide-react';
import ServerCard from '../components/dashboard/ServerCard';
import ServerManager from '../components/dashboard/ServerManager';
import NewServerModal from '../components/dashboard/NewServerModal';

import { useAchievement } from '../components/AchievementToast';

// Per-user localStorage helpers
const getUserKey = (email) => `DIORITE_SERVERS_${email}`;
const saveServers = (email, servers) => localStorage.setItem(getUserKey(email), JSON.stringify(servers));
const loadServers = (email) => {
  try { return JSON.parse(localStorage.getItem(getUserKey(email))) || []; }
  catch { return []; }
};

export default function Dashboard() {
  const { unlock } = useAchievement();
  const [user, setUser] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [servers, setServers] = useState([]);
  const [selectedServer, setSelectedServer] = useState(null);
  const [showNewModal, setShowNewModal] = useState(false);

  useEffect(() => {
    db.auth.me().then(u => {
      setUser(u);
      // Load THIS user's servers only — no cross-account bleed
      setServers(loadServers(u.email));
      setAuthLoading(false);
    }).catch(() => {
      setAuthLoading(false);
    });
  }, []);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !user) {
      db.auth.redirectToLogin(window.location.href);
    }
  }, [authLoading, user]);

  const totalOnline = useMemo(() => servers.filter(s => s.status === 'online').length, [servers]);
  const totalPlayers = useMemo(() => servers.reduce((a, s) => a + s.playersOnline, 0), [servers]);
  const totalDisk = useMemo(() => servers.reduce((a, s) => a + s.diskUsed, 0).toFixed(1), [servers]);

  const persistServers = (updated) => {
    if (user) saveServers(user.email, updated);
  };

  const updateServerStatus = (id, status) => {
    setServers(prev => {
      const updated = prev.map(s => s.id === id
        ? { ...s, status, cpuUsage: status === 'offline' ? 0 : s.cpuUsage, ramUsed: status === 'offline' ? 0 : s.ramUsed, playersOnline: status === 'offline' ? 0 : s.playersOnline }
        : s
      );
      persistServers(updated);
      return updated;
    });
  };

  const deleteServer = (id) => {
    setServers(prev => {
      const updated = prev.filter(s => s.id !== id);
      persistServers(updated);
      return updated;
    });
    if (selectedServer?.id === id) setSelectedServer(null);
  };

  const addServer = (newServer) => {
    const slug = newServer.name.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 20);
    // Ensure unique address by appending a suffix if the slug already exists
    setServers(prev => {
      const existingSlugs = prev.map(s => s.address);
      let candidate = `play.${slug}.diorite.hosting`;
      let suffix = 2;
      while (existingSlugs.includes(candidate)) {
        candidate = `play.${slug}${suffix}.diorite.hosting`;
        suffix++;
      }
      const address = candidate;
      const updated = [...prev, { ...newServer, id: Date.now(), address }];
      persistServers(updated);
      if (prev.length === 0) unlock('First Server!', 'Your journey begins.', '⛏️');
      else unlock('New Server Deployed', `${newServer.name} is ready.`, '🚀');
      return updated;
    });
  };

  if (authLoading) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-border border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) return null;

  const overviewStats = [
    { icon: Server, label: 'Total Servers', value: servers.length, color: 'text-blue-400', bg: 'bg-blue-400/10' },
    { icon: Activity, label: 'Online', value: totalOnline, color: 'text-green-400', bg: 'bg-green-400/10' },
    { icon: Users, label: 'Players Now', value: totalPlayers, color: 'text-purple-400', bg: 'bg-purple-400/10' },
    { icon: HardDrive, label: 'Disk Used', value: `${totalDisk} GB`, color: 'text-yellow-400', bg: 'bg-yellow-400/10' },
  ];

  if (selectedServer) {
    const liveServer = servers.find(s => s.id === selectedServer.id) || selectedServer;
    return (
      <div className="pt-16">
        <ServerManager
          server={liveServer}
          onBack={() => setSelectedServer(null)}
          onStatusChange={updateServerStatus}
        />
      </div>
    );
  }

  return (
    <div className="py-20 lg:py-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-black">Dashboard</h1>
            <p className="text-sm text-muted-foreground mt-1">Welcome back, {user.full_name || user.email}</p>
          </div>
          <Button
            onClick={() => setShowNewModal(true)}
            className="bg-gradient-to-r from-green-500 to-emerald-600 hover:opacity-90 text-white border-0"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Free Server
          </Button>
        </div>

        {/* Live Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {overviewStats.map((stat) => (
            <div key={stat.label} className="p-4 rounded-xl bg-card/50 border border-border/30 flex items-center gap-4">
              <div className={`w-10 h-10 rounded-lg ${stat.bg} flex items-center justify-center`}>
                <stat.icon className={`w-5 h-5 ${stat.color}`} />
              </div>
              <div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
                <div className="text-xl font-bold">{stat.value}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Server Grid */}
        <h2 className="text-lg font-bold mb-4">Your Servers</h2>
        {servers.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground">
            <Server className="w-12 h-12 mx-auto mb-3 opacity-20" />
            <p className="text-sm">No servers yet. Create your first free server!</p>
            <Button onClick={() => setShowNewModal(true)} className="mt-4 bg-gradient-to-r from-green-500 to-emerald-600 text-white border-0">
              <Plus className="w-4 h-4 mr-2" /> New Free Server
            </Button>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {servers.map((server) => (
              <ServerCard
                key={server.id}
                server={server}
                onManage={setSelectedServer}
                onStatusChange={updateServerStatus}
                onDelete={deleteServer}
              />
            ))}
          </div>
        )}
      </div>

      {showNewModal && (
        <NewServerModal
          onClose={() => setShowNewModal(false)}
          onCreate={addServer}
        />
      )}
    </div>
  );
}