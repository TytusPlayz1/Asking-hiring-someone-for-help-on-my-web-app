import React, { useState } from 'react';
import { Tv, Music, BookOpen, Sword, ExternalLink, Search, Play } from 'lucide-react';

const PLAYLISTS = [
  { id: 'PLlp2oHHkZshc81qPPAVHV81_8oZ8LMItf', label: 'C418 Full OST', icon: '🎵', cat: 'music' },
  { id: 'PLNG8gFz9vUpsLXnWdCEf0svaFEfbY-kHh', label: 'MC Music Mix', icon: '🎵', cat: 'music' },
  { id: 'PLtJ2sk922NkcS0qHQJipX42Lj3U8gP89S', label: 'MC Parody Classics', icon: '🎭', cat: 'parody' },
  { id: 'PL3817D41C7D841E23', label: 'MC Parodies Mix', icon: '🎭', cat: 'parody' },
  { id: 'PLnfoqKPSIlMF5s3zFMBqH6kLEYdNVNdnp', label: 'Tutorials & Guides', icon: '📖', cat: 'tutorial' },
  { id: 'PLnfoqKPSIlMFwAqu4FN0mmJYq4AqPsP0l', label: 'Eaglercraft Help', icon: '🌐', cat: 'tutorial' },
];

const FEATURED = [
  { label: 'C418 – Sweden', videoId: '9fAqjRjPXJ4', icon: '🎶' },
  { label: 'Fallen Kingdom', videoId: 'y5MaFoe2kHw', icon: '👑' },
  { label: 'I See a Dreamer – CG5', videoId: 'JhMVQ_jDQhI', icon: '✨' },
  { label: 'Dream SMP Montage', videoId: 'kDFqKoZY_7g', icon: '⚔️' },
  { label: 'Revenge – CaptainSparklez', videoId: '8NlYZ-f8wHk', icon: '⚔️' },
  { label: 'Take Back the Night', videoId: 'obgSqOyM8Q0', icon: '🌙' },
];

const CATS = [
  { key: 'featured', label: 'Featured', icon: Tv },
  { key: 'music', label: 'Music', icon: Music },
  { key: 'parody', label: 'Parodies', icon: Sword },
  { key: 'tutorial', label: 'Tutorials', icon: BookOpen },
];

export default function DioriteTube() {
  const [activeCat, setActiveCat] = useState('featured');
  const [activeVideo, setActiveVideo] = useState(FEATURED[0].videoId);
  const [activePlaylist, setActivePlaylist] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');

  const embedSrc = activePlaylist
    ? `https://www.youtube-nocookie.com/embed/videoseries?list=${activePlaylist}&autoplay=1&rel=0`
    : `https://www.youtube-nocookie.com/embed/${activeVideo}?autoplay=1&rel=0`;

  const handleSearch = (e) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    // Force Minecraft context in search
    const query = encodeURIComponent(`${searchQuery} minecraft`);
    setActivePlaylist(null);
    setActiveVideo(`search?q=${query}`); // won't embed but navigates in YT
    window.open(`https://www.youtube.com/results?search_query=${query}`, '_blank');
  };

  return (
    <div className="py-20 lg:py-24" style={{ minHeight: 'calc(100vh - 64px)' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-black flex items-center gap-3">
              <span className="text-red-500">🎬</span>
              Diorite<span className="text-red-500">Tube</span>
            </h1>
            <p className="text-sm text-muted-foreground mt-1">Minecraft content only · School-safe · No tracking</p>
          </div>
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-green-500/10 border border-green-500/20 text-xs text-green-400">
            🛡️ youtube-nocookie.com · Secure Mode
          </div>
        </div>

        <div className="grid lg:grid-cols-[1fr,320px] gap-6">
          {/* Main player */}
          <div>
            <div className="rounded-2xl overflow-hidden border border-border/30 bg-black aspect-video mb-4">
              <iframe
                key={embedSrc}
                src={embedSrc}
                className="w-full h-full"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
                allowFullScreen
                title="Diorite Tube Player"
              />
            </div>

            {/* Search bar */}
            <form onSubmit={handleSearch} className="flex gap-2 mb-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder='Search Minecraft content... (opens YouTube)'
                  className="w-full pl-9 pr-3 py-2 text-sm rounded-lg bg-secondary/30 border border-border/30 outline-none focus:border-primary/40 transition-colors"
                />
              </div>
              <button type="submit" className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white text-sm font-semibold transition-colors flex items-center gap-2">
                <ExternalLink className="w-4 h-4" /> Search
              </button>
            </form>
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            {/* Category tabs */}
            <div className="flex gap-1 bg-secondary/40 rounded-xl p-1">
              {CATS.map(cat => (
                <button key={cat.key} onClick={() => setActiveCat(cat.key)}
                  className={`flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg text-xs font-medium transition-all ${activeCat === cat.key ? 'bg-card text-foreground shadow' : 'text-muted-foreground hover:text-foreground'}`}>
                  <cat.icon className="w-3 h-3" />
                  <span className="hidden sm:inline">{cat.label}</span>
                </button>
              ))}
            </div>

            {/* Featured videos */}
            {activeCat === 'featured' && (
              <div className="space-y-2">
                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide px-1">Quick Play</div>
                {FEATURED.map(v => (
                  <button key={v.videoId} onClick={() => { setActivePlaylist(null); setActiveVideo(v.videoId); }}
                    className={`w-full flex items-center gap-3 p-3 rounded-xl border text-left transition-all ${activeVideo === v.videoId && !activePlaylist ? 'border-red-500/40 bg-red-500/5' : 'border-border/30 hover:border-border/60 bg-card/50'}`}>
                    <span className="text-xl">{v.icon}</span>
                    <span className="text-sm font-medium flex-1 truncate">{v.label}</span>
                    <Play className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                  </button>
                ))}
              </div>
            )}

            {/* Playlists */}
            {(activeCat === 'music' || activeCat === 'parody' || activeCat === 'tutorial') && (
              <div className="space-y-2">
                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide px-1">Playlists</div>
                {PLAYLISTS.filter(p => activeCat === 'music' ? p.cat === 'music' : activeCat === 'parody' ? p.cat === 'parody' : p.cat === 'tutorial').map(pl => (
                  <button key={pl.id} onClick={() => { setActivePlaylist(pl.id); setActiveVideo(null); }}
                    className={`w-full flex items-center gap-3 p-3 rounded-xl border text-left transition-all ${activePlaylist === pl.id ? 'border-red-500/40 bg-red-500/5' : 'border-border/30 hover:border-border/60 bg-card/50'}`}>
                    <span className="text-xl">{pl.icon}</span>
                    <span className="text-sm font-medium flex-1">{pl.label}</span>
                  </button>
                ))}
                {PLAYLISTS.filter(p => activeCat === 'music' ? p.cat === 'music' : activeCat === 'parody' ? p.cat === 'parody' : p.cat === 'tutorial').length === 0 && (
                  <p className="text-xs text-muted-foreground text-center py-6">No playlists in this category yet.</p>
                )}
              </div>
            )}

            {/* Info box */}
            <div className="p-3 rounded-xl bg-secondary/30 border border-border/20 text-xs text-muted-foreground space-y-1">
              <div className="font-semibold text-foreground/80">🔒 School-Safe Mode</div>
              <div>Uses youtube-nocookie.com to bypass tracking filters. All searches auto-append "Minecraft" to keep content relevant.</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}